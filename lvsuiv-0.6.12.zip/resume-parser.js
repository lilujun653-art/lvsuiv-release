(function(root){
// ============ 章节标题 → 分组 ============
const headers={
  个人信息:'basic',基本信息:'basic',联系方式:'basic',个人资料:'basic',基本资料:'basic',
  求职意向:'intent',求职意愿:'intent',求职期望:'intent',求职目标:'intent',
  教育背景:'education',教育经历:'education',学历信息:'education',学历:'education',教育:'education',
  在校经历:'project',校园经历:'project',校内经历:'project',校园实践:'project',实践经历:'project',社会实践:'project',
  社团经历:'project',社团和组织经历:'project',组织经历:'project',学术经历:'project',校内职务:'project',
  课程设计:'project',个人作品:'project',作品展示:'project',学生工作类:'project',社会实践类:'project',
  工作经历:'work',工作经验:'work',职业经历:'work',工作履历:'work',
  实习经历:'internship',实习经验:'internship',实习:'internship',
  项目经历:'project',项目经验:'project',科研经历:'project',科研项目:'project',课题经历:'project',
  语言能力:'language',语言技能:'language',外语能力:'language',
  荣誉证书:'honor',荣誉奖项:'honor',荣誉奖励:'honor',获奖经历:'award',荣誉:'honor',奖项:'award',
  获奖情况:'award',奖励情况:'award',所获奖励:'award',获奖证书:'honor',奖项荣誉:'honor',
  主要证书及荣誉奖项:'honor',在校荣誉:'honor',
  证书:'certificate',技能证书:'certificate',资格证书:'certificate',相关证书:'certificate',资质证书:'certificate',
  自我描述:'summary',自我评价:'summary',个人评价:'summary',自我介绍:'summary',个人总结:'summary',
  个人优势:'summary',个人亮点:'summary',个人简介:'summary',
  相关技能:'skills',专业技能:'skills',技能特长:'skills',个人技能:'skills',技能语言:'skills','技能/语言':'skills',
  计算机技能:'skills',IT技能:'skills',专业特长:'skills',兴趣特长:'skills',兴趣爱好:'skills',其他技能:'skills',特长:'skills',
  技能:'skills',专业能力:'skills',个人能力:'skills',技能与证书:'skills',能力特长:'skills',
  // ---- 英文简历小节（外企/英文简历常见；匹配时统一小写）----
  'Personal Information':'basic','Personal Details':'basic','Contact':'basic','Contact Information':'basic','Profile':'basic',
  'Education':'education','Academic Background':'education','Education Background':'education','Educational Background':'education',
  'Work Experience':'work','Professional Experience':'work','Experience':'work','Employment History':'work','Employment':'work',
  'Internship':'internship','Internships':'internship','Internship Experience':'internship',
  'Projects':'project','Project Experience':'project','Research Experience':'project','Campus Experience':'project',
  'Activities':'project','Extracurricular Activities':'project','Campus Activities':'project',
  'Skills':'skills','Technical Skills':'skills','Professional Skills':'skills','Computer Skills':'skills','Core Skills':'skills',
  'Languages':'language','Language Skills':'language','Language Proficiency':'language',
  'Awards':'award','Honors':'award','Honours':'award','Awards & Honors':'award','Awards and Honors':'award','Scholarships':'award','Achievements':'award',
  'Certificates':'certificate','Certifications':'certificate','Certificate':'certificate','Licenses':'certificate','Licenses & Certifications':'certificate',
  'Summary':'summary','Self Evaluation':'summary','About Me':'summary','Objective':'summary','Career Objective':'summary','Self Assessment':'summary','Profile':'summary','Personal Profile':'summary','Professional Summary':'summary',
  // ---- 学术/出版物类小节：这类小节动辄上千行，必须收进 project 当描述，不能逐行入奖项（实测学术 CV 曾爆出 3722 条 award）
  'Publications':'project','Publication':'project','Publications and Patents':'project','Papers':'project',
  'Journal Articles':'project','Conference Papers':'project','Research':'project','Research Projects':'project',
  'Teaching':'project','Teaching Experience':'project','Presentations':'project','Talks':'project',
  'Patents':'project','Grants':'project','Professional Service':'project','Academic Service':'project','References':'project',
  论文发表:'project',发表论文:'project',科研成果:'project',著作:'project',专利:'project',论文:'project',专著:'project'
};
// ============ 字段键 → schema 键 ============
const keys={
  basic:{姓名:'name',名字:'name',姓名拼音:'name',性别:'gender',年龄:'age',
    出生日期:'birthDate',出生年月:'birthDate',生日:'birthDate',
    电话:'phone',手机:'phone',手机号码:'phone',手机号:'phone',联系电话:'phone',联系方式:'phone',
    邮箱:'email',电子邮箱:'email',电子邮件:'email',邮件:'email',
    所在地:'location',现居地:'currentResidence',现居:'currentResidence',现居住:'currentResidence',现居住地:'currentResidence',现所在地:'currentResidence',当前所在地:'currentResidence',所在城市:'currentResidence',居住地:'currentResidence',居住地址:'currentResidence',现住址:'currentResidence',家庭住址:'currentResidence',通讯地址:'currentResidence',
    证件号:'idNumber',证件号码:'idNumber',身份证号:'idNumber',身份证号码:'idNumber',身份证:'idNumber',
    政治面貌:'politicalStatus',民族:'ethnicity',
    籍贯:'hometown',户籍:'hometown',户籍所在地:'hometown',家乡:'hometown',
    身高:'height',体重:'weight',身高体重:'__hw',工作经验:'experience',开始工作时间:'experience',工作年限:'experience',参工时间:'experience',最高学历:'highestLevel',
    Name:'name',Gender:'gender',Age:'age',Phone:'phone',Mobile:'phone',Tel:'phone',Telephone:'phone',Email:'email','E-mail':'email',
    Address:'location',Location:'location',Hometown:'hometown',Nationality:'nationality','Date of Birth':'birthDate',Birthday:'birthDate'},
  intent:{意向岗位:'expectedRole',意向职位:'expectedRole',目标岗位:'expectedRole',求职岗位:'expectedRole',应聘岗位:'expectedRole',期望职位:'expectedRole',期望岗位:'expectedRole',求职意向:'expectedRole',求职意愿:'expectedRole',求职目标:'expectedRole',
    意向城市:'expectedCity',期望城市:'expectedCity',意向工作城市:'applicationCity',工作城市:'applicationCity',期望工作城市:'expectedCity',意向地区:'expectedCity',
    期望薪资:'expectedSalary',期望月薪:'expectedSalary',期望年薪:'expectedSalary',当前薪资:'currentSalary',目前薪资:'currentSalary',
    求职类型:'jobType',期望行业:'expectedIndustry',当前状态:'currentStatus',到岗时间:'available'},
  education:{学校:'school',学校名称:'school',毕业院校:'school',院校:'school',院校名称:'school',就读院校:'school',
    专业:'major',专业名称:'major',所学专业:'major',学历:'level',教育程度:'level',学位:'degree',
    主修课程:'description',主修科目:'description',专业课程:'description',核心课程:'description',
    入学时间:'start',入学:'start',开始时间:'start',起始时间:'start',就读时间:'start',毕业年份:'end',
    毕业时间:'end',毕业年月:'end',结束时间:'end',毕业:'end',
    School:'school',University:'school',College:'school',Institution:'school',Major:'major',Specialty:'major','Field of Study':'major',
    Degree:'degree',GPA:'level',Start:'start','Start Date':'start',End:'end','End Date':'end',Graduation:'end'},
  work:{公司:'company',公司名称:'company',单位名称:'company',企业名称:'company',
    职位:'role',职位名称:'role',岗位:'role',职务:'role',工作职责:'description',工作内容:'description',
    开始时间:'start',入职时间:'start',起始时间:'start',结束时间:'end',离职时间:'end',终止时间:'end',
    Company:'company',Employer:'company',Organization:'company',CompanyName:'company',
    Position:'role',Title:'role','Job Title':'role',Start:'start','Start Date':'start',End:'end','End Date':'end',
    Description:'description',Responsibilities:'description'},
  internship:{公司:'company',公司名称:'company',实习单位:'company',单位名称:'company',
    职位:'role',职位名称:'role',岗位:'role',实习岗位:'role',职务:'role',工作职责:'description',工作内容:'description',
    开始时间:'start',入职时间:'start',开始:'start',结束时间:'end',离职时间:'end',结束:'end',
    Company:'company',Employer:'company',Organization:'company',Position:'role',Title:'role',
    Start:'start','Start Date':'start',End:'end','End Date':'end',Description:'description',Responsibilities:'description'},
  project:{项目名称:'name',项目:'name',角色:'role',项目角色:'role',担任角色:'role',职务:'role',职责:'role',项目描述:'description',项目内容:'description',
    开始时间:'start',起始时间:'start',结束时间:'end',终止时间:'end',
    Project:'name','Project Name':'name',Role:'role',Start:'start','Start Date':'start',End:'end','End Date':'end',Description:'description'},
  language:{语言:'name',语言类型:'name',语种:'name',掌握程度:'proficiency',熟练程度:'proficiency',
    Language:'name',Proficiency:'proficiency'},
  award:{奖项名称:'name',奖项:'name',获奖名称:'name',获奖时间:'date',
    Award:'name',Honor:'name','Award Name':'name',Date:'date',Year:'date'},
  certificate:{证书名称:'name',证书:'name',资格名称:'name',等级:'level',成绩:'level',获得时间:'date',取得时间:'date',
    Certificate:'name',Certification:'name','Certificate Name':'name',Level:'level',Score:'level',Grade:'level',Date:'date'}
};
// ============ 工具 ============
// 字形归一：PDF 提取常把常用字换成「部首形」字符（"政治⾯貌"的 ⾯ = U+2FAF 康熙部首、
// "冯世⻰"的 ⻰ = U+2EF0 CJK 补充部首、"⼯程"的 ⼯ = U+2F2F）→ 键表匹配不上、整块字段丢失。
// 康熙部首（U+2F00-2FDF）与兼容汉字（U+F900-FAFF）NFKC 能还原；CJK 补充部首（U+2E80-2EFF）没有
// NFKC 映射，只能查表（表里是常见简/繁体部首形，未收录的由 wildKey 通配匹配兜底）。
const RAD_SUP={'⻓':'长','⻑':'长','⻒':'长','⻔':'门','⻘':'青','⻙':'韦','⻚':'页','⻛':'风','⻜':'飞','⻢':'马','⻣':'骨','⻤':'龟','⻥':'鱼','⻦':'鸟','⻧':'卤','⻨':'麦','⻩':'黄','⻪':'风','⻬':'齐','⻭':'齿','⻮':'齿','⻰':'龙','⻯':'龙','⻱':'黾','⻲':'黾','⻕':'阜','⻖':'阜','⻗':'雨','⻆':'角','⻊':'足','⻋':'车','⻐':'金','⻏':'邑','⻎':'辵','⻈':'言','⻃':'色','⻂':'衣','⻄':'西','⻝':'食','⻞':'食','⻟':'食','⻠':'食'};
const foldGlyphs=s=>String(s==null?'':s)
  .replace(/[\u2E80-\u2FDF\uF900-\uFAFF]/g,ch=>{
    const n=ch.normalize('NFKC');
    if(n!==ch&&n.length===1)return n;              // 康熙部首 / 兼容汉字 → 标准字
    return RAD_SUP[ch]!==undefined?RAD_SUP[ch]:ch;  // 补充部首查表，查不到先留着
  })
  .replace(/[\uE000-\uF8FF\uFE00-\uFE0F]/g,'')      // 图标字体的私有区码位（"教育背景"前的装饰图标）→ 删掉，否则整块标题匹配不上
  .replace(/[\uFF21-\uFF3A\uFF41-\uFF5A\uFF10-\uFF19]/g,ch=>String.fromCharCode(ch.charCodeAt(0)-0xFEE0))
  .replace(/[\u00A0\u2000-\u200F\u2028-\u202F\uFEFF\uFFFD]/g,' ')
  // 逐字排版的键名（"性 别： 男"、"民 族： 汉"、"邮 箱 ： x"）→ 合回"性别："，
  // 否则分格后会拆成"性" + "别："，两个格子都匹配不上键表（马金央那份简历整个基本信息区都这样写）
  .replace(/([\u4e00-\u9fa5])\s+(?=[\u4e00-\u9fa5]\s*[:：])/g,'$1');
const clean=s=>foldGlyphs(s).replace(/[|｜]/g,' ').replace(/\s+/g,' ').trim();
// 键名/标题匹配用：只保留中英数字（去掉图标、装饰符、空白、冒号），英文统一小写（英文简历小节大小写常不统一）
const normKey=s=>clean(s).replace(/[^\u4e00-\u9fa5A-Za-z0-9]/g,'').toLowerCase();
// 键表查找兜底：① 键名带图标/装饰符时按"中英数"规范化匹配；② 仍残留怪异字形的当通配符逐字比
const weirdChar=/[\u2E80-\u2FDF\uF900-\uFAFF]/;
function lookIn(map,raw){
  const k=normKey(raw);if(!k)return null;
  if(map[k]!==undefined)return map[k];
  for(const key in map){if(normKey(key)===k)return map[key]}
  if(!weirdChar.test(k))return null;
  for(const key in map){
    const nk=normKey(key);
    if(nk.length!==k.length)continue;
    let ok=true;
    for(let i=0;i<nk.length;i++)if(nk[i]!==k[i]&&!weirdChar.test(k[i])){ok=false;break}
    if(ok)return map[key];
  }
  return null;
}
const pad=n=>String(n).padStart(2,'0');
// 拆分单元格：Tab 或任意空格序列。中文不用空格分词，所以单个空格通常就是字段分隔符
// 纯分隔符单元格（日期区间里的 - — – ~ 至 等）不是字段值：若混进候选，会被当成"学校/公司/项目名"，
// 还会让 buildEntries 的"同一实体"判断拿 '-' 与 '-' 比较恒等，把同区块后续经历全并进第一条
const SEP_CELL=/^[-—–－~～〜～至到\/／]+$/;
// 冒号后紧跟的空格是"键: 值"的一部分，不能当字段分隔符拆开
// （旧版会把 "意向岗位: 现场管理" 拆成 ["意向岗位:","现场管理"]，两边都匹配不上键值 → 整个求职意向区块丢失）
const splitCells=s=>foldGlyphs(String(s||'')).replace(/([:：])\s+/g,'$1').split(/\t| +/).map(clean).filter(c=>c&&!SEP_CELL.test(c));
// 判断单元格是否"只由日期构成"：剥掉数字/年月日/区间符号/至今后为空才算日期单元格。
// 不能用 /^\d{4}[.\-/年]/ 这种前缀判断——"2025年全国大学生市场调查与分析大赛"会被误判成日期而丢弃
const isDateCell=c=>String(c||'').replace(/[0-9\s.．、,，:：\-—–－~～〜\/／年月日]|至今|现在|目前|present|now|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|to\b/gi,'')==='';
// 日期区间：2024.09-2026.06 / 2024年9月-2026年6月 / 2024-至今
const DATE_RE=/(\d{4})\s*[.\-/年]\s*(\d{1,2})?\s*月?\s*(?:-|—|–|~|～|至|到|to)\s*(?:(\d{4})\s*[.\-/年]\s*(\d{1,2})?\s*月?|(至今|现在|今|目前|present|now))/i;
// 单日期开头（"2024-04 获得院级…"）：后一个数字必须不是年份的延续（"2024-2025学年" 不算单日期）
const ONE_DATE=/^(\d{4})(?:\s*[.\-/年]\s*(\d{1,2})(?!\d)\s*月?|\s*年)?\s*/;
// 英文简历的日期写法（实测 H10）："Sep 2020 - Jun 2024" / "September 2020 – Present"
// 先归一成 "2020.09" / "2020.09 - " 再用同一套 DATE_RE 解析，避免为英文单写一套条目逻辑
const EN_MONTH={jan:'01',feb:'02',mar:'03',apr:'04',may:'05',jun:'06',jul:'07',aug:'08',sep:'09',sept:'09',oct:'10',nov:'11',dec:'12'};
const normEnDates=s=>String(s||'')
  .replace(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+(\d{4})\b/gi,(m,mo,yr)=>yr+'.'+EN_MONTH[mo.slice(0,3).toLowerCase()])
  .replace(/\b(\d{4}\s*[.\-/年]\s*\d{1,2})\s*(?:-|—|–|~|～|至|到|to)\s*(present|now|current|today|date)\b/gi,'$1 - ');
function parseDateRange(src){
  const s=normEnDates(src);
  const m=DATE_RE.exec(s);if(!m)return null;
  const out={};
  if(+m[2]>=1&&+m[2]<=12)out.start=m[1]+'-'+pad(m[2]); else out.start=m[1];
  if(m[3]){if(+m[4]>=1&&+m[4]<=12)out.end=m[3]+'-'+pad(m[4]); else out.end=m[3]}
  else out.ongoing=true;
  return out;
}
// 单一日期值 → 统一成 YYYY-MM（"2021年9月"/"2021.9"/"2021-09" → "2021-09"；只有年份 → "2021"）
const normYM=s=>{const m=String(s).match(/(\d{4})\s*[.\-/年]?\s*(\d{1,2})?\s*月?/);if(!m)return String(s).trim();return(+m[2]>=1&&+m[2]<=12)?m[1]+'-'+pad(m[2]):m[1]};
// 单个日期值 → YYYY-MM-DD（"2001.09.04"/"2001年9月4日" → "2001-09-04"）
const normDate=s=>{const m=String(s).match(/(\d{4})\s*[.\-/年]\s*(\d{1,2})\s*月?\s*[.\-/日]?\s*(\d{1,2})?\s*日?/);
  if(!m)return clean(s);
  let o=m[1];
  if(+m[2]>=1&&+m[2]<=12)o+='-'+pad(m[2]);
  if(m[3]&&+m[3]>=1&&+m[3]<=31)o+='-'+pad(m[3]);
  return o};
// 末尾括号注释（"石家庄铁道大学（省重点）" → "石家庄铁道大学"，"工程管理（国家级特色专业/通过住建部评估）" → "工程管理"）
const stripNote=s=>clean(s).replace(/[（(][^（()）]{1,40}[）)]\s*$/,'').trim();
// 有些 PDF 把同一段文字提取两遍（描边/阴影叠加）→ "新媒体中心新媒体中心" 折叠成一半
const dedup=s=>{const t=clean(s);
  if(t.length>=4&&t.length%2===0&&t.slice(0,t.length/2)===t.slice(t.length/2))return t.slice(0,t.length/2);
  return t};
// "身高体重：178cm/77kg" → height + weight
const HW_RE=/(\d{2,3}(?:\.\d+)?)\s*(?:cm|CM|厘米|公分)?\s*[/、,，]?\s*(\d{2,3}(?:\.\d+)?)\s*(?:kg|KG|公斤|千克)?/;
// 单个"键：值"单元格
function kvOf(cell,group,entry,notes){
  const m=clean(cell).match(/^([^:：]{1,12})[:：]\s*(.+)$/);
  if(!m)return false;
  const key=keys[group]?lookIn(keys[group],m[1].trim()):null;
  if(!key)return false;
  let val=clean(m[2]);
  if(!val)return false;
  if(key==='__hw'){                       // 身高体重合成字段：拆成两项，原字段名不单独成列
    const hw=val.match(HW_RE);
    if(!hw)return false;
    if(!entry.height)entry.height=hw[1]+'cm';
    if(!entry.weight)entry.weight=hw[2]+'kg';
    return true;
  }
  if(key==='birthDate')val=normDate(val);
  // 起止时间字段：把"2021年9月"这类写法归一化；"结束时间：至今"落到 ongoing 而不是当成日期字符串
  if(key==='start'||key==='end'){
    if(/^(至今|现在|目前|今|present|now)$/i.test(val)){if(key==='end'&&!entry.ongoing)entry.ongoing='是';return true}
    val=normYM(val);
  }
  if(entry[key]&&entry[key]!==val){notes.push('同一区块有重复字段，保留首次识别值：'+m[1]);return true}
  entry[key]=val;return true;
}
// 经历区块的条目构建（日期行开新条目；短行作字段；其余进描述）
const ENTITY={education:'school',work:'company',internship:'company',project:'name'};
const SECOND={education:'major',work:'role',internship:'role',project:'role'};
const THIRD ={education:'level',work:null,internship:null,project:null};
// 服役/部队单位名（常被排在"教育背景"里，其实不是学历）；学校名特征
const MIL_RE=/武警|解放军|部队|卫戍|军区|军分区|集团军|参军|入伍|服役|预备役|警备|消防|边防|支队|旅部|连队|团部/;
// 学校名特征：英文简历不写"大学/学院"这类中文词，必须带上英文院校词，
// 否则 school 会被"不像学校"的校验退回描述（实测 H10 的 "Fictional Harbor University" 就是这样丢的）
const SCHOOL_RE=/大学|学院|学校|高级中学|中学|职业技术|中专|技校|University|College|Institute|Academy|Polytechnic|School/i;
function buildEntries(lines,group,notes){
  const out=[];let cur=null,kind='',pendingEnt=null;   // pendingEnt：双栏 PDF 里"日期行在前、实体行在后"时挂起的条目
  const flush=()=>{if(cur&&Object.keys(cur).length)out.push(cur)};
  // 表头被拆成多行的情况（"时间" ⏎ "单位" ⏎ "职位"）：开头连续 ≥3 个表头词整组跳过（少于 3 个不动，避免吃掉正文）
  const HEADWORD=/^(年份|时间|日期|起止时间|起止|起止年月|单位|公司|学校|学院|专业|学历|学位|职位|职位名称|岗位|职务|工作内容|荣誉|奖项名称|证书名称|名称)$/;
  let hs=0;while(hs<lines.length&&HEADWORD.test(clean(lines[hs])))hs++;
  if(hs>=3)lines=lines.slice(hs);
  // 教育专属：一行里"学校 + 专业 + 学历 + 毕业届"混排（"2026 届毕业生\t石家庄铁道大学\t工程管理（国家级特色专业…）"）
  const newEdu=(line,cells)=>{
    const e={};
    const em=line.match(/(\d{4})\s*届/);
    if(em)e.end=em[1];                                    // "2026 届毕业生" → 毕业年份（这一格不再是学校名）
    const rest=cells.filter(c=>{const s=clean(c);
      return s&&!/^\d{4}$/.test(s)&&!/^\d{4}\s*届/.test(s)&&!/^届(毕业生|学生)?$/.test(s)});
    const sc=rest.find(c=>SCHOOL_RE.test(c)&&!MIL_RE.test(c));
    if(sc)e[ENTITY[group]]=dedup(stripNote(sc));
    const lv=THIRD[group]&&rest.find(c=>/^(本科|专科|大专|硕士|研究生|博士|学士|高中)/.test(clean(c)));
    if(lv)e[THIRD[group]]=clean(lv);
    const mj=SECOND[group]&&rest.find(c=>c!==sc&&c!==lv&&!/^\d{4}/.test(clean(c)));
    if(mj)e[SECOND[group]]=stripNote(mj);
    return e;
  };
  for(const raw of lines){
    const line=clean(raw);if(!line)continue;
    // 表格型简历的表头行（"年份 大学及专业 学历"/"时间 单位 职位"）不是经历，跳过；表头也可能连写无空格
    if(line.length<=24&&(/^(年份|时间|日期|起止时间|单位|公司|学校|专业|学历|学位|职位|职位名称|工作内容|经历|奖项名称|证书名称)\s/.test(line)
       ||/^((年份|时间|日期|起止时间|单位|公司|学院|学校|专业|学历|学位|职位|职位名称|岗位|工作内容|荣誉|奖项名称|证书名称)\s*){2,}$/.test(line)))continue;
    const dr=parseDateRange(line);
    // 分格：有"|"竖线的行优先按竖线分（英文简历"职位 | 公司 | 时间"和中文表格都用它分列）——
    // 否则英文实体名会被空格拆成几格（实测 "Fictional Harbor University" → Fictional/Harbor/University）
    const splitRow=s=>{const f=foldGlyphs(String(s||''));return /[|｜]/.test(f)?f.split(/[|｜]/).map(c=>clean(c)).filter(c=>c&&!SEP_CELL.test(c)):splitCells(s)};
    let cells=splitRow(dr?normEnDates(String(raw)).replace(DATE_RE,'\t'):raw);
    // 英文简历里"职位 + 描述"会粘连（"Research InternMaintained sample logs…"）→ 在小写→大写边界拆开（仅纯英文行）
    if(cells.length&&!/[\u4e00-\u9fa5]/.test(cells.join(''))){
      const sp=[];for(const c of cells){for(const x of clean(c).split(/(?<=[a-z])(?=[A-Z][a-z])/))if(x.trim())sp.push(x.trim())}
      cells=sp;
    }
    if(dr){
      const others=cells.filter(c=>!isDateCell(c));
      const ent=others.map(c=>c.replace(/[:：].*$/,'').trim()).filter(Boolean)[0]||'';
      const same=cur&&cur[ENTITY[group]]&&ent&&(cur[ENTITY[group]].includes(ent)||ent.includes(cur[ENTITY[group]]));
      if(cur&&(!others.length||same)){   // 纯日期行／同一实体的重复行 → 并入当前条目，不新建
        if(dr.start&&!cur.start)cur.start=dr.start;
        if(dr.end){if(!cur.end)cur.end=dr.end}else if(dr.ongoing&&!cur.ongoing)cur.ongoing='是';
        if(!others.length)pendingEnt=cur;   // 只有日期、没有实体 → 实体在下一行（双栏 PDF 常见形态）
        continue;
      }
      flush();cur={};
      if(dr.start)cur.start=dr.start;
      if(dr.end)cur.end=dr.end;else if(dr.ongoing)cur.ongoing='是';
      if(!others.length){pendingEnt=cur;continue}   // 纯日期行新建的条目 → 实体在下一行（双栏 PDF 第一段就是这样）
      kind=group==='education'&&others.some(c=>MIL_RE.test(c))?'mil':'';   // 服役经历排在教育区 → 打标记，稍后挪到工作经历
      // 同一行可能同时有"公司 + 职位"（或"学校 + 专业 + 学历"）→ 按顺序分别落到对应字段，不能只取第一个
      let ei=0;
      for(const c of others){
        if(kvOf(c,group,cur,notes))continue;
        if(ei===0&&!cur[ENTITY[group]]){cur[ENTITY[group]]=dedup((group==='education')?stripNote(c):c);ei++}
        else if(ei===1&&SECOND[group]&&!cur[SECOND[group]]){cur[SECOND[group]]=c;ei++}
        else if(ei===2&&THIRD[group]&&!cur[THIRD[group]]){cur[THIRD[group]]=c;ei++}
        else{if(c&&!/[:：]/.test(c))cur.description=(cur.description?cur.description+'\n':'')+c;ei++}   // 多余格当描述，别丢
      }
      continue;
    }
    // 【双栏 PDF】上一行只有日期，这一行才是实体名（"2020.09—2024.06" ⏎ "虚拟沐光大学 | 汉语言文学"）
    // 双栏简历被 pdf.js 按坐标重排后就是这个形态：日期一列、内容一列，逐行拆开了
    if(!dr&&pendingEnt){
      const cs=splitCells(raw).filter(c=>c&&!isDateCell(c));
      if(cs.length){
        if(!pendingEnt[ENTITY[group]])pendingEnt[ENTITY[group]]=dedup(stripNote(cs[0]));
        if(SECOND[group]&&cs[1]&&!pendingEnt[SECOND[group]])pendingEnt[SECOND[group]]=stripNote(cs[1]);
        if(THIRD[group]&&cs[2]&&!pendingEnt[THIRD[group]])pendingEnt[THIRD[group]]=clean(cs[2]);
        cur=pendingEnt;pendingEnt=null;
        continue;
      }
    }
    // 教育区里"学校+专业+毕业届"混排的一行（前面常常还排着服役经历）→ 必须按学校关键词落位，
    // 不能傻取第一个格（否则拿到 school:"2026" / school:"2026届毕业生"）
    if(group==='education'&&kind==='mil'&&cells.some(c=>SCHOOL_RE.test(c)||/\d{4}\s*届/.test(c))){
      flush();cur=newEdu(line,cells);kind='sch';continue;
    }
    // 单日期开头的短行（"2024-04 获得院级计算机技能大赛三等奖"、"2006年\t复旦大学汉语言文学\t本科"）：
    // 日期当起始时间、余下格子按顺序落到实体/角色/学历（表格型简历里很常见）
    const od=ONE_DATE.exec(line);
    if(od&&!/\d{4}\s*届/.test(line)){      // "2026届毕业生…" 是学历行的写法，留给教育分支处理
      const rest=clean(line.slice(od[0].length));
      if(rest.length>=2&&!/^[\-–—]/.test(rest)){
        const ym=od[1]+(od[2]&&+od[2]>=1&&+od[2]<=12?'-'+pad(od[2]):'');
        flush();cur={start:ym};kind='';
        const restCells=splitCells(line.slice(od[0].length)).filter(c=>c&&!isDateCell(c));
        let i2=0;
        for(const c of restCells){
          if(kvOf(c,group,cur,notes))continue;
          if(i2===0&&!cur[ENTITY[group]]){cur[ENTITY[group]]=dedup(c);i2++}
          else if(i2===1&&SECOND[group]&&!cur[SECOND[group]]){cur[SECOND[group]]=c;i2++}
          else if(i2===2&&THIRD[group]&&!cur[THIRD[group]]){cur[THIRD[group]]=c;i2++}
          else i2++;
        }
        if(!cur[ENTITY[group]]&&rest.length<=40)cur[ENTITY[group]]=rest.replace(/[。；;]\s*$/,'');
        continue;
      }
    }
    if(!cur){
      // 先按"键：值"探测（标签式经历逐行给字段）——否则"学校名称：南京工业大学"会被当成学校名
      const probe={};
      if(cells.some(c=>kvOf(c,group,probe,notes))){cur=probe;kind='';continue}
      if(group==='education'&&cells.some(c=>SCHOOL_RE.test(c)||/\d{4}\s*届/.test(c))){
        cur=newEdu(line,cells);kind='sch';continue;
      }
      cur={};kind='';
      const c0=cells[0];if(c0)cur[ENTITY[group]]=dedup(c0);if(cells[1]&&SECOND[group])cur[SECOND[group]]=cells[1];continue}
    if(kvOf(line,group,cur,notes))continue;
    // 短行且不含冒号 → 可能是"专业|学历"或"职位"
    if(SECOND[group]&&!cur[SECOND[group]]&&line.length<=24&&!/[:：]/.test(line)&&!/^(?:[\d(（①②③]|[一二三四五六七八九十]\s*[、.．)）])/.test(line)){
      const seg=String(raw).split(/\t|\s*[|｜/／]\s*|\s{2,}/).map(clean).filter(Boolean);
      cur[SECOND[group]]=seg[0];
      if(seg[1]&&THIRD[group]&&!cur[THIRD[group]])cur[THIRD[group]]=seg[1];
      continue;
    }
    cur.description=(cur.description?cur.description+'\n':'')+line;
  }
  flush();return out;
}
// 把被 PDF 换行截断的句子接回去（如"…毕业设计大赛二" + "等奖、…"）
function joinLines(lines){
  const out=[];
  for(const raw of lines){
    const t=clean(raw);if(!t)continue;
    const prev=out.length?out[out.length-1]:'';
    const prevIsWhole=/[。；;！!？?、，,)）】》〕”"]$/.test(prev)||prev.length<10;
    const lineStartsNew=/\d{4}/.test(t.slice(0,4))||/^[\d(（一二三四五六七八九十①②③]/.test(t);
    if(prev&&!prevIsWhole&&!lineStartsNew)out[out.length-1]=prev+t;
    else out.push(t);
  }
  return out;
}
// ============ 主解析 ============
function parse(text){
  const p={version:2,confirmed:false,basic:{},intent:{},education:[],work:[],internship:[],project:[],language:[],award:[],certificate:[],selfSummary:''};
  const notes=[];
  const raw=String(text||'').replace(/\r/g,'');
  // 全局正则
  const emails=[...new Set(raw.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[])];
  if(emails.length)p.basic.email=emails[0];
  const phones=[...new Set(raw.match(/(?<!\d)1[3-9]\d{9}(?!\d)/g)||[])];
  if(!phones.length){                       // 带分隔符的写法："153-3339-2125"
    const p2=raw.match(/(?<!\d)1[3-9]\d[\s\-]?\d{4}[\s\-]?\d{4}(?!\d)/);
    if(p2)phones.push(p2[0].replace(/[\s\-]/g,''));
  }
  if(phones.length)p.basic.phone=phones[0];
  const ids=[...new Set(raw.match(/(?<![\dXx])\d{17}[\dXx](?![\dXx])/g)||[])];
  if(ids.length){p.basic.idNumber=ids[0];notes.push('识别到疑似身份证号，请核对后再保存')}
  const pol=raw.match(/政治面貌[:：\s]*(中共党员|中共预备党员|共青团员|群众|无党派人士|民主党派)/);
  if(pol)p.basic.politicalStatus=pol[1];
  const lines=raw.split('\n').map(s=>s.trim()).filter(Boolean);
  // 姓名兜底：开头几行里第一个 2~4 字纯中文且非标题；也认"姓名 + 同行其他字段"（"赵佳雪 意向岗位:…"）
  for(const l of lines.slice(0,8)){
    const s=clean(l);
    let cand=null;
    if(/^[\u4e00-\u9fa5·]{2,4}$/.test(s))cand=s;
    else if(/^[\u4e00-\u9fa5·](?:\s[\u4e00-\u9fa5·]){1,3}$/.test(s)){   // 逐字排版："马 金 央"
      const t2=s.replace(/\s+/g,'');
      if(!/大学|学院|公司|学校|专业|简历|个人|应届|本科|专科|经历|工作|技能|证书|荣誉/.test(t2))cand=t2;
    }
    else{
      const m=s.match(/^([\u4e00-\u9fa5·]{2,4})[\s　]+(.+)$/);
      // 只有当后半截确实是字段（带冒号）或是性别标注时，前半截才算"姓名"
      if(m&&(/[:：]/.test(m[2])||/^(男|女)([\s，,]|$)/.test(m[2])))cand=m[1];
    }
    if(cand&&!lookIn(headers,cand)&&!lookIn(keys.basic,cand)){p.basic.name=cand;break}
  }
  // 分组遍历
  let group='basic',buf=[];
  const cross={};   // 基本信息区里出现的"其实属于其他组"的键值（如"毕业院校：X"实际属于教育经历）
  const flushGroup=()=>{
    if(!buf.length)return;
    if(group==='honor'||group==='summary'||group==='skills')buf=joinLines(buf);   // 仅对纯文本段落做断行接续，结构化区块不能合并
    if(group==='basic'||group==='intent'||group==='honor'||group==='summary'||group==='skills'){
      if(group==='intent'){for(const l of buf)for(const c of splitCells(l))kvOf(c,group,p[group],notes)}
      else if(group==='basic'){
        const flat=[];
        for(const l of buf)for(const c of splitCells(l))flat.push(c);
        // 纯字段名（可落到任意组的键）→ 目标位置
        const targetOf=s=>{
          const k=clean(s);if(!k||/[:：]/.test(k))return null;
          if(keys.basic[k])return{g:'basic',k:keys.basic[k]};
          for(const g of Object.keys(keys)){if(g==='basic'||g==='intent')continue;if(keys[g][k])return{g,k:keys[g][k]}}
          return null;
        };
        for(let i=0;i<flat.length;i++){
          const c=flat[i];
          if(!/^[^:：]{1,12}[:：]/.test(clean(c)))continue;
          if(kvOf(c,group,p[group],notes))continue;
          // 本组没有这个字段名 → 看看是不是别的组的字段（基本信息区里常混着"毕业院校/所学专业/公司名称"）
          const m=clean(c).match(/^([^:：]{1,12})[:：]\s*(.+)$/);
          if(!m)continue;              // "标签：" 后没有值（竖排键值的标签行）→ 跳过；否则下面 m[1] 会抛异常
          const lb=m[1].trim();
          for(const g of Object.keys(keys)){
            if(g==='basic')continue;   // basic 上一行已处理；intent 必须放行——真实简历常把"意向岗位/期望薪资"写在基本信息区，排除它会让这些内容整行丢失
            const k2=lookIn(keys[g],lb);
            if(k2){const box=cross[g]=cross[g]||{};if(!box[k2])box[k2]=clean(m[2]);break}
          }
        }
        // "赵晴，性别：女 | 13800000006 | a@example.com" —— 真实简历常把姓名和其他信息挤在同一行，
        // 这种行整体结构是乱的，但行首那个"姓名 + 分隔符"是可靠的：姓名缺失时先把它摘出来（用黑名单挡住"性别/民族"等标签词）
        if(!p.basic.name){
          const NAMEBAD=/^(性别|民族|身高|体重|年龄|电话|手机|邮箱|政治|面貌|籍贯|住址|地址|学历|专业|学校|毕业|姓名|出生|婚姻|现居|求职|意向|期望|联系|个人|基本|简介|自我)$/;
          const nmh=(()=>{for(const l of buf){const m2=clean(l).match(/^([\u4e00-\u9fa5·]{2,4})\s*[，,、|｜/\\\s]/);if(m2&&!NAMEBAD.test(m2[1]))return m2}return null})();
          if(nmh)p.basic.name=nmh[1];
          else{
            // 英文姓名（"Lin An"）：整行只有 2~3 个首字母大写的英文词、无数字 —— 英文简历首页首行常见
            const enh=(()=>{for(const l of buf){const m2=clean(l).match(/^([A-Z][a-z]{1,15}(?:\s+[A-Z][a-z]{1,15}){1,2})$/) ;if(m2)return m2}return null})();
            if(enh)p.basic.name=enh[1].replace(/\s+/g,' ');
          }
        }
        // 竖排键值：标签自成一格（不带冒号）、值在下一格 —— Word 表格简历逐格导出常见写法
        // （性别/女、籍贯/山东省济南市）。连续两个以上纯标签视为"标签列"，列序无从判断 → 整段不配对，宁缺勿错
        const runs=[];let open=-1;
        for(let i=0;i<flat.length;i++){
          if(targetOf(flat[i])){if(open<0){open=i;runs.push([i,i])}else runs[runs.length-1][1]=i}
          else open=-1;
        }
        for(const [a,b] of runs){
          if(a!==b)continue;
          const t=targetOf(flat[a]);
          const v=a+1<flat.length?clean(flat[a+1]):'';
          if(!t||!v||v.length>30)continue;
          if(/[:：]/.test(v)||targetOf(v))continue;                       // 值本身是"键：值"或另一个字段名 → 不是竖排值
          if(headers[v.replace(/[\s:：]/g,'')])continue;                  // 值是章节标题 → 不是值
          if(t.g==='basic'){if(!p[group][t.k])p[group][t.k]=v}
          else{const box=cross[t.g]=cross[t.g]||{};if(!box[t.k])box[t.k]=v}
        }
      }
      else if(group==='honor'){collectHonor(buf,p)}
      else if(group==='skills'){p.basic.skills=(p.basic.skills?p.basic.skills+'\n':'')+buf.map(clean).filter(Boolean).join('\n')}
      else if(group==='summary'){p.selfSummary=(p.selfSummary?p.selfSummary+'\n':'')+buf.map(clean).join('')}
    }else if(['education','work','internship','project'].includes(group)){
      const es=buildEntries(buf,group,notes);for(const e of es)p[group].push(e);
    }else if(group==='language'||group==='award'||group==='certificate'){
      // 同一落点、逐行给字段（语言类型：英语 / 掌握程度：熟练）要合成一条，不能各推一条
      let acc=null;
      const flush=()=>{if(acc&&Object.keys(acc).length)p[group].push(acc);acc=null};
      const PROF=/^(母语|精通|熟练|流利|良好|较好|一般|入门|了解|英语[四六]级|CET[- ]?[46]|专业[八四级]|雅思|托福|IELTS|TOEFL)/i;
      // 列表项入档：清洗名称（去"服役相关："这类归类前缀/动词/赘尾，抽末尾年份）后各成一条
      const pushItem=raw=>{const it=tidyItem(raw);
        if(!it.name||it.name.length>40||/[。；;]/.test(it.name))return;   // 像句子的不像证书/奖项名
        flush();acc={name:it.name};if(it.date)acc.date=it.date;if(it.level)acc.level=it.level};
      for(const l of buf){
        // 纯英文行整行当一项：英文奖项/证书名含空格，按空格分格会被拆碎（实测 "Campus Research Award" → 3 条）
        const en=l&&/[A-Za-z]/.test(l)&&!/[\u4e00-\u9fa5]/.test(l);
        for(const c of (whole||en?[clean(l)]:splitCells(l))){
          if(!c)continue;
          // 顿号/逗号分隔的多项：拆开，每项各自成条
          const dc=clean(c).match(/^(\d{4})\s*[.\-/年]\s*(\d{1,2})?\s*月?$/);
          if(dc){                                          // 光秃秃的日期行是上一条的时间（"单项奖学金" + "2025/03"）
            if(acc&&!acc.date)acc.date=dc[2]&&+dc[2]>=1&&+dc[2]<=12?dc[1]+'-'+pad(dc[2]):dc[1];
            continue;
          }
          // 顿号/逗号分隔的多项：拆开，每项各自成条（语言能力不拆——"英语，听说读写良好" 是一句话）
          if(group!=='language'&&!/[:：]/.test(c)&&/[、,，;；]/.test(c)){for(const t of splitItems(c))pushItem(t);continue}
          const tmp={};
          if(kvOf(c,group,tmp,notes)){
            if(tmp.name&&acc&&acc.name&&acc.name!==tmp.name)flush();
            if(!acc)acc={};
            for(const k in tmp)if(acc[k]==null)acc[k]=tmp[k];
            continue;
          }
          const t=clean(c);
          if(/[:：]/.test(t))continue;                       // 带冒号但键不认识 → 不猜
          if(group==='language'&&acc&&acc.name&&PROF.test(t)){if(!acc.proficiency)acc.proficiency=t;continue}
          // 裸列表项（无冒号、无顿号）→ 旧版整条丢弃，这里清洗后当名称入档
          pushItem(t);
        }
      }
      flush();
    }
    buf=[];
  };
  // 把若干行交给「另一个组」的规则去解析（区块内部常混入跨组内容：
  // 教育经历区里的"荣誉奖项：A、B、C"、校园经历区里的"具有 C1 驾驶证、…证书、…"）
  const routeTo=(lines,g)=>{const sg=group,sb=buf;group=g;buf=lines.slice();flushGroup();group=sg;buf=sb};
  let whole=false;   // 整句清单（"具有 C1 驾驶证、…"）：不按空格拆格，只在顿号/逗号处拆
  const routeWhole=(txt,g)=>{whole=true;routeTo([txt],g);whole=false};
  const INLINE_LIST=['honor','award','certificate','skills','summary','language','intent'];
  const isHeadInline=t=>!!lookIn(headers,t.replace(/[\s:：]/g,''));
  // 整份简历是否"一个已知章节标题都没有" → 只有这种简历才启用"按内容特征分流"（见下方 noHeaderDoc 用法）
  const noHeaderDoc=!lines.some(l=>!!lookIn(headers,clean(l).replace(/[\s:：]/g,'')));
  for(let i=0;i<lines.length;i++){
    const t0=clean(lines[i]),bare=t0.replace(/[\s:：]/g,'');
    const h=lookIn(headers,bare);
    if(h){flushGroup();group=h;continue}
    // 模糊标题：没收录但明显是章节名（"主要证书及荣誉奖项"、"社团和组织经历"、"汉语教学"…）
    // → 不处理的话整块内容会留在上一个组里（实测：中文模板简历的 15 条经历全堆进 education）
    if(!h&&!/[:：]/.test(t0)&&bare.length<=14&&!lookIn(keys.basic,bare)){
      // ⚠️ 标题形状护栏（2026-09-12 修的真 bug）：下面这些规则原本只看"包含关键词 + 够短"，
      // 结果**描述里的一句话**会被当成章节标题——实测「获得95%满意度评价」含"评价"且长度≤10，
      // 被判成"自我评价"标题 → flushGroup 把组切到 summary → 后面 2 段实习**整块消失**（用户报"信息不完全"）。
      // 真标题不会以动词/数字/标点开头，也不含列表编号；据此排除句子。
      const NOT_HEADER=/^(获得|荣获|取得|参与|负责|完成|主导|协助|独立|通过|根据|掌握|熟练|具备|能够|使用|运用|利用|结合|配合|实现|累计|同时|另外|此外|担任|组织|策划|维护|编写)|[\d，。；、：%]/.test(bare);
      // 每条都要求"目标组 ≠ 当前组"——否则证书名本身（"工程识图培训证书"）会被当成标题丢掉
      if(!NOT_HEADER&&/(证书|资质|资格).*(荣誉|奖项|奖励)|(荣誉|奖项|奖励).*(证书|资质)/.test(bare)&&group!=='honor'){flushGroup();group='honor';continue}
      if(!NOT_HEADER&&/(奖励|荣誉|奖项|获奖)/.test(bare)&&bare.length<=8&&group!=='honor'&&group!=='award'){flushGroup();group='honor';continue}
      if(/^(主要)?(荣誉|获奖|奖项|奖励)(情况|记录|列表)?$/.test(bare)&&group!=='award'&&group!=='honor'){flushGroup();group='award';continue}
      if(/^(主要)?(证书|资格|资质)(情况|记录|列表)?$/.test(bare)&&group!=='certificate'){flushGroup();group='certificate';continue}
      if(!NOT_HEADER&&/(证书|资格证|执照|驾照)/.test(bare)&&bare.length<=8&&group!=='certificate'){flushGroup();group='certificate';continue}
      if(!NOT_HEADER&&/(技能|能力|特长|专长)/.test(bare)&&bare.length<=10&&group!=='skills'){flushGroup();group='skills';continue}
      if(!NOT_HEADER&&/(自我|评价|描述|总结|优势|简介|感悟)/.test(bare)&&bare.length<=10&&group!=='summary'){flushGroup();group='summary';continue}
      // 经历类：只认「以关键词结尾」的短行（标题的真实特征："汉语教学"/"活动组织及工作经验"/"项目经历"）
      // 不能用"包含"也不能用"开头"——实测「项目部技术岗」两种都会误判，把整段实习切走
      if(bare.length<=12&&group!=='project'&&!/(岗|职位|公司|集团|团队|中心|部门)/.test(bare)
         &&/(经历|经验|实践|履历|教学|培训|社团|组织|志愿|竞赛|课题)$/.test(bare)){
        flushGroup();group='project';continue;
      }
    }
    // 表格简历常把多个"键：值"塞进同一行（"意向岗位：工程造价 意向城市：青岛 期望薪资：8000元/月"）——
    // 整行喂进去会因"值里又冒出一个冒号"被当脏数据丢掉，先按"空格 + 2~10 字 + 冒号"切成多行分别处理。
    // 必须放在下面"行内小标题"判断之前：否则整行会被小标题分支按"键：值"吃掉，拆不出来
    if(/[：:]/.test(t0)){
      const segs=t0.split(/(?<=\S)\s+(?=[^\s：:]{2,10}[：:])/).filter(s=>s.trim());
      if(segs.length>1){for(const s of segs)buf.push(s);continue}
    }
    const m=t0.match(/^([^:：]{2,10})[:：]\s*(.+)$/);
    if(m){
      const lb=m[1].trim();
      const h2=lookIn(headers,lb);                    // 行内小标题："荣誉奖项：…" / "专业技能：…"
      if(h2&&h2!==group&&INLINE_LIST.includes(h2)){
        // PDF 常把一条奖项截成两行（"…第十一届全国大学生 BIM" + "毕业设计创新大赛优秀奖"）→ 先接回去。
        // 但续行判定必须保守：带 tab 的表格行、含日期的行、编号行都不是续行（否则会把后面整段经历吞进来）
        let txt=m[2],added=0;
        while(!/[。；;！!？?）)】》]\s*$/.test(txt)&&i+1<lines.length&&added<2){
          const raw=lines[i+1],nx=clean(raw);
          if(!nx||isHeadInline(nx)||/[:：]/.test(nx)||nx.length>40)break;
          if(/\t/.test(raw)||/\d{4}/.test(nx)||/^[\d•·]/.test(nx))break;
          txt+=nx;i++;added++;
        }
        // 注意：这里不能 flushGroup()——那会把当前经历区块的 buf 切断，
        // 导致后面的描述行变成新条目（实测：李陆军"跨部门协作: …"被切成空壳条目）
        if(h2==='intent')routeTo([lines[i]],'intent');  // 求职意向要保留"键：值"原样才能落字段
        else routeWhole(txt,h2);                        // 语言/技能等整句，不按空格拆格
        continue;
      }
      const kb=lookIn(keys.basic,lb);                 // 经历区里的基本信息字段："现居：河北省邯郸市"
      if(kb&&group!=='basic'){routeTo([lines[i]],'basic');continue}
      // 技能/经历区里混着的证书与荣誉行："4. 相关证书 ：大学英语四级、…"、"5. 在校荣誉：二等奖学金（3次）"
      const lbn=normKey(lb.replace(/^\d+\s*[.、)）]\s*/,''));
      if(/^(相关证书|证书|证书情况|资质证书|资格证书|语言证书|证书与荣誉)$/.test(lbn)&&group!=='certificate'){
        routeWhole(m[2],'certificate');continue;
      }
      if(/^(在校荣誉|荣誉|荣誉情况|获奖情况|所获奖励|奖励情况|获奖记录)$/.test(lbn)&&group!=='award'&&group!=='honor'){
        routeWhole(m[2],'honor');continue;
      }
    }
    // 单日期开头的"获奖/证书"行："2024-04 获得院级计算机技能大赛三等奖；" → 归奖项/证书，而不是当项目名
    if(group!=='award'&&group!=='honor'&&group!=='certificate'){
      const od2=t0.match(/^(\d{4})\s*[.\-/年]\s*(\d{1,2})?\s*月?\s*(.+)$/);
      if(od2&&od2[3].length>=4){
        const rest2=od2[3].replace(/^[，,、。;；:：\s]+/,'');
        if(/(获得|荣获|获评|评为|取得).{0,24}(奖|称号|荣誉)/.test(rest2)){routeWhole(rest2,'award');continue}
        if(/(证书|结业证|资格证|执照|驾照)/.test(rest2)){routeWhole(rest2,'certificate');continue}
      }
    }
    // 整句证书清单："具有 C1 驾驶证、普通话二甲证书、…、献血证等"
    if(group!=='certificate'&&/^(具有|持有|拥有|取得|获得)/.test(t0)&&/(证|认证|驾照|执照)/.test(t0)
       &&/[、,，]/.test(t0)&&t0.length<=160){routeWhole(t0,'certificate');continue}
    // 表格简历常把多个"键：值"塞进同一行（"意向岗位：工程造价 意向城市：青岛 期望薪资：8000元/月"）——
    // 整行喂进去会因"值里又冒出一个冒号"被当脏数据丢掉，先按"空格 + 2~10 字 + 冒号"切成多行分别处理
    if(/[：:]/.test(t0)){
      const segs=t0.split(/(?<=\S)\s+(?=[^\s：:]{2,10}[：:])/).filter(s=>s.trim());
      if(segs.length>1){for(const s of segs)buf.push(s);continue}
    }
    // 通篇没有章节标题的简历（实测 H06：整份只解析出 2 个字段、其余全丢）：按"日期区间 + 实体特征"分流。
    // 仅在"整份简历一个已知标题都没有"时启用 → 有标题的正常简历完全不受影响（实测放宽后会抢走实习条目）
    if(noHeaderDoc&&!/[:：]/.test(t0)&&parseDateRange(t0)){
      const isSchool=/(大学|学院|学校|中学|研究所|职业技术)/.test(t0);
      const isCorp=/(公司|集团|事务所|工作室|银行|医院|酒店|工厂)/.test(t0);
      // 切组前先 flushGroup()：否则已经攒在 buf 里的基本信息内容会被冲进 education（实测成了垃圾条目）
      if(isSchool&&group!=='education'){flushGroup();group='education';buf.push(lines[i]);continue}
      if(isCorp&&group!=='work'){flushGroup();group='work';buf.push(lines[i]);continue}
    }
    buf.push(lines[i]);
  }
  flushGroup();
  // 跨组键值归位：经历类并入第一条（不覆盖已有），列表类各自成为一条
  for(const g in cross){
    if(g==='intent'||g==='basic'){
      // 单对象组（求职意向/基本信息）：直接补字段，不覆盖已有值。
      // 实测缺这一步会让"意向岗位：工程造价 意向城市：青岛"这类行整行掉进"未归位内容"
      for(const k in cross[g])if(!p[g][k])p[g][k]=cross[g][k];
    }else if(['education','work','internship','project'].includes(g)){
      if(!p[g].length)p[g].push({});
      for(const k in cross[g])if(!p[g][0][k])p[g][0][k]=cross[g][k];
    }else if(['language','award','certificate'].includes(g)){
      const e={};for(const k in cross[g])e[k]=cross[g][k];
      if(Object.keys(e).length)p[g].push(e);
    }
  }
  // 服役/部队经历常被排在"教育背景"里（有日期、名字像单位）→ 不是学历：挪到工作经历并留提示
  const movedEdu=[];
  p.education=p.education.filter(e=>{
    if(e.school&&MIL_RE.test(e.school)){movedEdu.push(e);return false}
    return true;
  });
  if(movedEdu.length){
    for(const e of movedEdu){                  // 字段名随组转换：教育用 school/major，工作用 company/role
      const c={...e};
      if(c.school){c.company=c.school;delete c.school}
      if(c.major){c.role=c.major;delete c.major}
      delete c.level;
      p.work.push(c);
    }
    notes.push('识别到疑似服役/部队经历 '+movedEdu.length+' 段，已归入工作经历，请核对');
  }
  // "语言技能"区里常混着证书（"英语四级证书（528）"）→ 按内容归到证书
  const langCert=[];
  p.language=p.language.filter(e=>{
    if(e.name&&/证书|驾照|执照|资格|等级|鉴定|普通话|计算机/.test(e.name)){langCert.push(e);return false}
    return true;
  });
  if(langCert.length)p.certificate.push(...langCert);
  // 教育条目的 school 必须是"像学校"的名字，否则"外语能力：…"这类段落会被当成校名
  for(const e of p.education){
    if(e.school&&!SCHOOL_RE.test(e.school)){
      e.description=((e.school||'')+(e.description?'\n'+e.description:'')).trim();
      delete e.school;
    }
  }
  // 工作/实习/项目的"名称"若其实是整段话（"课程设计：本科期间，完成了…"）→ 退回描述，避免名称被污染
  for(const g of ['work','internship','project']){
    const k=ENTITY[g];
    for(const e of p[g]){
      const v=e[k];
      if(v&&(v.length>36||/[。；;]/.test(v)||(/[:：]/.test(v)&&v.length>16))){
        e.description=((v)+(e.description?'\n'+e.description:'')).trim();delete e[k];
      }
    }
  }
  // 从教育经历补"最高学历"；简历正文明确写了"应届"才补应届标识（不按年份推断）
  if(!p.basic.highestLevel){const lv=p.education.map(e=>e.level).find(Boolean);if(lv)p.basic.highestLevel=lv}
  if(!p.basic.graduateType&&/应届/.test(raw))p.basic.graduateType='应届';
  // 防御：单人档案的奖项/证书/语言不会有几百条 —— 学术 CV 的出版物列表会被逐行拆成上千条，直接把面板拖死
  for(const g of ['award','certificate','language']){
    if(p[g].length>120){
      notes.push('「'+g+'」识别到 '+p[g].length+' 条（疑似出版物/列表型小节），已保留前 120 条，请核对');
      p[g]=p[g].slice(0,120);
    }
  }
  // 兜底保险：解析完仍没进任何字段的实质内容行 → 收进 p.unfiled（原文摘录，不做任何猜测），
  // 保证"信息不丢"：排版再怪的简历，用户也能在档案里看到并复制这部分内容
  try{
    const nz=s=>foldGlyphs(String(s||'')).replace(/[\s\p{P}\p{S}]/gu,'');
    const vals=[];
    (function walk(o){
      if(typeof o==='string')vals.push(o);
      else if(Array.isArray(o))o.forEach(walk);
      else if(o&&typeof o==='object')for(const k in o)if(k!=='version'&&k!=='confirmed')walk(o[k]);
    })(p);
    const filed=nz(vals.join(''));
    const cset=new Set(filed), ng=4, gs=new Set();
    for(let i=0;i+ng<=filed.length;i++)gs.add(filed.slice(i,i+ng));
    const unfiled=[];
    // 判定时剥掉"键名"部分：档案里存的是值，键名（"意向岗位""期望薪资"）本来就不该出现，留着会把已归位的行误判成未归位
    const stripKeys=s=>s.replace(/[^：:\s]{1,12}[：:]\s*/g,'');
    for(const rawLine of raw.split('\n')){
      const line=clean(rawLine), nl=nz(stripKeys(line));
      if(nl.length<6)continue;
      // 判定"这行是否已进档案"：字符覆盖率 ≥0.75（容忍同一行的内容被拆到不同字段）且存在 ≥4 字连续片段
      // 只按整行 6-gram 判会把"意向岗位：工程造价 意向城市：青岛"这种已归位的行误收进来（值被拆开存放，跨值的 gram 对不上）
      let inSet=0;for(const ch of nl)if(cset.has(ch))inSet++;
      let hasChunk=false;const n=Math.min(ng,nl.length);
      for(let i=0;i+n<=nl.length&&!hasChunk;i++)if(gs.has(nl.slice(i,i+n)))hasChunk=true;
      if(!(inSet/nl.length>=0.75&&hasChunk))unfiled.push(line);
    }
    if(unfiled.length)p.basic.unfiled=unfiled.slice(0,300).join('\n');
  }catch(e){}
  if(p.selfSummary)p.basic.selfDescription=p.selfSummary;
  delete p.selfSummary;
  // 清理 & 计数
  for(const g of Object.keys(p))if(Array.isArray(p[g]))p[g]=p[g].filter(x=>Object.keys(x).length);
  const count=Object.values(p.basic).filter(Boolean).length
    +Object.values(p.intent).filter(Boolean).length
    +['education','work','internship','project','language','award','certificate'].reduce((n,g)=>n+p[g].reduce((a,e)=>a+Object.keys(e).length,0),0);
  return{profile:p,count,notes};
}
// 荣誉/证书混排：按"、"拆分，清洗后按"证书类字样优先、否则奖项"归类
function splitItems(s){return String(s||'').split(/[、,，;；]/).map(clean).filter(Boolean)}
// 列表项清洗：去掉"服役相关："/"学业与竞赛："这类归类前缀、"具有/持有"这类动词、"等"这类赘尾，
// 并把末尾括号里的年份抽成 date（"普通话二级甲等（2025）" → name+date）
function tidyItem(raw){
  let t=clean(raw);
  const lm=t.match(/^([^:：]{2,10})[:：]\s*(.+)$/);
  if(lm&&!/^(获得时间|取得时间|证书名称|奖项名称|获奖名称|颁发|等级|成绩)/.test(lm[1]))t=clean(lm[2]);
  t=t.replace(/^(具有|持有|拥有|取得|获得|本人|荣获)\s*/,'')
     // 只删真正是清单赘尾的"等"（"献血证等。"），保住等级词（"普通话二级甲等" —— 删了就成了残证名）
     .replace(/(证书|证明|证|奖项|奖|称号|荣誉|资格|执照|驾照)\s*等\s*$/,'$1')
     .replace(/[。；;、,，]\s*$/,'').trim();
  t=dedup(t);
  let date,level;
  // 末尾括号：四位年份 → date；考试分数/等级 → level（"英语四级证书（528）"、"计算机证书（高级）"）
  const dm=t.match(/^(.*?)[（(]\s*(\d{4})\s*(?:[.\-/年]\s*(\d{1,2}))?\s*[）)]\s*$/);
  if(dm&&clean(dm[1])){t=clean(dm[1]).replace(/[。；;、,，]\s*$/,'');date=dm[3]?dm[2]+'-'+pad(dm[3]):dm[2]}
  else{
    const lm2=t.match(/^(.*?)[（(]\s*([^（()）]{1,12})\s*[）)]\s*$/);
    const inner=lm2?clean(lm2[2]):'';
    if(lm2&&clean(lm2[1])&&(/^\d{2,3}(?:\.\d+)?$/.test(inner)||/^(高级|中级|初级|一级|二级|三级|优秀|良好|合格)$/.test(inner))){
      t=clean(lm2[1]).replace(/[。；;、,，]\s*$/,'');level=inner;
    }
  }
  // 光秃秃的日期/页码/单字不是证书或奖项名（"2025/03"、"- 1 -"、"1"）→ 丢弃
  if(!t||t.length<2||/^[\d\s.\-/()（）年月日]+$/.test(t)||/^第?\s*\d+\s*页?$/.test(t))return{name:''};
  return{name:t,date,level};
}
// 归类：有"证书/执照/认证/等级/鉴定"这类字样的算证书；否则含"奖/荣誉/优秀"的算奖项
function classifyItem(t){
  if(/证书|执照|驾照|驾驶证|认证|资格|鉴定|等级|级别|献血证|英语[四六]级|计算机|普通话/.test(t))return 'certificate';
  if(/奖|荣誉|称号|优秀|标兵|先进|模范/.test(t))return 'award';
  return 'certificate';
}
function collectHonor(buf,p){
  for(const l of buf)for(const piece of splitItems(l)){
    const it=tidyItem(piece);
    if(!it.name||it.name.length>40)continue;
    // 荣誉段落里常混着效果描述（"有效提升学院品牌影响力"）→ 明显是效果句且不含荣誉/证书词的丢弃
    if(/^(有效|显著|极大|大幅|进一步)?(提升|提高|增强|促进|帮助|加强|优化|完善)/.test(it.name)
       &&!/奖|荣誉|称号|证书|证|资格|认证|执照/.test(it.name))continue;
    const e={name:it.name};if(it.date)e.date=it.date;if(it.level)e.level=it.level;
    (classifyItem(it.name)==='award'?p.award:p.certificate).push(e);
  }
}
root.ResumeParser={parse,parseDateRange,splitCells,foldGlyphs};
})(globalThis);
