import * as pdfjs from './vendor/pdf.min.mjs';
pdfjs.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdf.worker.min.mjs',import.meta.url).href;
const q=s=>document.querySelector(s);let draft=null,weakText='';
// 按坐标重排 PDF 文本，还原视觉阅读顺序（表格/分栏简历必须这么做，否则文字顺序是乱的）
function reflow(items){
  const TOL=4, COL_GAP=45, SP_GAP=3;   // SP_GAP 要小于 PDF 里半角空格的宽度（约5px），否则 "日期 公司 职位" 会粘成一串
  const its=[];
  for(const it of items){
    if(!it.str||!it.str.trim())continue;
    const tr=it.transform||[];const x=tr[4]||0,y=tr[5]||0;
    its.push({s:it.str,x,y,w:it.width||0});   // pdf.js 的 width 已是实际宽度，不要再乘缩放系数
  }
  its.sort((a,b)=>(b.y-a.y)||(a.x-b.x));          // PDF 的 y 越大越靠上
  const rows=[];
  for(const it of its){
    const last=rows[rows.length-1];
    if(last&&Math.abs(last.y-it.y)<=TOL)last.items.push(it);
    else rows.push({y:it.y,items:[it]});
  }
  const out=[];
  for(const r of rows){
    r.items.sort((a,b)=>a.x-b.x);
    let line='',prevEnd=null;
    for(const it of r.items){
      if(prevEnd!==null){const gap=it.x-prevEnd;if(gap>COL_GAP)line+='\t';else if(gap>SP_GAP)line+=' '}
      line+=it.s;prevEnd=it.x+it.w;
    }
    const s=line.replace(/\s+$/,'');
    if(s)out.push(s);
  }
  return out.join('\n');
}
function show(){const text=q('#resumeText').value;if(text.length>100000){q('#resumeStatus').textContent='文字过长，请保留10万字以内的简历正文。';return}const r=ResumeParser.parse(text);draft=r.profile;q('#resumeStatus').textContent=`识别到 ${r.count} 个候选字段。只识别明确标注和常见联系方式，请逐项核对；复杂排版、多段经历可能遗漏。`+(r.notes.length?' '+r.notes.join('；'):'')+(weakText?' '+weakText:'');q('#resumePreview').textContent=Object.entries(draft).filter(([g])=>SCHEMA[g]).flatMap(([g,v])=>(Array.isArray(v)?v:[v]).flatMap((entry,i)=>Object.entries(entry).map(([k,value])=>(labels[g]|| (g==='basic'?'个人信息':'求职意向'))+(Array.isArray(v)?' '+(i+1):'')+' · '+(SCHEMA[g].find(x=>x[0]===k)?.[1]||k)+'：'+value))).join('\n');q('#applyResume').disabled=!r.count;q('#resumeReview').hidden=false;}
q('#readResume').onclick=show;
q('#resumeFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;draft=null;q('#applyResume').disabled=true;q('#resumeReview').hidden=true;q('#resumeText').value='';q('#resumeStatus').textContent='正在本地读取文件…';try{if(f.size>10*1024*1024)throw Error('文件超过10MB，请先缩小文件。');const ext=f.name.split('.').pop().toLowerCase();let text='';weakText='';if(ext==='txt')text=await f.text();else if(ext==='docx'){const zip=await JSZip.loadAsync(await f.arrayBuffer());const item=zip.file('word/document.xml');if(!item)throw Error('文件不是有效的Word文档。');if(item._data?.uncompressedSize>5*1024*1024)throw Error('文档正文过大。');const xml=await item.async('string');if(xml.length>5000000)throw Error('文档正文过大。');const doc=new DOMParser().parseFromString(xml,'application/xml');if(doc.querySelector('parsererror'))throw Error('Word正文无法解析。');[...doc.getElementsByTagNameNS('*','Fallback')].forEach(el=>el.parentNode&&el.parentNode.removeChild(el));text=[...doc.getElementsByTagNameNS('*','p')].map(p=>[...p.getElementsByTagNameNS('*','t')].map(n=>n.textContent).join('')).join('\n');}else if(ext==='pdf'){const task=pdfjs.getDocument({data:new Uint8Array(await f.arrayBuffer()),isEvalSupported:false,useSystemFonts:true,cMapUrl:new URL('./vendor/cmaps/',import.meta.url).href,cMapPacked:true});let doc;try{doc=await task.promise;if(doc.numPages>30)throw Error('请导入30页以内的简历。');const pages=[],pstat=[];for(let i=1;i<=doc.numPages;i++){const page=await doc.getPage(i);const content=await page.getTextContent();const t=reflow(content.items);pages.push(t);const chars=t.replace(/\s/g,'').length;const c=(t.match(/[\u4e00-\u9fa5]/g)||[]).length;pstat.push([i,chars,c]);}text=pages.join('\n');const cjk=(text.match(/[\u4e00-\u9fa5]/g)||[]).length;if(cjk<50)weakText='这份 PDF 只识别到 '+cjk+' 个汉字（字体未嵌入编码表时常见），中文正文可能读不到，建议改用 DOCX 或把正文粘贴进来核对。';else{const bad=pstat.filter(x=>x[1]>200&&x[2]/x[1]<0.05).map(x=>x[0]);if(bad.length)weakText='第 '+bad.join('、')+' 页几乎没读出中文（该页字体编码可能没映射上），这一页的内容可能不完整——建议改用 DOCX，或把该页正文粘贴进来核对。'}}finally{await task.destroy();}}else throw Error('请使用PDF、DOCX或TXT；旧版DOC请另存为DOCX。');if(!text.trim())throw Error('未找到可读取文字。扫描版PDF请先转成文字，或直接粘贴正文。');if(text.length>100000)throw Error('提取的文字超过10万字，请缩短文档。');q('#resumeText').value=text;show();}catch(err){q('#resumeStatus').textContent='读取未完成：'+err.message}finally{e.target.value=''}};
q('#applyResume').onclick=()=>{if(!draft)return;const current=collect();for(const [k,v]of Object.entries(draft.basic))if(!current.basic[k])current.basic[k]=v;for(const [k,v]of Object.entries(draft.intent||{}))if(!current.intent[k])current.intent[k]=v;for(const g of ['education','work','internship','project','language','award','certificate'])if(!current[g].length)current[g]=draft[g];
// 最高学历：按教育经历里的等级取最高的一项（可在下方核对修改）
if(!current.basic.highestLevel){const rank=['博士后','博士','博士研究生','硕士','硕士研究生','本科','大学本科','本科生','大专','专科','高职','高中','中专'];let best='',bi=99;for(const e of (draft.education||[])){const i=rank.indexOf(String(e.level||'').trim());if(i>=0&&i<bi){bi=i;best=e.level}}if(best)current.basic.highestLevel=best}
current.confirmed=false;render(current);dirty();q('#resumeStatus').textContent='已填入档案空白处，已有内容保留。请检查下方档案并保存。';q('#basic').scrollIntoView({behavior:'smooth'});};
