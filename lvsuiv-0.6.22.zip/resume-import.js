import * as pdfjs from './vendor/pdf.min.mjs';
pdfjs.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdf.worker.min.mjs',import.meta.url).href;
const q=s=>document.querySelector(s);let draft=null,weakText='';
// 授权门禁（买断版功能）：未激活不解析——提示语必须指向上面那张「授权」卡，别让用户以为解析坏了
const needLicense=async()=>{let ok=false;try{ok=await window.LvLicense.can('parse')}catch(e){ok=false}if(ok)return false;
  const st=q('#resumeStatus');if(st)st.textContent='未激活：请先在上面「授权」里完成激活，再导入简历。';return true};
// 按坐标重排 PDF 文本，还原视觉阅读顺序（表格/分栏简历必须这么做，否则文字顺序是乱的）
function reflow(items){
  const TOL=4, COL_GAP=45, SP_GAP=3;   // SP_GAP 要小于 PDF 里半角空格的宽度（约5px），否则 "日期 公司 职位" 会粘成一串
  const its=[];
  for(const it of items){
    if(!it.str||!it.str.trim())continue;
    const tr=it.transform||[];const x=tr[4]||0,y=tr[5]||0;
    its.push({s:it.str,x,y,w:it.width||0});   // pdf.js 的 width 已是实际宽度，不要再乘缩放系数
  }
  its.sort((a,b)=>(b.y-a.y)||(a.x-b.x));          // PDF 的 y 越大越靠上
  const rows=[];
  for(const it of its){
    const last=rows[rows.length-1];
    if(last&&Math.abs(last.y-it.y)<=TOL)last.items.push(it);
    else rows.push({y:it.y,items:[it]});
  }
  const out=[];
  for(const r of rows){
    r.items.sort((a,b)=>a.x-b.x);
    let line='',prevEnd=null;
    for(const it of r.items){
      if(prevEnd!==null){const gap=it.x-prevEnd;if(gap>COL_GAP)line+='\t';else if(gap>SP_GAP)line+=' '}
      line+=it.s;prevEnd=it.x+it.w;
    }
    const s=line.replace(/\s+$/,'');
    if(s)out.push(s);
  }
  return out.join('\n');
}
function paint(r,extra){draft=r.profile;q('#resumeStatus').textContent=`识别到 ${r.count} 个候选字段。只识别明确标注和常见联系方式，请逐项核对；复杂排版、多段经历可能遗漏。`+(r.notes.length?' '+r.notes.join('；'):'')+(weakText?' '+weakText:'')+(extra||'');q('#resumePreview').textContent=Object.entries(draft).filter(([g])=>SCHEMA[g]).flatMap(([g,v])=>(Array.isArray(v)?v:[v]).flatMap((entry,i)=>Object.entries(entry).map(([k,value])=>(labels[g]|| (g==='basic'?'个人信息':'求职意向'))+(Array.isArray(v)?' '+(i+1):'')+' · '+(SCHEMA[g].find(x=>x[0]===k)?.[1]||k)+'：'+value))).join('\n');q('#applyResume').disabled=!r.count;q('#resumeReview').hidden=false;}
function show(){const text=q('#resumeText').value;if(text.length>100000){q('#resumeStatus').textContent='文字过长，请保留10万字以内的简历正文。';return}const r=lastR=ResumeParser.parse(text);resetCalls();paint(r);aiOffer().catch(()=>{})}
q('#readResume').onclick=async()=>{if(await needLicense())return;lastExtract=null;show()};
q('#resumeFile').onchange=async e=>{if(await needLicense()){e.target.value='';return}const f=e.target.files[0];if(!f)return;
// 先把旧草稿整份留底：读文件失败时原样还原（契约：导入失败不能把已识别/已填的内容弄丢）
const keep={lastR:lastR,draft:draft,text:q('#resumeText').value,review:q('#resumeReview').hidden,apply:q('#applyResume').disabled,status:q('#resumeStatus').textContent};
draft=null;q('#applyResume').disabled=true;q('#resumeReview').hidden=true;q('#resumeText').value='';q('#resumeStatus').textContent='正在本地读取文件…';try{if(f.size>10*1024*1024)throw Error('文件超过10MB，请先缩小文件。');const ext=f.name.split('.').pop().toLowerCase();let text='';weakText='';if(ext==='txt')text=await f.text();else if(ext==='docx'){const zip=await JSZip.loadAsync(await f.arrayBuffer());const item=zip.file('word/document.xml');if(!item)throw Error('文件不是有效的Word文档。');if(item._data?.uncompressedSize>5*1024*1024)throw Error('文档正文过大。');const xml=await item.async('string');if(xml.length>5000000)throw Error('文档正文过大。');const doc=new DOMParser().parseFromString(xml,'application/xml');if(doc.querySelector('parsererror'))throw Error('Word正文无法解析。');[...doc.getElementsByTagNameNS('*','Fallback')].forEach(el=>el.parentNode&&el.parentNode.removeChild(el));text=[...doc.getElementsByTagNameNS('*','p')].map(p=>[...p.getElementsByTagNameNS('*','t')].map(n=>n.textContent).join('')).join('\n');}else if(ext==='pdf'){const task=pdfjs.getDocument({data:new Uint8Array(await f.arrayBuffer()),isEvalSupported:false,useSystemFonts:true,cMapUrl:new URL('./vendor/cmaps/',import.meta.url).href,cMapPacked:true});let doc;try{doc=await task.promise;if(doc.numPages>30)throw Error('请导入30页以内的简历。');const pages=[],pstat=[];for(let i=1;i<=doc.numPages;i++){const page=await doc.getPage(i);const content=await page.getTextContent();const t=reflow(content.items);pages.push(t);const chars=t.replace(/\s/g,'').length;const c=(t.match(/[\u4e00-\u9fa5]/g)||[]).length;pstat.push([i,chars,c]);}text=pages.join('\n');const cjk=(text.match(/[\u4e00-\u9fa5]/g)||[]).length;lastExtract={cjk:cjk,badPages:(typeof pstat!=='undefined')?pstat.filter(x=>x[1]>200&&x[2]/x[1]<0.05).map(x=>x[0]):[]};
if(cjk<50)weakText='这份 PDF 只识别到 '+cjk+' 个汉字（字体未嵌入编码表时常见），中文正文可能读不到，建议改用 DOCX 或把正文粘贴进来核对。';else{const bad=pstat.filter(x=>x[1]>200&&x[2]/x[1]<0.05).map(x=>x[0]);if(bad.length)weakText='第 '+bad.join('、')+' 页几乎没读出中文（该页字体编码可能没映射上），这一页的内容可能不完整——建议改用 DOCX，或把该页正文粘贴进来核对。'}}finally{await task.destroy();}}else throw Error('请使用PDF、DOCX或TXT；旧版DOC请另存为DOCX。');if(!text.trim())throw Error('未找到可读取文字。扫描版PDF请先转成文字，或直接粘贴正文。');if(text.length>100000)throw Error('提取的文字超过10万字，请缩短文档。');q('#resumeText').value=text;show();}catch(err){lastR=keep.draft;lastR=keep.lastR;draft=keep.draft;q('#resumeText').value=keep.text;q('#resumeReview').hidden=keep.review;q('#applyResume').disabled=keep.apply;q('#resumeStatus').textContent='读取未完成：'+err.message+'（已保留上一次的识别结果）'}finally{e.target.value=''}};
q('#applyResume').onclick=()=>{if(!draft)return;const current=collect();for(const [k,v]of Object.entries(draft.basic))if(!current.basic[k])current.basic[k]=v;for(const [k,v]of Object.entries(draft.intent||{}))if(!current.intent[k])current.intent[k]=v;for(const g of ['education','work','internship','project','language','award','certificate'])if(!current[g].length)current[g]=draft[g];
// 最高学历：按教育经历里的等级取最高的一项（可在下方核对修改）
if(!current.basic.highestLevel){const rank=['博士后','博士','博士研究生','硕士','硕士研究生','本科','大学本科','本科生','大专','专科','高职','高中','中专'];let best='',bi=99;for(const e of (draft.education||[])){const i=rank.indexOf(String(e.level||'').trim());if(i>=0&&i<bi){bi=i;best=e.level}}if(best)current.basic.highestLevel=best}
current.confirmed=false;render(current);dirty();q('#resumeStatus').textContent='已填入档案空白处，已有内容保留。请检查下方档案并保存。';q('#basic').scrollIntoView({behavior:'smooth'});};

// ---------- AI 识别兜底（基础版内置）：只发"未归位的那几行"，点一次才发，可关 ----------
// 方案：设计/ai-识别兜底-实现方案.md；纯逻辑在 resume-ai.js（缺口判定/脱敏/防编造/只补空白）
const AI_PROXY_DEFAULT = 'https://1454638672-hwza9hi1mf.ap-guangzhou.tencentscf.com';   // 云端函数 URL（腾讯云函数，2026-09-12 上线）；本机调试时可在设置里改回 http://127.0.0.1:8787
// 代理地址可从 storage 覆盖（换域名/联调改这里，不用改代码；默认仍是本机代理）
async function aiProxyUrl(){try{const v=(await chrome.storage.local.get('aiProxyUrl')).aiProxyUrl;return String(v||AI_PROXY_DEFAULT).replace(/\/+$/,'')}catch(e){return AI_PROXY_DEFAULT}}
const AI_MAX_CALLS = 5;                                   // 单次导入最多调用次数
let lastR = null, lastGap = null, lastReq = null, lastExtract = null;

const aiCfg = async () => (await chrome.storage.local.get('aiGapSettings')).aiGapSettings || { enabled: true };
const resetCalls = async () => { try { await chrome.storage.local.set({ aiGapState: { calls: 0 } }); } catch (e) {} };

async function aiOffer() {
  const card = q('#aiCard');
  if (!card || !draft) return;
  const cfg = await aiCfg();
  const en = q('#aiEnabled'); if (en) en.checked = cfg.enabled !== false;
  lastGap = (typeof ResumeAI !== 'undefined') ? ResumeAI.gapOf(draft, lastExtract) : { level: 'none', canAI: false };
  if (!lastGap.canAI) { card.hidden = true; return; }      // G2/G3 都不发：没有可发的片段 / 引擎限制
  lastReq = ResumeAI.buildRequest(draft, lastGap);
  q('#aiPreview').textContent = lastReq.sentLines.join('\n')
    + (lastReq.truncated ? '\n…（未归位内容共 ' + (lastReq.totalLines || lastReq.sentLines.length) + ' 行，这里只发前 ' + lastReq.sentLines.length + ' 行，剩余请手工核对）' : '');
  q('#aiMasked').textContent = (lastReq.scrubbed.length ? ('发送前已屏蔽：' + lastReq.scrubbed.join('、')) : '')
    + (lastReq.blocked ? ((lastReq.scrubbed.length ? '；' : '') + '含密码/验证码一类凭证的 ' + lastReq.blocked + ' 行已整行剔除，不发送') : '');
  q('#aiNote').textContent = '下面 ' + lastReq.sentLines.length + ' 行正文没能归位。可以发给我们的中转服务试着认一下——只发这几行，不存储；结果先给你核对，不会直接写进档案。';
  const run = q('#aiRun');
  run.disabled = cfg.enabled === false;
  q('#aiStatus').textContent = cfg.enabled === false ? 'AI 补全已关闭（勾上左下角开关才会发送）。' : '';
  card.hidden = false;
  card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

async function callProxy(url, req) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), 12000);
  try {
    const snap = (typeof LvLicense !== 'undefined' && LvLicense.licenseSnapshot) ? await LvLicense.licenseSnapshot().catch(() => null) : null;
    if (snap && snap.legacy) throw Error('这张授权码是旧版，云端 AI 需要换发新版授权；本次未发送请求');
    if (!snap) throw Error('云端 AI 需要有效授权；本次未发送请求');
    const body = JSON.stringify({ schemaVersion: req.schemaVersion, want: req.want, text: req.text });
    const proof = await new Promise((resolve,reject)=>chrome.runtime.sendMessage({type:'campus-device-proof',body,snap},r=>{
      if(chrome.runtime.lastError)return reject(Error('device_key_unavailable'));
      if(!r||!r.ok)return reject(Error((r&&r.reason)||'device_key_unavailable'));
      resolve(r.headers);
    }));
    const res = await fetch(url + '/v1/resume-gap', {
      method: 'POST', signal: ac.signal, cache: 'no-store', credentials: 'omit',
      headers: Object.assign({ 'content-type': 'application/json', 'X-Lvsuiv-Token': ResumeAI.CLIENT_TOKEN, 'X-Lvsuiv-License': snap.licB64, 'X-Lvsuiv-Device': snap.deviceId }, proof),
      body,
    });
    if (!res.ok) {
      let detail = {}; try { detail = await res.json(); } catch (e) {}
      const reason = res.status === 401 && detail.error === 'license_missing' ? '云端 AI 需要有效授权：请先在上面「授权」里完成激活（未激活不发送）'
        : res.status === 401 && detail.error === 'license_expired' ? '授权已过期，云端 AI 已停用；重开授权后即可继续'
        : res.status === 401 && detail.error === 'license_device_mismatch' ? '这张授权是别的设备的，云端 AI 已拒绝；请联系我们转移'
        : res.status === 401 && detail.error === 'license_version_unsupported' ? '这张授权码是旧版，云端 AI 需要换发新版授权'
        : res.status === 401 && ['proof_missing','proof_malformed','proof_ts_skew','proof_bad_sig','proof_pk_device_mismatch','proof_replay'].includes(detail.error) ? '云端设备持有证明未通过（' + detail.error + '），请联系换发'
        : res.status === 503 && ['proof_replay_capacity','proof_config_invalid'].includes(detail.error) ? '云端设备证明暂不可用（' + detail.error + '），请稍后再试'
        : res.status === 401 && ['license_invalid', 'license_malformed', 'license_plan_not_allowed'].includes(detail.error) ? '授权校验未通过（' + detail.error + '），云端 AI 已拒绝'
        : res.status === 401 || res.status === 403 ? 'AI 服务拒绝访问，请更新扩展或联系维护者'
        : res.status === 429 ? (detail.scope === 'day' ? 'AI 今日调用已达上限' : 'AI 调用频率已达上限，请稍后重试')
        : res.status === 402 ? 'AI 模型账户余额不足' : 'AI 服务请求失败';
      throw Error(reason + '（HTTP ' + res.status + '）');
    }
    return await res.json();
  } finally { clearTimeout(t); }
}

async function saveCache(fp, mappings) {
  const all = (await chrome.storage.local.get('aiGapCache')).aiGapCache || {};
  all[fp] = { at: new Date().toISOString(), mappings };
  const keys = Object.keys(all).sort((a, b) => String(all[a].at).localeCompare(String(all[b].at)));
  while (keys.length > 200) delete all[keys.shift()];      // 上限 200 条，超出丢最旧
  await chrome.storage.local.set({ aiGapCache: all });
}

const aiBtn = q('#aiRun'), aiSkip = q('#aiSkip'), aiEn = q('#aiEnabled');
if (aiSkip) aiSkip.onclick = () => { const c = q('#aiCard'); if (c) c.hidden = true; };
if (aiEn) aiEn.onchange = async () => {
  try { await chrome.storage.local.set({ aiGapSettings: { enabled: !!aiEn.checked } }); } catch (e) {}
  if (q('#aiRun')) q('#aiRun').disabled = !aiEn.checked;
  q('#aiStatus').textContent = aiEn.checked ? '' : '已关闭：以后不会再发送任何内容。';
};
if (aiBtn) aiBtn.onclick = async () => {
  if (!lastReq) return;
  const say = t => { const n = q('#aiStatus'); if (n) n.textContent = t; };
  // 发送前复核（处理器级保护，不只靠按钮 disabled）：总开关必须开着、基础版授权必须可用
  if ((await aiCfg()).enabled === false) { say('开关是关的：这次不发送。'); return }
  if (await needLicense()) { say('授权不可用，已取消发送。'); return }
  aiBtn.disabled = true; aiBtn.textContent = '正在补全…';
  try {
    const proxyUrl = await aiProxyUrl();
    const fp = await ResumeAI.fingerprint(lastReq.text);
    const cache = (await chrome.storage.local.get('aiGapCache')).aiGapCache || {};
    let mappings = cache[fp] ? cache[fp].mappings : null, fromCache = !!mappings;
    if (!mappings) {
      const calls = ((await chrome.storage.local.get('aiGapState')).aiGapState || {}).calls || 0;
      if (calls >= AI_MAX_CALLS) { say('这一次导入的 AI 调用已达上限（' + AI_MAX_CALLS + ' 次）。可以先把档案存下来，再重新导入一次。'); return }
      const data = await callProxy(proxyUrl, lastReq);
      mappings = (data && data.mappings) || [];
      await saveCache(fp, mappings);
      await chrome.storage.local.set({ aiGapState: { calls: calls + 1 } });
    }
    const V = ResumeAI.validate(lastReq, { mappings });
    const mg = ResumeAI.merge(draft, V.ok);
    paint(lastR, ' AI 补全：补上 ' + mg.filled.length + ' 项' + (V.dropped.length ? '，丢弃 ' + V.dropped.length + ' 项（不在原文里的值，不采信）' : '') + (fromCache ? '（命中缓存，未重新联网）' : '') + '。请逐项核对。');
    say(mg.filled.length ? ('补上 ' + mg.filled.length + ' 项，已填到下方档案的空白处，请核对后保存。') : '这几行里没有能对上的字段，保持原样。');
    if (V.dropped.length) say(q('#aiStatus').textContent + ' 丢弃：' + V.dropped.map(d => d.field + '（' + d.why + '）').join('；'));
  } catch (e) {
    say('AI 没连上（' + ((e && e.message) || e) + '）。已按本地识别结果给你，不影响档案。');
  } finally {
    // 关掉开关后不再把按钮恢复成可点（否则留下"看着能点、点了白跑"或旧任务重发的缝）
    aiBtn.disabled = ((await aiCfg()).enabled === false);
    aiBtn.textContent = '用 AI 补齐这几段';
  }
};
