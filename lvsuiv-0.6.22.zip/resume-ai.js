// 简历随行 · AI 识别兜底的【纯逻辑层】（普通脚本；Node 可 eval 加载做离线断言）
// 方案：设计/ai-识别兜底-实现方案.md（依据交接文档 §0.6 的三条硬约束）
// 这里只做四件可离线验证的事：①缺口判定 ②组装"只含未归位那几行"的请求 ③指纹（缓存 key）④校验+只补空白
// 网络、开关、缓存落盘、限额都在 resume-import.js 里做，本文件不碰 chrome、不发请求、不落盘。
(function (root) {
  const CLIENT_TOKEN = '416f70e65e710138b8dd30a5c5003fd9fd228bc4357a63ed'; // 公开共享口令，非密钥
  const SCHEMA = 'resume-gap-mvp-1';
  const MAX_LINES = 40;          // 最多发 40 行
  const MAX_CHARS = 3000;        // 最多 3000 字
  const MAX_VALUE = 200;         // 单个返回值的长度上限
  const MIN_VALUE = 2;
  // 单字就合法的字段（审计 3-04：统一 2 字下限会把"男/女"这种正确值丢掉）
  const MINLEN1 = new Set(['basic.gender', 'education.level', 'language.proficiency', 'certificate.level']);
  // 白名单判定只认**自有属性**（审计 3-04：FIELDS[field] 会命中原型上的 toString 之类）
  const isField = f => Object.prototype.hasOwnProperty.call(FIELDS, f);
  // 掩码占位符不得作为候选值（审计 3-03：否则 [手机]/[姓名]大学 会被当成"补全成功"的真值填进档案）
  const PLACEHOLDER = /\[(姓名|手机|邮箱|座机|证件号|银行卡|密码|验证码)\]/;

  // 字段白名单：既是"允许 AI 填的字段"，也是发给代理的"要它找什么"清单（固定、与用户档案无关）
  const FIELDS = {
    'basic.name': '姓名', 'basic.phone': '手机号码', 'basic.email': '邮箱', 'basic.gender': '性别',
    'basic.birthDate': '出生日期', 'basic.highestLevel': '最高学历', 'basic.politicalStatus': '政治面貌',
    'basic.ethnicity': '民族', 'basic.hometown': '籍贯', 'basic.currentResidence': '现居住地', 'basic.location': '所在地',
    'basic.age': '年龄', 'basic.skills': '专业技能', 'basic.selfDescription': '自我描述',
    'intent.expectedRole': '意向岗位', 'intent.expectedCity': '期望城市', 'intent.applicationCity': '意向工作城市',
    'intent.expectedSalary': '期望薪资', 'intent.jobType': '求职类型', 'intent.available': '到岗时间',
    'education.school': '学校名称', 'education.major': '专业名称', 'education.degree': '学位', 'education.level': '学历',
    'education.start': '开始时间', 'education.end': '结束时间',
    'internship.company': '实习单位', 'internship.role': '实习岗位', 'internship.start': '开始时间', 'internship.end': '结束时间',
    'internship.description': '工作描述',
    'work.company': '公司名称', 'work.role': '职位名称', 'work.start': '开始时间', 'work.end': '结束时间', 'work.description': '工作职责',
    'project.name': '项目名称', 'project.role': '项目角色', 'project.start': '开始时间', 'project.end': '结束时间',
    'project.description': '项目描述',
    'language.name': '语言类型', 'language.proficiency': '掌握程度',
    'award.name': '奖项名称', 'award.date': '获奖时间',
    'certificate.name': '证书名称', 'certificate.level': '等级/成绩', 'certificate.date': '获得时间',
  };
  // 证件号等敏感字段**永不**交给 AI（与红线一致）
  const GROUP_OF = ['basic', 'intent', 'education', 'internship', 'work', 'project', 'language', 'award', 'certificate'];
  const KEY_FIELDS = [['basic', 'name', '姓名'], ['basic', 'phone', '手机'], ['basic', 'email', '邮箱'], ['basic', 'highestLevel', '最高学历']];
  const has = v => v !== undefined && v !== null && !(typeof v === 'string' && !v.trim());

  // ---------- ① 缺口判定 ----------
  // extract: {cjk:number, badPages:number[]}（来自 resume-import 既有的弱提取统计，可省略）
  function gapOf(profile, extract) {
    const p = profile || {};
    const raw = String((p.basic && p.basic.unfiled) || '');
    const unfiled = raw.split('\n').map(s => s.trim()).filter(Boolean);
    if (extract && ((typeof extract.cjk === 'number' && extract.cjk < 50) || (extract.badPages && extract.badPages.length))) {
      return { level: 'G3', canAI: false, unfiled: [], reasons: ['这份文件的正文可能没读全（字体编码问题），AI 也救不了 → 建议改用 DOCX 或把正文粘贴进来'] };
    }
    if (unfiled.length) {
      return { level: 'G1', canAI: true, unfiled: unfiled.slice(0, MAX_LINES), unfiledTotal: unfiled.length,
        reasons: ['有 ' + unfiled.length + ' 行正文没能归位（下面会原样列出），可以让 AI 试着认一下'] };
    }
    const missing = [];
    for (const [g, k, label] of KEY_FIELDS) if (!has((p[g] || {})[k])) missing.push(label);
    if (!(p.education || []).length) missing.push('教育经历');
    if (!(p.internship || []).length && !(p.work || []).length) missing.push('实习/工作经历');
    if (missing.length) {
      return { level: 'G2', canAI: false, unfiled: [],
        reasons: ['没识别出：' + missing.join('、') + '。没有可发的正文片段，AI 帮不上，请在下面手工补一下'] };
    }
    return { level: 'none', canAI: false, unfiled: [], reasons: [] };
  }

  // ---------- ② 组请求（只含未归位那几行；绝不含已解析出的任何字段值） ----------
  // 脱敏：要发出去的是"结构化文本"，姓名/手机/邮箱/证件号对抽取字段没有价值，一律先屏蔽再发。
  // （红线上不许把这类个人信息外发；脱敏后仍保留 AI 需要的单位/学校/时间/职责等文字）
  const MASK = {
    email: /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g,
    phone: /(?:\+?86[-\s]?)?1[3-9]\d{9}/g,
    landline: /(?:0\d{2,3}[-\s]?)\d{7,8}/g,
    idNumber: /(?<!\d)\d{17}[\dXx](?!\d)|(?<!\d)\d{15}(?!\d)/g,
    bank: /(?<!\d)(?:\d[ \t\u00a0-]*){15,18}\d(?!\d)/g,
    passport: /\b[EGDSP]\d{8}\b/gi,
    nameLabel: /(?:姓名|名字)\s*[:：]\s*[\u4e00-\u9fa5·]{2,4}|\b(?:full[ \t]+name|name)[ \t]*[:：][ \t]*[A-Za-z][A-Za-z .'-]*/gi,
  };
  // 凭证标签出现即剔除整行；独占行标签还会剔除下一非空行。
  // 边界避免误删“密码学”；空标签保守处理，可能少发一行普通正文。
  const SECRET_LABEL = /(?:密码|口令|验证码|校验码|动态码|短信码|支付码|安全码|取件码|取款码)(?![\u4e00-\u9fa5])|\b(?:password|passwd|passcode|verification[ \t]+code|security[ \t]+code|OTP|CVV|PIN)\b/i;
  const SECRET_ONLY = /^(?:(?:密码|口令|验证码|校验码|动态码|短信码|支付码|安全码|取件码|取款码)|(?:password|passwd|passcode|verification[ \t]+code|security[ \t]+code|OTP|CVV|PIN))[ \t]*[:：=]?[ \t]*$/i;
  function scrub(text, profile) {
    const keptLines = [], blocked = [];
    let pendingSecret = false;
    for (const ln of String(text || '').replace(/\r\n?/g, '\n').split('\n')) {
      if (pendingSecret) {
        blocked.push(ln);
        if (ln.trim()) pendingSecret = SECRET_ONLY.test(ln.trim());
        continue;
      }
      if (SECRET_LABEL.test(ln)) {
        blocked.push(ln); pendingSecret = SECRET_ONLY.test(ln.trim()); continue;
      }
      keptLines.push(ln);
    }
    let out = keptLines.join('\n');
    const applied = [];
    const hit = (key, re) => {
      const m = out.match(re);
      if (m && m.length) { applied.push(key + '×' + m.length); out = out.replace(re, '[' + key + ']'); }
    };
    // 先处理完整分组数字，避免局部电话匹配留下卡号尾段。
    hit('银行卡', MASK.bank);
    hit('证件号', MASK.passport);
    hit('证件号', MASK.idNumber);
    hit('邮箱', MASK.email);
    hit('手机', MASK.phone);
    hit('座机', MASK.landline);
    // 已解析的短号码也屏蔽，例如没有区号的座机。
    for (const [field, label] of [['phone', '手机'], ['email', '邮箱'], ['idNumber', '证件号']]) {
      const value = String(((profile || {}).basic || {})[field] || '').trim();
      if (value.length >= 5) hit(label, new RegExp(value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'));
    }
    // "姓名：张三"这种带标注的，即使解析器没认出姓名，也按标注屏蔽（审计 3-03：否则未知姓名原样外发）
    hit('姓名', MASK.nameLabel);
    // 已知姓名也屏蔽（名字对判断"这行在讲什么经历"没有帮助）
    // 已知姓名按**词边界**屏蔽（审计 3-03：原名"张江"会把"张江大学"改成"[姓名]大学"，毁掉学校名）
    const name = String(((profile || {}).basic || {}).name || '').trim();
    if (name.length >= 2 && /^[\u4e00-\u9fa5·]+$/.test(name)) {
      const esc = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp('(?<![\\u4e00-\\u9fa5])' + esc + '(?![\\u4e00-\\u9fa5])', 'g');
      const m = out.match(re);
      if (m && m.length) { out = out.replace(re, '[姓名]'); applied.push('姓名×' + m.length); }
    }
    return { text: out, applied, blocked: blocked.length };
  }

  function buildRequest(profile, gap) {
    const all = ((gap && gap.unfiled) || []).map(s => String(s).trim()).filter(Boolean);
    const lines = all.slice(0, MAX_LINES);
    const kept = [];
    let len = 0, cutFirst = false;
    // 审计 3-06：原来第一行不受预算约束（一行 4000 字会被整行发出、代理侧直接 400）。
    // 现在首行也受预算约束（超长就按字符上限硬截），并且把"截了多少"如实带出去。
    for (const ln of lines) {
      if (kept.length && len + ln.length + 1 > MAX_CHARS) break;
      const cut = ln.length > MAX_CHARS ? ln.slice(0, MAX_CHARS) : ln;
      if (cut !== ln) cutFirst = true;
      kept.push(cut); len += cut.length + 1;
    }
    const totalLines = (gap && (typeof gap.unfiledTotal === 'number' ? gap.unfiledTotal : (gap.unfiled || []).length)) || all.length;
    const truncated = (totalLines > kept.length) || cutFirst;
    const raw = kept.join('\n');
    const sc = scrub(raw, profile);
    return {
      schemaVersion: SCHEMA,
      want: Object.keys(FIELDS).map(f => ({ field: f, label: FIELDS[f] })),
      text: sc.text,
      truncated,
      totalLines,                        // 未归位内容的总行数（界面用它说明"共 N 行、只发前 M 行"）
      sentLines: sc.text.split('\n').filter(Boolean),
      scrubbed: sc.applied,
      blocked: sc.blocked || 0,          // 含密码/验证码等凭证、已整行剔除的行数（界面要如实显示）
    };
  }

  // 指纹 = 缓存 key（同一份文本重复导入 → 0 请求）
  async function fingerprint(text) {
    const data = new TextEncoder().encode(String(text || ''));
    const buf = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(buf), b => b.toString(16).padStart(2, '0')).join('');
  }

  // ---------- ③ 校验：AI 只能"抄"，不能"编" ----------
  function validate(req, resp) {
    // 审计 3-01：原来先把整段文本的空白全部删掉再比子串 —— "北京\n大学" 能拼成 "北京大学"，
    // 跨行/跨段拼装都能骗过校验。现在改成**按行**比对：值必须落在**同一行原文**里（行内空格容忍）。
    const lines = String((req && req.text) || '').split('\n').map(l => l.replace(/\s+/g, ''));
    const ok = [], dropped = [];
    const list = (resp && Array.isArray(resp.mappings)) ? resp.mappings : [];
    for (const m of list) {
      if (!m || typeof m !== 'object') continue;
      const field = String(m.field || '').trim();
      const value = String(m.value == null ? '' : m.value).trim();
      if (!isField(field)) { dropped.push({ field, value, why: '字段不在白名单' }); continue; }          // 自有属性才算
      if (PLACEHOLDER.test(value)) { dropped.push({ field, value, why: '这是脱敏占位符，不是真值' }); continue; }
      const minLen = MINLEN1.has(field) ? 1 : MIN_VALUE;
      if (value.length < minLen) { dropped.push({ field, value, why: '值太短' }); continue; }
      if (value.length > MAX_VALUE) { dropped.push({ field, value, why: '值过长' }); continue; }
      const flat = value.replace(/\s+/g, '');
      const li = lines.findIndex(l => l.includes(flat));
      if (li < 0) { dropped.push({ field, value, why: '不在原文里 / 跨行拼出来的（防编造）' }); continue; }
      ok.push({ field, value, li, src: lines[li] });                                                    // 带着来源行，供 merge 判断归属
    }
    return { ok, dropped, counts: { got: list.length, kept: ok.length, dropped: dropped.length } };
  }

  // ---------- ④ 只补空白（不覆盖已有值；条目型去重后并入或新建） ----------
  function merge(profile, ok) {
    // 审计 3-02：原实现按"找个空槽"补字段，会把不同经历的字段拼到同一条里
    // （甲大学的 school 槽 + 乙大学的 major → 拼出原文没有的"甲大学 · 工程管理"）。
    // 现在的规则：**同一个来源行 = 同一条目**；已有条目只有在"它自己的某个值出现在这一行里"时才可被补空字段，
    // 否则一律新建条目。宁可多出一条让用户自己删，也不替用户拼一条不存在的关系。
    const p = profile || {};
    const filled = [], skipped = [];
    for (const group of GROUP_OF) { if (!p[group]) p[group] = (group === 'basic' || group === 'intent') ? {} : []; }
    const scalar = [], byLine = new Map();
    for (const it of (ok || [])) {
      const [g] = String(it.field).split('.');
      if (g === 'basic' || g === 'intent') { scalar.push(it); continue }
      const key = g + '|' + (it.li == null ? '-' : it.li);
      if (!byLine.has(key)) byLine.set(key, []);
      byLine.get(key).push(it);
    }
    for (const { field, value } of scalar) {
      const [g, k] = field.split('.');
      if (has(p[g][k])) { skipped.push({ field, why: '档案里已有值' }); continue }
      p[g][k] = value; filled.push(field);
    }
    for (const [key, items] of byLine) {
      const g = key.split('|')[0];
      const arr = Array.isArray(p[g]) ? p[g] : (p[g] = []);
      const src = String(items[0].src || '');
      // 归属判定只用**身份字段**（学校/单位/项目名）——审计 D02：上一版"任一已有字段出现在源行里就算同一条"，
      // 会让共有值（学历"本科"、日期、职位）把甲大学的专业并到乙大学那条上。
      const IDENTITY = { education: ['school'], internship: ['company'], work: ['company'],
                         project: ['name'], language: ['name'], award: ['name'], certificate: ['name'] };
      const idKeys = IDENTITY[g] || [];
      let target = arr.find(e => e && idKeys.some(kk => has(e[kk]) && src.includes(String(e[kk]).trim()))) || null;
      if (!target && idKeys.length) {
        // 身份冲突：本批次带了自己的身份值（如学校名），而某条已有记录的身份字段也非空且不同 → 不许并进去
        const idVals = items.filter(it => idKeys.includes(it.field.split('.')[1]));
        if (idVals.length) target = arr.find(e => e && idVals.some(it => has(e[it.field.split('.')[1]])
          && String(e[it.field.split('.')[1]]).trim() === String(it.value).trim())) || null;
      }
      if (!target) {
        const dup = arr.find(e => items.some(it => String(e && e[it.field.split('.')[1]] || '') === it.value));
        if (dup) { items.forEach(it => skipped.push({ field: it.field, why: '同一条目已存在' })); continue }
        target = {}; arr.push(target);
      }
      for (const it of items) {
        const k = it.field.split('.')[1];
        if (!has(target[k])) { target[k] = it.value; filled.push(it.field) }
        else if (String(target[k]) === it.value) { skipped.push({ field: it.field, why: '同一条目已存在' }) }
        else { skipped.push({ field: it.field, why: '该条目里已有值' }) }
      }
    }
    return { profile: p, filled, skipped };
  }

  root.ResumeAI = { CLIENT_TOKEN, SCHEMA, FIELDS, MAX_LINES, MAX_CHARS, MAX_VALUE, gapOf, buildRequest, scrub, fingerprint, validate, merge };
})(globalThis);
