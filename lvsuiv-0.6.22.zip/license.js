// 简历随行 · 一码一机离线授权内核（口径：绑定的是**此浏览器安装标识**，不是硬件指纹；清浏览器数据/换浏览器会变）
// 如实边界（V06）：离线部分**不声称**防系统时间回拨、也不声称硬件级绑定——恢复整份 storage 快照仍可绕过；
// 云端 AI 的时效与作废由服务端保证（S-11 信任环+撤销名单；SEC-E 设备持有证明），本机只管离线可用性。
// 依据：设计/授权方案-一码一机.md —— 我们发码时把「设备 ID」写进载荷并签名；扩展内置公钥离线验签，
// 校验「签名有效 → device 等于本机设备 ID → 未过期」。零服务端成本，不联网、不上传任何数据。
//
// ⚠️ 本文件是**普通脚本**（非 ES module）：regression/license_unit.js 会直接 import 它做单测，所以
//    禁止 export / 顶层 import / window；一切挂 globalThis；**顶层不许碰 chrome**（只能在函数里读）。
(function () {
  const PUBKEY_FILE = 'license-key.json';          // 扩展内置公钥（tools/issue_license.js --init 生成）
  const PLANS = ['basic-buyout', 'member'];
  const ALG = { name: 'Ed25519' };
  const PLAN_LABELS = { 'basic-buyout': '买断版', member: '会员' };
  // ⚠️ 上架前替换为公开联系方式（商店描述与这里必须一致）；内测阶段仅通过微信发码
  const CONTACT = '发放授权的人（内测：微信；邮箱 1786884739@qq.com）';
  const REASONS = {
    none: '未激活',
    invalid: '授权无效',
    'device-mismatch': '设备不匹配',
    expired: '已过期',
    ok: '已激活',
  };
  // 功能开关矩阵（设计文档第三节）：检查更新永远可用；买断解锁解析+复制；会员才解锁自动填/AI/岗位表
  const MATRIX = { update: 'always', parse: 'basic', copy: 'basic', autofill: 'member', ai: 'member', jobs: 'member' };
  const DEVICE_RE = /^[0-9a-f]{32}$/;
  const V2_KEYS = ['v', 'code', 'device', 'plan', 'exp', 'iat', 'proof', 'key', 'kid'];
  const KEY_DB = 'lvsuiv-device', KEY_STORE = 'keys', KEY_ID = 'active';

  let pubkeyCache = null;

  const hasChrome = () => typeof chrome !== 'undefined' && !!chrome && !!chrome.storage && !!chrome.storage.local;

  function b64ToBytes(b64) {
    const s = String(b64).replace(/[\s\r\n]/g, '');
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(s)) throw Error('不是有效的 base64');
    const bin = (typeof atob === 'function') ? atob(s) : Buffer.from(s, 'base64').toString('binary');
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function b64u(bytes) {
    let bin = ''; for (const b of new Uint8Array(bytes)) bin += String.fromCharCode(b);
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  // ⚠️ 绝不自造密码学：SHA-256 走 WebCrypto（2026-09-13 实测：上一版手写实现值不对，
  //    sha256Hex('abc') ≠ ba7816bf…，会让 kid 与 licenseDigest/bodyDigest 全错 → 服务端必拒）。
  async function sha256Hex(value) {
    const bytes = value instanceof Uint8Array ? value : value instanceof ArrayBuffer ? new Uint8Array(value) : new TextEncoder().encode(String(value));
    const d = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
    return Array.from(d, x => x.toString(16).padStart(2, '0')).join('');
  }
  function bytesFromB64u(s) { let t = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (t.length % 4) t += '='; return b64ToBytes(t); }
  function dpCanonical(o) { return JSON.stringify(['lvsuiv-dp1', String(o.aud), String(o.method).toUpperCase(), String(o.path), String(o.licenseDigest), String(o.device), String(o.kid), String(o.ts), String(o.rid), String(o.bodyDigest)]); }
  const keyUnavailable = () => Error('device_key_unavailable');
  function openKeyDB() { return new Promise((resolve, reject) => { try { const r = indexedDB.open(KEY_DB, 1); r.onupgradeneeded = () => { if (!r.result.objectStoreNames.contains(KEY_STORE)) r.result.createObjectStore(KEY_STORE); }; r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error || keyUnavailable()); r.onblocked = () => reject(keyUnavailable()); } catch (_) { reject(keyUnavailable()); } }); }
  function idbGet(db) { return new Promise((resolve, reject) => { try { const tx = db.transaction(KEY_STORE, 'readonly'), q = tx.objectStore(KEY_STORE).get(KEY_ID); q.onsuccess = () => resolve(q.result); q.onerror = () => reject(q.error); tx.onabort = () => reject(tx.error); } catch (e) { reject(e); } }); }
  function idbAddOrRead(db, rec) { return new Promise((resolve, reject) => { let winner; try { const tx = db.transaction(KEY_STORE, 'readwrite'), s = tx.objectStore(KEY_STORE), q = s.get(KEY_ID); q.onsuccess = () => { winner = q.result; if (!winner) { try { s.add(rec, KEY_ID); winner = rec; } catch (_) {} } }; q.onerror = () => reject(q.error); tx.onabort = () => reject(tx.error || keyUnavailable()); tx.oncomplete = () => resolve(winner); } catch (e) { reject(e); } }); }
  async function validateKeyRecord(r, device) {
    if (!r || r.schema !== 1 || r.device !== device || !r.privateKey || !r.publicKey || r.privateKey.extractable !== false) throw keyUnavailable();
    const raw = new Uint8Array(await crypto.subtle.exportKey('raw', r.publicKey));
    if (raw.length !== 32 || b64u(raw) !== r.key || (await sha256Hex(raw)) !== r.kid) throw keyUnavailable();
    const challenge = new TextEncoder().encode('lvsuiv-device-key-self-check');
    const sig = await crypto.subtle.sign(ALG, r.privateKey, challenge);
    if (!(await crypto.subtle.verify(ALG, r.publicKey, sig, challenge))) throw keyUnavailable();
    return r;
  }
  let deviceKeyPromise = null;
  async function deviceKey() {
    if (!deviceKeyPromise) deviceKeyPromise = (async () => {
      const device = await getDeviceId(); let db;
      try {
        db = await openKeyDB(); let found = await idbGet(db);
        if (found) return await validateKeyRecord(found, device);
        const pair = await crypto.subtle.generateKey(ALG, false, ['sign', 'verify']);
        const raw = new Uint8Array(await crypto.subtle.exportKey('raw', pair.publicKey));
        const rec = { schema: 1, device, key: b64u(raw), kid: await sha256Hex(raw), privateKey: pair.privateKey, publicKey: pair.publicKey };
        found = await idbAddOrRead(db, rec);
        return await validateKeyRecord(found, device);
      } catch (_) { throw keyUnavailable(); } finally { if (db) db.close(); }
    })().then(x => { deviceKeyPromise = null; return x; }, e => { deviceKeyPromise = null; throw e; });
    return deviceKeyPromise;
  }
  async function deviceInfo() { const r = await deviceKey(); return { device: r.device, kid: r.kid, key: r.key, line: 'LVSUIV-DEV-v2:' + r.device + ':' + r.kid + ':' + r.key }; }
  async function signDeviceProof(message) { const r = await deviceKey(); return b64u(await crypto.subtle.sign(ALG, r.privateKey, new TextEncoder().encode(message))); }

  function newDeviceId() {
    const b = new Uint8Array(16);
    (globalThis.crypto || {}).getRandomValues ? globalThis.crypto.getRandomValues(b) : b.forEach((_, i) => (b[i] = Math.floor(Math.random() * 256)));
    return Array.from(b, x => x.toString(16).padStart(2, '0')).join('');
  }

  // 本机设备 ID：一经生成不再改动（换 ID 会让已买授权失效，所以不做静默轮换）
  // 并发防护（审计 M1）：同一上下文并发调用只生成一次；写入后**再读回**——若别的上下文先写成功就采用它。
  // 否则会出现"页面上显示的 ID ≠ 最终存下的 ID"：用户把 A 发出去，回来的却是按 B 签的码 → 白锁一次。
  let deviceIdPromise = null;
  async function getDeviceId() {
    if (!hasChrome()) throw Error('当前环境读不到本地存储');
    // 权威来源永远是 storage —— 审计 2-05：上一版把结果**永久缓存**，storage 里换了设备 ID 内核仍按旧值判定，
    // 换设备检测会失效。现在只有"存储里还没有、需要首次生成"时才串行化，且生成完成立刻释放。
    const got = await chrome.storage.local.get('deviceId');
    const cur = got && got.deviceId;
    if (typeof cur === 'string' && cur.trim()) return cur.trim();
    if (!deviceIdPromise) {
      deviceIdPromise = (async () => {
        const again = await chrome.storage.local.get('deviceId');
        const c2 = again && again.deviceId;
        if (typeof c2 === 'string' && c2.trim()) return c2.trim();
        await chrome.storage.local.set({ deviceId: newDeviceId() });
        const back = await chrome.storage.local.get('deviceId');
        const fin = back && back.deviceId;
        return (typeof fin === 'string' && fin.trim()) ? fin.trim() : '';
      })().then(v => { deviceIdPromise = null; return v }, e => { deviceIdPromise = null; throw e });
    }
    const v = await deviceIdPromise;
    if (!v) throw Error('设备 ID 写入失败，请重开设置页再试');
    return v;
  }
  function resetDeviceIdCache() { deviceIdPromise = null }   // 仅测试用（换了 mock storage 之后要清）

  // 公钥：兼容旧的扁平 JWK，也接受最多三把的有序信任环。任何坏条目都拒绝整环。
  async function loadPubkeys(jwk) {
    const validateOne = async (v, ringEntry) => {
      if (!v || typeof v !== 'object' || Array.isArray(v) || Object.prototype.hasOwnProperty.call(v, 'd')) throw Error('公钥文件不合法');
      if ((!ringEntry && (v.kty !== 'OKP' || v.crv !== 'Ed25519')) ||
          (ringEntry && ((v.kty !== undefined && v.kty !== 'OKP') || (v.crv !== undefined && v.crv !== 'Ed25519'))) ||
          typeof v.x !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(v.x)) throw Error('公钥文件不合法');
      let raw;
      try { raw = bytesFromB64u(v.x); } catch (_) { throw Error('公钥文件不合法'); }
      if (raw.length !== 32 || b64u(raw) !== v.x) throw Error('公钥文件不合法');
      const kid = await sha256Hex(raw);
      if (Object.prototype.hasOwnProperty.call(v, 'kid') && (typeof v.kid !== 'string' || v.kid !== kid)) throw Error('公钥文件不合法');
      return { kty: 'OKP', crv: 'Ed25519', x: v.x };
    };
    const parse = async source => {
      if (!source || typeof source !== 'object' || Array.isArray(source)) throw Error('公钥文件不合法');
      if (Array.isArray(source.keys) || Object.prototype.hasOwnProperty.call(source, 'schemaVersion')) {
        if (source.schemaVersion !== 1 || !Array.isArray(source.keys) || source.keys.length < 1 || source.keys.length > 3) throw Error('公钥文件不合法');
        return Promise.all(source.keys.map(v => validateOne(v, true)));
      }
      return [await validateOne(source, false)];
    };
    if (jwk && typeof jwk === 'object') {
      if (pubkeyCache && pubkeyCache.source === jwk) return pubkeyCache.keys;
      const keys = await parse(jwk);
      pubkeyCache = { source: jwk, keys };
      return keys;
    }
    if (pubkeyCache) return pubkeyCache.keys;
    const url = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
      ? chrome.runtime.getURL(PUBKEY_FILE) : PUBKEY_FILE;
    const res = await fetch(url, { cache: 'no-store' });
    if (!res || res.ok === false) throw Error('公钥读取失败');
    let jwk2;
    try { jwk2 = await res.json(); } catch (_) { throw Error('公钥文件不合法'); }
    const keys = await parse(jwk2);
    pubkeyCache = { source: 'file', keys };
    return keys;
  }

  // 解析授权码文本：容忍代码块围栏、包裹引号、前后空白，以及 base64(UTF-8 JSON) 形态
  function parseLicenseText(text) {
    let t = String(text == null ? '' : text).trim();
    t = t.replace(/^```[a-zA-Z]*\s*/, '').replace(/\s*```$/, '').trim();
    const unquote = s => {
      const f = s[0], l = s[s.length - 1];
      return ((f === '"' && l === '"') || (f === "'" && l === "'")) ? s.slice(1, -1).trim() : s;
    };
    const asLicense = s => {
      try {
        const o = JSON.parse(s);
        if (o && typeof o === 'object' && typeof o.payload === 'string' && typeof o.sig === 'string' && o.payload && o.sig) {
          return { payload: o.payload, sig: o.sig };
        }
      } catch (e) { /* 继续试下一种形态 */ }
      return null;
    };
    // 容忍被换行/空格打断（邮件、微信转发时常见）：payload 与 sig 里本来没有换行，去掉 \r\n 再解析
    const forms = [t, unquote(t), t.replace(/[\r\n]+/g, ''), unquote(t).replace(/[\r\n]+/g, '')];
    for (const f of forms) { const got = asLicense(f); if (got) return got; }
    try {
      const decoded = new TextDecoder().decode(b64ToBytes(unquote(t)));
      const got2 = asLicense(decoded) || asLicense(decoded.trim());
      if (got2) return got2;
    } catch (e) { /* 落空 */ }
    return null;
  }

  // 载荷结构校验（签名之外的那道门：字段缺一不可、plan 必须在白名单内）
  function payloadOf(payloadStr) {
    try {
      const d = JSON.parse(payloadStr);
      if (!d || typeof d !== 'object' || Array.isArray(d)) return null;
      if (d.v === 1) {
        if (Object.keys(d).length !== 6) return null;
        if (typeof d.code !== 'string' || !d.code || typeof d.device !== 'string' || !d.device || !PLANS.includes(d.plan) || typeof d.exp !== 'string' || !d.exp || typeof d.iat !== 'string' || !d.iat) return null;
        return Object.assign(d, { legacy: true });
      }
      if (d.v !== 2 || Object.keys(d).length !== V2_KEYS.length || !V2_KEYS.every(k => Object.prototype.hasOwnProperty.call(d, k))) return null;
      if (typeof d.code !== 'string' || !d.code) return null;
      if (typeof d.device !== 'string' || !d.device) return null;
      if (!PLANS.includes(d.plan)) return null;
      if (typeof d.exp !== 'string' || !d.exp) return null;
      if (typeof d.iat !== 'string' || !d.iat) return null;
      if (d.proof !== 'ed25519-dp1' || !/^[A-Za-z0-9_-]{43}$/.test(d.key) || !/^[0-9a-f]{64}$/.test(d.kid)) return null;
      try { const raw = bytesFromB64u(d.key); if (raw.length !== 32 || b64u(raw) !== d.key) return null; } catch (_) { return null; }
      return d;
    } catch (e) { return null; }
  }

  const expired = (exp, now) => exp !== 'never' && !(new Date(exp).getTime() > new Date(now).getTime());

  // 核心校验：任何异常都落到 invalid（fail-closed，绝不允许错误地返回 ok）
  async function verify(license, opts) {
    const o = opts || {};
    const deviceId = typeof o.deviceId === 'string' ? o.deviceId : '';
    const now = o.now || new Date().toISOString();
    if (!license || typeof license !== 'object' || typeof license.payload !== 'string' || typeof license.sig !== 'string') {
      return { state: 'invalid', reason: '授权码格式不对，请把发给你的一整段原样粘贴' };
    }
    const d = payloadOf(license.payload);
    if (!d) return { state: 'invalid', reason: '授权码内容不完整或已被改动' };
    if (d.v === 2) {   // key↔kid 一致性：SHA-256 走 WebCrypto（异步），只能在这里校验；口径与服务端一致
      try { if ((await sha256Hex(bytesFromB64u(d.key))) !== d.kid) return { state: 'invalid', reason: '授权码内容不完整或已被改动' }; }
      catch (e) { return { state: 'invalid', reason: '授权码内容不完整或已被改动' }; }
    }
    let ok = false;
    try {
      const jwks = await loadPubkeys(o.pubkeyJwk);
      // 只对 payload 字符串原文验签，不重新序列化（字段顺序变了签名就会失效）
      for (const jwk of jwks) {
        const key = await crypto.subtle.importKey('jwk', jwk, ALG, false, ['verify']);
        if (await crypto.subtle.verify(ALG, key, b64ToBytes(license.sig), new TextEncoder().encode(license.payload))) { ok = true; break; }
      }
    } catch (e) { ok = false; }
    if (!ok) return { state: 'invalid', reason: '签名无效：授权码可能被改动过，或本机授权公钥未配置' };
    // 时间字段必须可解析：签名对得上但 exp 是烂值 → 按失效处理（fail-closed，别让它落进"降级可用"）
    if (d.exp !== 'never' && isNaN(new Date(d.exp).getTime())) return { state: 'invalid', reason: '授权码里的有效期无法识别' };
    if (d.device !== deviceId) return { state: 'device-mismatch', plan: d.plan, exp: d.exp, code: d.code, reason: '该授权绑定的是另一台浏览器的安装标识（不是硬件；清浏览器数据或换浏览器都会变），请联系我们转移' };
    if (expired(d.exp, now)) return { state: 'expired', plan: d.plan, exp: d.exp, code: d.code, reason: '授权已过期，请联系我们续期' };
    return { state: 'ok', plan: d.plan, exp: d.exp, code: d.code, iat: d.iat, reason: '已激活' };
  }

  async function getState() {
    if (!hasChrome()) return { state: 'none', deviceId: '', reason: '当前环境读不到本地授权' };
    let deviceId = '';
    try { deviceId = await getDeviceId(); } catch (e) { return { state: 'invalid', deviceId: '', reason: '设备标识读取失败' }; }
    let license = null;
    try { license = (await chrome.storage.local.get('license')).license; } catch (e) { return { state: 'invalid', deviceId, reason: '授权读取失败' }; }
    if (!license) return { state: 'none', deviceId, reason: REASONS.none };
    const r = await verify(license, { deviceId, now: new Date().toISOString() });
    return Object.assign({ deviceId }, r);
  }

  // 功能开关：'update' 永远可用（没买的人也要能检查更新、看到新功能）
  // 过期口径（设计 §5 验收项「会员过期 → 自动降级为买断功能，档案不丢」）：状态 expired 仍保留买断功能
  // （解析/复制），只锁会员功能；invalid / device-mismatch 一律什么都不解锁。
  async function can(feature) {
    const need = MATRIX[feature];
    if (!need) return false;
    if (need === 'always') return true;
    const st = await getState();
    if (st.state !== 'ok' && st.state !== 'expired') return false;
    return need === 'member' ? (st.state === 'ok' && st.plan === 'member') : true;
  }

  // 激活：先完整校验，通过才落盘；任何失败都不写 storage、也不动档案
  // 落盘条件 = 签名有效 + 设备匹配（含 expired：过期会员仍需被识别，才能「降级为买断」）
  async function activate(text) {
    const lic = parseLicenseText(text);
    if (!lic) return { ok: false, state: 'none', reason: '授权码格式不对，请把发给你的一整段原样粘贴' };
    if (!hasChrome()) return { ok: false, state: 'none', reason: '当前环境不能保存授权' };
    let deviceId = '';
    try { deviceId = await getDeviceId(); } catch (e) { return { ok: false, state: 'none', reason: '设备标识读取失败' }; }
    const r = await verify(lic, { deviceId, now: new Date().toISOString() });
    if (r.state !== 'ok' && r.state !== 'expired') return { ok: false, state: r.state, reason: r.reason };
    const p = payloadOf(lic.payload);
    if (p && p.v === 2) { try { const di = await deviceInfo(); if (p.key !== di.key || p.kid !== di.kid) return { ok: false, state: 'device-mismatch', reason: REASONS['device-mismatch'] }; } catch (_) { return { ok: false, state: 'device-mismatch', reason: '云端设备密钥不可用；本地资料与本地授权保留，请联系换发' }; } }
    try { await chrome.storage.local.set({ license: { payload: lic.payload, sig: lic.sig } }); }
    catch (e) { return { ok: false, state: 'none', reason: '授权保存失败，请重试' }; }
    if (r.state === 'expired') return { ok: true, state: 'expired', plan: r.plan, exp: r.exp, code: r.code, reason: '授权已过期：' + String(r.exp).slice(0, 10) + '（买断功能仍可用，会员功能已锁）' };
    return { ok: true, state: 'ok', plan: r.plan, exp: r.exp, code: r.code, reason: '已激活' };
  }

  const reasonText = state => REASONS[state] || '未激活';
  const planLabel = plan => PLAN_LABELS[plan] || '';

  // 供联网调用：把当前授权（payload+sig）与设备 ID 交给服务端二次校验。
  // 未激活 / 读不到 / 环境不允许 → 返回 null（不抛）。
  async function licenseSnapshot() {
    if (!hasChrome()) return null;
    let lic = null;
    try { lic = (await chrome.storage.local.get('license')).license; } catch (e) { return null; }
    if (!lic || typeof lic.payload !== 'string' || typeof lic.sig !== 'string' || !lic.payload || !lic.sig) return null;
    let deviceId = '';
    try { deviceId = await getDeviceId(); } catch (e) { return null; }
    const bytes = new TextEncoder().encode(JSON.stringify({ payload: lic.payload, sig: lic.sig }));
    let bin = ''; for (const b of bytes) bin += String.fromCharCode(b);
    const p = payloadOf(lic.payload); if (!p) return null;
    return { licB64: btoa(bin), deviceId, kid: p.kid || '', payloadVersion: p.v, legacy: !!p.legacy };
  }

  globalThis.LvLicense = {
    getDeviceId, getState, can, activate, reasonText, planLabel, licenseSnapshot, CONTACT, resetDeviceIdCache,
    // 纯函数出口（离线单测直接调真代码，不复制一份逻辑）
    __core: {
      parseLicenseText, payloadOf, verify, loadPubkeys, newDeviceId, b64u, sha256Hex, dpCanonical, deviceInfo, deviceKey, signDeviceProof,
      resetPubkeyCache() { pubkeyCache = null; },
      MATRIX, PLANS,
    },
  };
})();
