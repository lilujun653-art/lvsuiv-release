(function () {
  'use strict';
  const LvUpdate = {};
  LvUpdate.RELEASE_REPO = 'lilujun653-art/lvsuiv-release'; LvUpdate.RELEASE_REF = 'main';
  // Replace this bootstrap placeholder with the 43-char public key printed by
  // `node tools/sign_manifest.js --init-release-keys` before the first release.
  LvUpdate.RELEASE_PUBKEY = 'LgZVKidbhxgiQAM6SpybRWyrPeMzO-3bFNhWPoU-v7c';
  LvUpdate.RELEASE_SIG_ALG = 'ed25519-m1';
  LvUpdate.DEFAULT_UPDATE_URL = 'https://raw.githubusercontent.com/' + LvUpdate.RELEASE_REPO + '/' + LvUpdate.RELEASE_REF + '/latest.json';
  LvUpdate.MIRROR_UPDATE_URL = 'https://cdn.jsdelivr.net/gh/' + LvUpdate.RELEASE_REPO + '@' + LvUpdate.RELEASE_REF + '/latest.json';
  let lastObjectUrl = null;
  const codeError = code => { const e = new Error(code); e.code = code; return e; };
  const httpsUrl = value => { try { const u = new URL(value); return u.protocol === 'https:' ? u.href : null; } catch (_) { return null; } };
  const manifestPayload = data => JSON.stringify(['lvsuiv-manifest-1', String(data?.schemaVersion), String(data?.version), String(data?.minSupported || ''), String(data?.releasedAt || ''), String(data?.zip?.url), String(data?.zip?.sha256).toLowerCase(), String(data?.zip?.size || ''), (Array.isArray(data?.notes) ? data.notes.join('\u0001') : ''), String(data?.storeUrl || '')]);
  const base64 = value => { try { const s = atob(String(value).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from(s, c => c.charCodeAt(0)); } catch (_) { return null; } };
  const verifyManifest = async data => { if (!data?.sig) throw codeError('zip-sig-missing'); if (data.sigAlg !== LvUpdate.RELEASE_SIG_ALG) throw codeError('zip-sig-invalid'); try { if (!globalThis.crypto?.subtle) throw 0; const pub = base64(LvUpdate.RELEASE_PUBKEY), sig = base64(data.sig); if (!pub || pub.length !== 32 || !sig || sig.length !== 64) throw 0; const kid = [...new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256', pub))].map(x => x.toString(16).padStart(2, '0')).join(''); if (data.kidOfManifestKey !== kid) throw 0; const key = await globalThis.crypto.subtle.importKey('raw', pub, { name:'Ed25519' }, false, ['verify']); if (!await globalThis.crypto.subtle.verify({ name:'Ed25519' }, key, sig, new TextEncoder().encode(manifestPayload(data)))) throw 0; } catch (_) { throw codeError('zip-sig-invalid'); } };
  function parse(v) { if (typeof v !== 'string') return null; const m = /^v?(\d+(?:\.[0-9A-Za-z]+)*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(v.trim()); return m ? [m[1].split('.'), m[2] ? m[2].split('.') : null] : null; }
  function segment(a, b) { const an = /^\d+$/.test(a), bn = /^\d+$/.test(b); if (an && bn) { a = BigInt(a); b = BigInt(b); } else if (an !== bn) return an ? 1 : -1; return a === b ? 0 : a > b ? 1 : -1; }
  LvUpdate.cmpV = function (a, b) { const x = parse(a), y = parse(b); if (!x || !y) return null; for (let i = 0; i < Math.max(x[0].length, y[0].length); i++) { const c = segment(x[0][i] || '0', y[0][i] || '0'); if (c) return c; } if (!x[1] || !y[1]) return x[1] ? -1 : y[1] ? 1 : 0; for (let i = 0; i < Math.max(x[1].length, y[1].length); i++) { if (x[1][i] === undefined || y[1][i] === undefined) return x[1][i] === undefined ? -1 : 1; const aa = x[1][i], bb = y[1][i], c = /^\d+$/.test(aa) !== /^\d+$/.test(bb) ? (/^\d+$/.test(aa) ? -1 : 1) : segment(aa, bb); if (c) return c; } return 0; };
  LvUpdate.getUrls = async function () { const stored = await chrome.storage.local.get('updateUrl'); return stored.updateUrl ? [stored.updateUrl] : [LvUpdate.DEFAULT_UPDATE_URL, LvUpdate.MIRROR_UPDATE_URL]; };
  LvUpdate.check = async function ({ url, fetchImpl, timeoutMs = 6000, currentVersion } = {}) {
    const error = detail => ({ state: 'error', remote: '', notes: [], zip: null, detail });
    try { const current = currentVersion === undefined ? chrome.runtime.getManifest().version : currentVersion; if (!parse(current)) return error('invalid-current-version'); const targets = url === undefined ? await LvUpdate.getUrls() : [url], failures = [];
      for (const [index, target] of targets.entries()) { let timer; try {
        if (!httpsUrl(target)) throw codeError('invalid-url'); const controller = new AbortController();
        const timeout = new Promise((_, reject) => { timer = setTimeout(() => { controller.abort(); reject(codeError('timeout')); }, timeoutMs); });
        const request = async () => { const response = await (fetchImpl || globalThis.fetch)(target, { method: 'GET', signal: controller.signal, credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer', redirect: 'error' }); if (response.status !== 200) throw codeError('http-' + response.status); return response.json(); };
        const data = await Promise.race([request(), timeout]); await verifyManifest(data); const cmp = LvUpdate.cmpV(data?.version, current); if (cmp === null) throw codeError('invalid-remote-version'); if (cmp < 0) throw codeError('rollback-refused');
        const notes = Array.isArray(data.notes) ? data.notes.filter(n => typeof n === 'string') : []; if (cmp === 0) return { state: 'latest', remote: data.version, notes: [], zip: null, detail: '' };
        const packageUrl = httpsUrl(data.zip?.url), sha256 = data.zip?.sha256; if (!packageUrl) throw codeError('invalid-url'); if (typeof sha256 !== 'string' || !/^[0-9a-f]{64}$/i.test(sha256)) throw codeError('missing-sha256');
        return { state: 'newer', remote: data.version, notes, zip: { url: packageUrl, sha256 }, source: index === 0 ? 'primary' : 'mirror' };
      } catch (e) { const code = e?.code || e?.message || 'request-failed'; if (['rollback-refused', 'missing-sha256', 'invalid-url'].includes(code)) return error(code); failures.push(String(target) + ': ' + code); } finally { clearTimeout(timer); } }
      return error(failures.some(x => x.endsWith(': zip-sig-missing')) ? 'zip-sig-missing' : failures.some(x => x.endsWith(': zip-sig-invalid')) ? 'zip-sig-invalid' : failures.some(x => x.endsWith(': rollback-refused')) ? 'rollback-refused' : failures.some(x => x.endsWith(': missing-sha256')) ? 'missing-sha256' : failures.some(x => x.endsWith(': invalid-url')) ? 'invalid-url' : failures.join('; '));
    } catch (e) { return error(e?.code || e?.message || 'request-failed'); }
  };
  LvUpdate.downloadVerified = async function ({ url, sha256, fetchImpl, timeoutMs = 15000, maxBytes = 20 * 1024 * 1024, makeObjectUrl } = {}) {
    if (!httpsUrl(url)) throw codeError('invalid-url'); if (typeof sha256 !== 'string' || !/^[0-9a-f]{64}$/i.test(sha256)) throw codeError('missing-sha256'); let timer;
    try { const controller = new AbortController(); const timeout = new Promise((_, reject) => { timer = setTimeout(() => { controller.abort(); reject(codeError('timeout')); }, timeoutMs); });
      const request = async () => { const response = await (fetchImpl || globalThis.fetch)(url, { method: 'GET', signal: controller.signal, credentials: 'omit', cache: 'no-store', redirect: 'error' }); if (!response || (!response.ok && response.status !== 200)) throw codeError('http-' + (response?.status || 0)); const length = Number(response.headers?.get?.('content-length')); if (Number.isFinite(length) && length > maxBytes) throw codeError('too-large'); return new Uint8Array(await response.arrayBuffer()); };
      const bytes = await Promise.race([request(), timeout]); if (bytes.byteLength > maxBytes) throw codeError('too-large'); if (!globalThis.crypto?.subtle) throw codeError('crypto-unavailable'); const hash = [...new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256', bytes))].map(x => x.toString(16).padStart(2, '0')).join(''); if (hash !== sha256.toLowerCase()) throw codeError('zip-hash-mismatch'); const objectUrl = (makeObjectUrl || URL.createObjectURL)(new Blob([bytes], { type: 'application/zip' })); return { bytes, sha256: hash, size: bytes.byteLength, objectUrl };
    } catch (e) { throw e?.code ? e : codeError(e?.message || 'request-failed'); } finally { clearTimeout(timer); }
  };
  LvUpdate.openVerifiedPackage = async function (entry, { fetchImpl, timeoutMs, maxBytes, makeObjectUrl, opener, revokeObjectUrl } = {}) { try { if (!entry || entry.state !== 'newer' || !entry.zip) throw codeError('invalid-entry'); if (lastObjectUrl) { (revokeObjectUrl || URL.revokeObjectURL)(lastObjectUrl); lastObjectUrl = null; } const verified = await LvUpdate.downloadVerified({ ...entry.zip, fetchImpl, timeoutMs, maxBytes, makeObjectUrl }); lastObjectUrl = verified.objectUrl; await (opener || (url => chrome.tabs.create({ url })))(verified.objectUrl); return { ok: true, ...verified }; } catch (e) { return { ok: false, code: e?.code || e?.message || 'request-failed' }; } };
  if (typeof window !== 'undefined') window.LvUpdate = LvUpdate; if (typeof module !== 'undefined') module.exports = LvUpdate;
})();
