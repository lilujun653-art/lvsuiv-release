@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   简历随行 · 发码（基础版买断 / 一码一机）
echo ============================================
echo.
echo 同学的设备 ID 从扩展里拿：档案页 ^> 「授权」卡片 ^> 「复制设备 ID」
echo （32 位小写十六进制，例如 9f2c...）
echo.
set /p NAME=同学的称呼/备注（例：张三 秋招2026）: 
set /p DEV=粘贴设备 ID（32 位小写十六进制）: 
echo.
echo 正在签发...
echo.
node tools\issue_license.js --name "%NAME%" --device %DEV% --plan basic-buyout
if errorlevel 1 (
  echo.
  echo [!] 签发失败：请检查上面提示（最常见原因：设备 ID 少字符/含空格/不是 32 位小写十六进制）
) else (
  echo.
  echo [OK] 把上面那串 LVSUIV-XXXX-XXXX 整段发给同学，让他粘进「授权码」框点「激活」。
  echo      发出去以后，记得跑一次：node tools\issue_license.js --deliver 该码
)
echo.
pause
