const SCHEMA={basic:[['name','姓名'],['email','邮箱','email'],['phone','手机号码','tel'],['dialCode','电话区号（如 +86）'],['gender','性别（选填）'],['birthDate','出生日期（选填）','date'],['experience','工作经验（按网站选项填写）'],['highestLevel','最高学历'],['location','所在地'],['latestCompany','最近公司'],['idNumber','证件号（选填）'],['politicalStatus','政治面貌（选填）'],['ethnicity','民族（选填）'],['hometown','籍贯（选填）'],['currentResidence','现居住地（选填）'],['height','身高（选填）'],['age','年龄（选填）'],['weight','体重（选填）'],['idType','证件类型（选填）'],['nationality','国籍（选填）'],['maritalStatus','婚姻状况（选填）'],['studyMode','学习形式（选填）'],['graduateType','应届/往届（选填）'],['nativePlace','生源地（选填）'],['skills','专业技能/特长','textarea'],['selfDescription','自我描述','textarea'],['unfiled','未归位内容（原文摘录，请核对后补充到上方或删除）','textarea']],education:[['school','学校名称'],['major','专业名称'],['degree','学位（如学士）'],['level','学历（如本科）'],['start','开始时间','month'],['end','结束时间','month']],internship:[['company','实习单位'],['role','实习岗位'],['start','开始时间','month'],['end','结束时间','month'],['description','工作描述','textarea']],project:[['name','项目名称'],['role','项目角色'],['start','开始时间','month'],['end','结束时间','month'],['description','项目描述','textarea'],['responsibilities','项目中职责','textarea'],['ongoing','是否至今（填是或否）']]};
SCHEMA.work=[['company','公司名称'],['role','职位名称'],['start','开始时间','month'],['end','结束时间','month'],['ongoing','是否至今（填是或否）'],['description','工作职责','textarea']];
SCHEMA.internship.push(['ongoing','是否至今（填是或否）']);
SCHEMA.language=[['name','语言类型'],['proficiency','掌握程度'],['speaking','听说'],['writing','读写']];
SCHEMA.award=[['date','获奖时间','month'],['name','奖项名称']];
SCHEMA.certificate=[['name','证书名称'],['level','等级/成绩'],['date','获得时间','month']];
SCHEMA.intent=[['applicationCity','本次申请：意向工作城市'],['expectedRole','意向岗位'],['expectedCity','期望城市'],['jobType','求职类型（如 校招）'],['expectedIndustry','期望行业'],['currentStatus','当前状态（如 随时到岗）'],['currentSalary','当前薪资（注明币种及月薪/年薪）'],['expectedSalary','期望薪资（注明币种及月薪/年薪）'],['available','到岗/报到时间（如 2027-07）'],['obeyAdjust','是否服从工作地点调配（是/否）']];

const localMode=!(globalThis.chrome?.storage?.local);let revision=0;let savedRevision=0;
const db={async get(){return localMode?JSON.parse(localStorage.getItem('campus-profile')||'null'):(await chrome.storage.local.get('profile')).profile},async set(profile){if(localMode)localStorage.setItem('campus-profile',JSON.stringify(profile));else await chrome.storage.local.set({profile})},async clear(){if(localMode)localStorage.removeItem('campus-profile');else await chrome.storage.local.remove('profile')}};
const $=s=>document.querySelector(s);const labels={education:'教育经历',internship:'实习经历',project:'项目经历',work:'工作经历',language:'语言能力',award:'获奖经历',certificate:'证书'};
function field(key,label,type='text',value=''){const wrapper=document.createElement('label');wrapper.className='field'+(type==='textarea'?' full':'');wrapper.append(document.createTextNode(label));const input=document.createElement(type==='textarea'?'textarea':'input');if(type!=='textarea')input.type=type;input.dataset.key=key;input.value=value;input.maxLength=type==='textarea'?6000:250;wrapper.append(input);const copy=document.createElement("button");copy.type="button";copy.className="secondary small";copy.style.alignSelf="flex-start";copy.textContent="复制此项";copy.onclick=async e=>{e.preventDefault();let okCopy=true;try{if(globalThis.LvLicense&&LvLicense.can)okCopy=await LvLicense.can('copy')}catch(err){okCopy=false}if(!okCopy){copy.textContent='激活后才能复制';setTimeout(()=>copy.textContent='复制此项',1800);return}try{await navigator.clipboard.writeText(input.value);copy.textContent="已复制";}catch{input.focus();input.select();copy.textContent="请按 Ctrl+C 复制";}setTimeout(()=>copy.textContent="复制此项",1800)};wrapper.append(copy);return wrapper}
function addEntry(group,entry={}){const wrap=document.createElement('div');wrap.className='entry';const head=document.createElement('div');head.className='entry-head';const title=document.createElement('h3');title.textContent=labels[group];const remove=document.createElement('button');remove.type='button';remove.className='danger small';remove.textContent='移除';remove.onclick=()=>{wrap.remove();dirty()};head.append(title,remove);const fields=document.createElement('div');fields.className='fields';for(const [key,label,type] of SCHEMA[group])fields.append(field(key,label,type,entry[key]||''));wrap.append(head,fields);$('#'+group+'Entries').append(wrap)}
function render(p={}){$('#intentFields').replaceChildren();for(const [key,label,type] of SCHEMA.intent)$('#intentFields').append(field(key,label,type,p.intent?.[key]||''));$('#basicFields').replaceChildren();for(const [key,label,type]of SCHEMA.basic)$('#basicFields').append(field(key,label,type,p.basic?.[key]||''));for(const group of Object.keys(labels)){$('#'+group+'Entries').replaceChildren();for(const entry of p[group]||[])addEntry(group,entry)}$('#confirmed').checked=!!p.confirmed;}
function values(el){return Object.fromEntries([...el.querySelectorAll('[data-key]')].map(n=>[n.dataset.key,n.value.trim()]))}
function collect(){const p={version:2,intent:values($('#intentFields')),basic:values($('#basicFields')),confirmed:$('#confirmed').checked,updatedAt:new Date().toISOString()};for(const group of Object.keys(labels))p[group]=[...$('#'+group+'Entries').children].map(values).filter(v=>Object.values(v).some(Boolean));return p}
function validate(p){if(!p||![1,2].includes(p.version)||!p.basic||typeof p.basic!=='object'||Array.isArray(p.basic))throw Error('不是有效的简历随行档案。');const clean={version:2,basic:{},confirmed:false};for(const group of Object.keys(SCHEMA)){const entries=['basic','intent'].includes(group)?[p[group]||{}]:(p[group]||[]);if(!Array.isArray(entries)||entries.length>30)throw Error('经历格式不正确或数量超过30条。');const valid=entries.map(entry=>{if(!entry||typeof entry!=='object'||Array.isArray(entry))throw Error('经历格式不正确。');return Object.fromEntries(SCHEMA[group].map(([key,,type])=>{const v=entry[key]??'';if(typeof v!=='string'||v.length>(type==='textarea'?6000:250))throw Error('档案字段格式或长度不正确。');if(type==='date'&&v&&!/^\d{4}-\d{2}-\d{2}$/.test(v))throw Error('出生日期应为 YYYY-MM-DD。');if(type==='month'&&v&&!/^\d{4}-(0[1-9]|1[0-2])$/.test(v))throw Error('日期应为 YYYY-MM。');return[key,v]}))});clean[group]=['basic','intent'].includes(group)?valid[0]:valid}return clean}
function dirty(){revision++;$('#confirmed').checked=false;$('#saveStatus').textContent='有未保存的修改，请核对并重新确认。'}
$('#profileForm').addEventListener('input',e=>{if(e.target.id!=='confirmed')dirty()});
document.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>{addEntry(b.dataset.add);dirty()});
$('#profileForm').onsubmit=async e=>{e.preventDefault();try{const p=collect();if(!p.basic.name)throw Error('请至少填写姓名。');for(const group of Object.keys(labels))for(const item of p[group])if(item.start&&item.end&&item.start>item.end)throw Error(labels[group]+'的结束时间不能早于开始时间。');for(const group of ['work','internship','project'])for(const item of p[group]){if(item.ongoing&&!['是','否'].includes(item.ongoing))throw Error('是否至今请填是或否，或留空。');if(item.ongoing==='是'&&item.end)throw Error('至今的经历请清空结束时间。');}if(!p.confirmed)throw Error('请先确认资料。');await db.set(p);savedRevision=revision;$('#saveStatus').textContent='已保存并确认 · '+new Date().toLocaleTimeString();}catch(e){$('#saveStatus').textContent=e.message}};
$('#export').onclick=()=>{const blob=new Blob([JSON.stringify(collect(),null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='我的求职档案.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
$('#import').onclick=()=>$('#file').click();$('#file').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;if(f.size>300000)throw Error('文件过大，请导入300KB以内的档案。');const p=validate(JSON.parse(await f.text()));render(p);dirty();$('#dataStatus').textContent='已载入编辑区。请检查并保存。'}catch(e){$('#dataStatus').textContent='导入失败：'+e.message}finally{e.target.value=''}};
$('#clear').onclick=async()=>{if(!confirm('删除此浏览器保存的档案并清空编辑区？已填写到网页的内容不会删除。'))return;try{
  // 有预存附件时明确询问是否一并删除（默认一并删更安全，避免个人文件残留）
  const attRec=await getAttachmentRec().catch(()=>null);
  let attRemoved=false;
  if(attRec){
    attRemoved=confirm(`检测到有预存的简历附件（${attRec.name||'resume'}）。是否一并删除？\n「确定」一并删除（推荐），「取消」保留附件。`);
    if(attRemoved)await deleteAttachmentRec();
  }
  await db.clear();
  // 审计 I05：AI 候选缓存里存的是"从简历提取的候选值"，删档案时一并清掉，别让简历相关数据以缓存形式残留
  try{ if(globalThis.chrome&&chrome.storage&&chrome.storage.local) await chrome.storage.local.remove(['aiGapCache','aiGapState']) }catch(e){}
  render();revision++;savedRevision=revision;
  $('#saveStatus').textContent='本地档案已删除（AI 候选缓存也已清空）。';
  $('#dataStatus').textContent=attRec?(attRemoved?'删除完成，预存附件也已删除。':'删除完成，预存附件仍保留。'):'删除完成。';
  showAttachment();
}catch(e){$('#dataStatus').textContent='删除失败：'+e.message}};
window.addEventListener('beforeunload',e=>{if(revision!==savedRevision){e.preventDefault();e.returnValue=''}});
// ---------- 简历附件（IndexedDB：本页写入，background.js 只读，供自动上传） ----------
function openFileDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open('campus-files',1);req.onupgradeneeded=()=>{try{req.result.createObjectStore('files')}catch{}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
// 预存附件的查询与删除（供"删除档案"与"移除附件"共用）
async function getAttachmentRec(){const fdb=await openFileDB();try{return await new Promise((res,rej)=>{const q=fdb.transaction('files','readonly').objectStore('files').get('resume');q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)})}finally{fdb.close()}}
async function deleteAttachmentRec(){const fdb=await openFileDB();try{await new Promise((res,rej)=>{const tx=fdb.transaction('files','readwrite');tx.objectStore('files').delete('resume');tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}finally{fdb.close()}}
async function showAttachment(){try{const db=await openFileDB();const rec=await new Promise((res,rej)=>{const q=db.transaction('files','readonly').objectStore('files').get('resume');q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});db.close();$('#attachStatus').textContent=rec?`已预存：${rec.name}（${Math.round((rec.data&&rec.data.byteLength||0)/1024)} KB，${new Date(rec.savedAt).toLocaleString()}）`:'尚未预存附件。'}catch(e){$('#attachStatus').textContent='附件状态读取失败：'+e.message}}
$('#attachFile').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;try{if(!/\.(pdf|doc|docx)$/i.test(f.name))throw Error('请使用 PDF、DOC 或 DOCX 文件。');if(f.size>5*1024*1024)throw Error('附件请控制在 5MB 以内。');const db=await openFileDB();const data=await f.arrayBuffer();await new Promise((res,rej)=>{const tx=db.transaction('files','readwrite');tx.objectStore('files').put({name:f.name,type:f.type,data,savedAt:new Date().toISOString()},'resume');tx.oncomplete=res;tx.onerror=()=>rej(tx.error)});db.close();showAttachment();}catch(err){$('#attachStatus').textContent='保存附件失败：'+err.message}};
$('#attachRemove').onclick=async()=>{if(!confirm('删除预存的简历附件？（首版已关闭自动填写与附件注入，这里只删除本地留存）'))return;try{await deleteAttachmentRec();await showAttachment();$('#attachStatus').textContent='附件已删除。'}catch(e){$('#attachStatus').textContent='删除失败：'+e.message}};
(async()=>{try{render(await db.get()||{});if(!$('#educationEntries').children.length)addEntry('education');if(localMode)$('#previewNotice').classList.remove('hidden');showAttachment()}catch(e){$('#saveStatus').textContent='读取失败：'+e.message}})();

// ---------- 版本号统一取自 manifest（唯一真源，禁止在各处写死） ----------
try{
  const vt=document.getElementById('verTag');
  if(vt) vt.textContent=chrome.runtime.getManifest().version;
}catch(e){}

const updateBtn = $('#checkUpdate'), updateStatus = $('#updateStatus'), updateSteps = $('#updateSteps');
let updateVersion = '';
const UPDATE_FAIL = '检查失败：网络或服务不可用，可稍后重试';
try { updateVersion = chrome.runtime.getManifest().version; $('#updateVersion').textContent = '当前版本 v' + updateVersion; } catch (_) {}
updateBtn.onclick = async () => {
  updateBtn.disabled = true; updateBtn.textContent = '检查中…';
  updateStatus.textContent = ''; updateSteps.hidden = true; updateSteps.open = false;
  let text = UPDATE_FAIL, result = null;
  try {
    result = await window.LvUpdate.check();
    // 真机断言用的只读钩子（不含任何敏感信息）：让测试台能拿到结构化终态，而不是靠猜界面文案
    window.__lastUpdateResult = result || null;
    window.__lastUpdateState = (result && result.state) || '';
    window.__lastUpdateDetail = (result && result.detail) || '';
    window.__lastUpdateZipUrl = (result && result.zip && result.zip.url) || '';
    if(result.state === 'latest') text = '已是最新 v' + updateVersion;
    else if(result.state === 'newer') text = '有新版 v' + result.remote.replace(/^v/, '');
    else if(result.state === 'error') text = updateErrorText(result.detail);
  } catch (_) {}
  updateBtn.disabled = false; updateBtn.textContent = '检查更新';
  updateStatus.textContent = text;
  if(result && result.state === 'newer'){
    const a = document.createElement('a');
    a.href = '#'; a.textContent = '下载并校验更新包';
    a.onclick = async e => { e.preventDefault(); a.setAttribute('aria-disabled','true'); updateStatus.textContent='正在校验更新包…'; const opened=await window.LvUpdate.openVerifiedPackage(result); updateStatus.textContent=opened.ok?'已通过哈希校验，正在打开':updateErrorText(opened.code); };
    updateStatus.append(' · ', a);
    updateSteps.hidden = false; updateSteps.open = true;
  }
};
function updateErrorText(code){return code==='rollback-refused'?'远端版本比本机旧，已拒绝（防降级）':code==='zip-hash-mismatch'?'更新包哈希不匹配，已拒绝（可能被替换）':code==='missing-sha256'?'清单缺少哈希，已拒绝':code==='invalid-url'?'只允许 https':'更新包校验失败：'+(code||'request-failed')}

// ---------- 授权（一码一机）：状态展示 + 激活 + 未激活时锁住「导入简历」 ----------
// 依据：设计/授权方案-一码一机.md —— 未激活：解析/复制不可用；买断：解析+复制；会员：再加自动填/AI/岗位表。
// 红线：检查更新永远可用；降级/过期只锁功能，档案一个字节都不动。
function licLockImport(on){
  const body=document.getElementById('importBody'),note=document.getElementById('resumeLocked');
  if(body)body.hidden=!!on;
  if(note)note.hidden=!on;
}
async function renderDeviceInfo(){
  const devId=document.getElementById('devId'),devInfo=document.getElementById('devInfo'),copy=document.getElementById('devInfoCopy');
  if(copy)copy.disabled=false;
  let device='';
  try{
    device=await LvLicense.getDeviceId();
    if(devId)devId.textContent=device;
  }catch(e){
    if(devId)devId.textContent='读取失败，请在「编辑档案」里查看';
  }
  try{
    const info=await LvLicense.__core.deviceInfo();
    if(devInfo)devInfo.textContent=info.line;
    if(copy)copy._deviceInfo=info.line;
  }catch(e){
    if(devInfo)devInfo.textContent='本机设备密钥不可用（本地功能不受影响），请联系我们';
    if(copy){copy.disabled=true;copy._deviceInfo=''}
  }
}
async function refreshLicense(){
  let st={state:'none'};
  try{st=await LvLicense.getState()}catch(e){st={state:'invalid',reason:'授权读取失败'}}
  const usable=st.state==='ok'||st.state==='expired';
  licLockImport(!usable);
  const line=document.getElementById('licState');
  if(line)line.textContent = st.state==='ok'
    ? (st.plan==='member'?'已激活 · 会员'+(st.exp==='never'?'':'，有效期至 '+String(st.exp).slice(0,10)):'已激活 · 基础版（解析、复制、AI 识别辅助已含；自动填与 AI 生成/改写属会员版，尚未开放）')
    : (st.state==='expired'?('会员已于 '+String(st.exp).slice(0,10)+' 过期：解析与复制仍可用，会员功能已锁'):(st.state==='none'?'未激活：解析与复制需要先激活':('授权不可用：'+(st.reason||''))));
  const c=document.getElementById('licContact');if(c)c.textContent=LvLicense.CONTACT;
  await renderDeviceInfo();
  const status=document.getElementById('licStatus');
  if(status){
    if(st.state==='none')status.textContent='把上面这行设备信息（不是只发设备 ID）发给对方，收到授权码后粘到下面激活。';
    else if(st.state==='ok'||st.state==='expired'){
      const snap=await LvLicense.licenseSnapshot();
      status.textContent=snap&&snap.legacy===true
        ?'已激活（旧版授权码）：本地解析、复制、检查更新不受影响；云端 AI 需要换发新版授权——请把上面那行设备信息发给我们换发。'
        :'已激活：本机签名密钥已就绪（只在本机、不可导出）；换设备时用上面那行设备信息重新绑定（绑定的是浏览器安装标识，不是硬件）。';
    }
  }
  return st;
}
(async()=>{
  await refreshLicense();
  const dev=document.getElementById('devCopy');
  if(dev)dev.onclick=async()=>{try{const id=await LvLicense.getDeviceId();await navigator.clipboard.writeText(id);dev.textContent='已复制';setTimeout(()=>dev.textContent='复制设备 ID',1800)}catch(e){dev.textContent='请手动选中复制'}};
  const devInfo=document.getElementById('devInfoCopy');
  if(devInfo)devInfo.onclick=async()=>{const line=devInfo._deviceInfo;if(!line)return;try{await navigator.clipboard.writeText(line);devInfo.textContent='已复制';setTimeout(()=>devInfo.textContent='复制设备信息',1800)}catch(e){devInfo.textContent='请手动选中复制'}};
  const act=document.getElementById('licActivate'),ta=document.getElementById('licText'),sts=document.getElementById('licStatus');
  if(!act)return;
  act.onclick=async()=>{
    if(!ta.value.trim()){sts.textContent='请先粘贴授权码。';return}
    act.disabled=true;act.textContent='激活中…';
    let r={ok:false,reason:'激活失败'};
    try{r=await LvLicense.activate(ta.value)}catch(e){r={ok:false,reason:'激活失败：'+((e&&e.message)||e)}}
    act.disabled=false;act.textContent='激活';
    sts.textContent=r.ok?(r.state==='expired'?r.reason:'已激活，可以导入简历了。'):(r.reason||'激活失败');
    sts.className='status'+(r.ok?' success':' error');
    if(r.ok){ta.value='';await refreshLicense()}
  };
})();
