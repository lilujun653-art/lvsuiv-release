// 简历随行 · 复制面板 v4（依据：02-方案-UI设计.md 的独立设计 + 比对定稿）
// 原则：复制的是"你确认过的完整正文"，不截断、不改写、不往网页写任何内容。
// v4 变更（对 v3 的差异）：
//  1) 去掉首屏营销口号；顶部只留「产品名 + 档案身份/状态 + 编辑档案」一处入口
//  2) 经历改轻列表：标题（可换行）+ 角色·日期 + 两行预览 + 「展开全文」「展开字段」两个独立入口
//  3) 复制入口常驻可见（不再靠 hover 才出现），命中区 ≥32px，键盘可达
//  4) 复制成功保留标签与值，只在固定图标位切勾；常驻「最近复制」状态槽（不用会消失的 toast）
//  5) 动效全部 ≤120ms、只动 opacity/transform，支持 prefers-reduced-motion（降级为 0ms 切换）
//  6) 失败兜底：完整载荷文本框 + 已全选 + 「重新全选」+ 关闭后焦点回到触发项
//  7) 版本号取自 manifest（唯一真源），不手写版本串
const $ = s => document.querySelector(s);
const SVGNS = 'http://www.w3.org/2000/svg';
const FEEDBACK_MS = 1200;          // 成功标识停留时长（非过渡时长）

const GROUP_LABELS = {basic:'基本信息',intent:'求职意向',education:'教育经历',internship:'实习经历',work:'工作经历',project:'项目经历',language:'语言能力',award:'获奖经历',certificate:'证书'};
const FIELD_LABELS = {email:'邮箱',phone:'手机号码',dialCode:'电话区号',gender:'性别',birthDate:'出生日期',experience:'工作经验',highestLevel:'最高学历',location:'所在地',latestCompany:'最近公司',selfDescription:'自我评价',unfiled:'未归位内容',skills:'专业技能',idNumber:'证件号',idType:'证件类型',politicalStatus:'政治面貌',ethnicity:'民族',hometown:'籍贯',currentResidence:'现居住地',height:'身高',weight:'体重',nationality:'国籍',maritalStatus:'婚否',nativePlace:'生源地',studyMode:'学习形式',graduateType:'应届/往届',age:'年龄',
applicationCity:'申请工作城市',expectedRole:'期望从事职业',expectedCity:'期望工作城市',expectedIndustry:'期望从事行业',expectedSalary:'期望薪资',currentSalary:'当前薪资',jobType:'求职类型',currentStatus:'当前状态',available:'到岗时间',obeyAdjust:'是否服从调剂',
school:'学校名称',major:'专业名称',degree:'学位',level:'学历',start:'开始时间',end:'结束时间',company:'单位名称',role:'职位/角色',description:'描述',responsibilities:'职责',proficiency:'掌握程度',speaking:'听说',writing:'读写',date:'时间',ongoing:'是否至今'};
const QUICK_MAIN = [
  {g:'basic',k:'name'},{g:'basic',k:'phone'},{g:'basic',k:'email'},
  {g:'education',k:'school'},{g:'education',k:'major'},{g:'intent',k:'expectedRole'}
];
const QUICK_MORE = [
  {g:'basic',k:'highestLevel'},{g:'basic',k:'politicalStatus'},{g:'basic',k:'hometown'},
  {g:'basic',k:'birthDate'},{g:'basic',k:'ethnicity'},{g:'basic',k:'selfDescription'},{g:'basic',k:'unfiled'},
  {g:'intent',k:'expectedCity'},{g:'intent',k:'expectedSalary'},{g:'intent',k:'available'},
  {g:'education',k:'level'},{g:'basic',k:'idNumber'}
];
const ENTRY_GROUPS = ['education','internship','work','project','language','award','certificate'];
const ANCHORS = {education:['school','major'],internship:['company','role'],work:['company','role'],project:['name','role'],language:['name'],award:['name'],certificate:['name']};
const BODY_KEYS = ['description','responsibilities'];
const SENSITIVE = ['idNumber','idType'];
let profile = null, showSensitive = false, keyword = '', lastTrigger = null;
const openState = Object.create(null);

const has = v => v !== undefined && v !== null && v !== '' && !(typeof v === 'string' && !v.trim());
const fmt = v => (v === true ? '是' : v === false ? '否' : String(v));
function labelOf(k, g){
  if(k==='name') return g==='basic' ? '姓名' : (g==='project' ? '项目名称' : (g==='certificate' ? '证书名称' : (g==='award' ? '奖项名称' : '名称')));
  return FIELD_LABELS[k] || k;
}
const visible = k => showSensitive || !SENSITIVE.includes(k);
const obj = g => { const v = profile && profile[g]; return (v && typeof v==='object' && !Array.isArray(v)) ? v : {}; };
const records = g => { const v = profile && profile[g]; return Array.isArray(v) ? v : []; };
const firstRecord = g => records(g).find(e => e && typeof e==='object' && Object.values(e).some(has));

// ---- 极简 DOM 构造（不用 innerHTML）----
function el(tag, attrs={}, ...kids){
  const n = document.createElement(tag);
  for(const [k,v] of Object.entries(attrs)){
    if(v === false || v == null) continue;
    if(k === 'text') n.textContent = v;
    else if(k === 'class') n.className = v;
    else n.setAttribute(k, v);
  }
  for(const k of kids) if(k != null) n.append(k);
  return n;
}
const ICONS = {
  copy: [['rect',{x:9,y:9,width:11,height:11,rx:2}],['path',{d:'M5 15V5a2 2 0 0 1 2-2h10'}]],
  tick: [['path',{d:'m5 14 4 4L19 7','stroke-width':2.4}]],
  search: [['circle',{cx:11,cy:11,r:7}],['path',{d:'m20 20-3.2-3.2'}]]
};
function icon(name, cls, size=14){
  const svg = document.createElementNS(SVGNS,'svg');
  svg.setAttribute('width',size); svg.setAttribute('height',size); svg.setAttribute('viewBox','0 0 24 24');
  svg.setAttribute('fill','none'); svg.setAttribute('stroke','currentColor'); svg.setAttribute('stroke-width','1.7');
  svg.setAttribute('stroke-linecap','round'); svg.setAttribute('aria-hidden','true');
  if(cls) svg.setAttribute('class',cls);
  for(const [t,a] of (ICONS[name]||[])){
    const e = document.createElementNS(SVGNS,t);
    for(const [k,v] of Object.entries(a)) e.setAttribute(k,v);
    svg.append(e);
  }
  return svg;
}

// ---- 状态槽（常驻，替代会消失的 toast）----
function setStatus(text, bad){
  const s = $('#status'); if(!s) return;
  s.textContent = text; s.classList.toggle('bad', !!bad);
}

// ---- 复制 ----
function legacyCopy(text){
  try{
    const ta=document.createElement('textarea'); ta.value=text; ta.setAttribute('readonly','');
    ta.style.cssText='position:fixed;top:-1000px;left:-1000px';
    document.body.append(ta); ta.select();
    const ok=document.execCommand('copy'); ta.remove(); return !!ok;
  }catch(e){ return false }
}
function offerManual(text, msg, trigger){
  const box=$('#manual'); if(!box) return;
  lastTrigger = trigger || null;
  const ta = el('textarea',{class:'manualText',readonly:'', 'aria-label':'待复制内容'});
  ta.value = text;
  const reselect = el('button',{class:'btn',type:'button',text:'重新全选'});
  const close = el('button',{class:'btn',type:'button',text:'关闭'});
  reselect.onclick = () => { ta.focus(); ta.select() };
  close.onclick = () => {
    box.hidden = true; box.replaceChildren();
    if(lastTrigger && document.contains(lastTrigger)) lastTrigger.focus();
  };
  box.replaceChildren(el('div',{class:'manualHint',text:msg}), ta, el('div',{class:'manualBar'}, reselect, close));
  box.hidden = false;
  ta.focus(); ta.select();
}
const hideManual = () => { const b=$('#manual'); if(b){ b.hidden=true; b.replaceChildren(); } };

function flashIcon(btn, ok){
  if(!btn) return;
  btn.classList.toggle('ok', ok);
  clearTimeout(btn._t); btn._t = setTimeout(()=>btn.classList.remove('ok'), FEEDBACK_MS);
}
function flashCell(cell, ok){
  if(!cell) return;
  cell.classList.toggle('ok', ok);
  clearTimeout(cell._t); cell._t = setTimeout(()=>cell.classList.remove('ok'), FEEDBACK_MS);
}
function flashBtn(btn, text){
  if(!btn) return;
  const done = btn.querySelector('.done'); if(done) done.textContent = text;
  btn.classList.add('busy');
  clearTimeout(btn._t); btn._t = setTimeout(()=>btn.classList.remove('busy'), FEEDBACK_MS);
}
async function copyText(text, opts={}){
  const {btn=null, source='', kind=''} = opts;
  // 动作级门禁（审计 H2）：不靠 disabled——未激活 / 设备不符 / 授权被撤后，复制一律拒绝
  // （复制设备 ID 例外：那是激活流程本身要用的）
  if(!opts.allowNoLicense && !(lastLic.state === 'ok' || lastLic.state === 'expired')){
    setStatus('未激活：复制功能需要先激活。', true); return
  }
  let ok=false, err=null;
  try{
    if(navigator.clipboard && navigator.clipboard.writeText){
      try{ await navigator.clipboard.writeText(text); ok=true }catch(e){ err=e }
    }
    if(!ok) ok = legacyCopy(text);
  }catch(e){ err = err || e }
  if(ok){
    if(btn && btn.classList.contains('copyBtn')) flashIcon(btn, true);
    else if(btn && btn.classList.contains('quickCell')) flashCell(btn, true);
    else if(btn) flashBtn(btn, '✓ 已复制');
    hideManual();
    setStatus('最近复制：' + source + (kind ? ' · ' + kind : ''));
    return true;
  }
  if(btn){
    if(btn.classList.contains('copyBtn')) flashIcon(btn,false);
    else if(btn.classList.contains('quickCell')) flashCell(btn,false);
    else flashBtn(btn,'复制失败');
  }
  const m = lastTrigger = (opts.trigger || btn);
  offerManual(text, '复制失败（'+((err&&err.message)||'浏览器拒绝写入剪贴板')+'）。下面是本次要复制的完整内容，已全选，可直接 Ctrl+C：', m);
  setStatus('复制失败：已给出完整内容，可手动复制', true);
  return false;
}

// ---- 渲染 ----
function row(k, v, g){
  const lb = labelOf(k, g);
  const b = el('button',{class:'copyBtn',type:'button','aria-label':'复制'+lb});
  b.append(icon('copy','ic'), icon('tick','tk'));
  b.onclick = () => copyText(fmt(v), {btn:b, source:lb, trigger:b});
  return el('div',{class:'row'}, el('div',{class:'rowLabel',text:lb}), el('div',{class:'rowValue',text:fmt(v)}), b);
}
function entryTitle(g, e){
  const parts = (ANCHORS[g]||[]).map(k=>e[k]).filter(has);
  return parts.length ? parts.join(' · ') : '这段经历';
}
function entryMeta(g, e){
  const role = (g==='education') ? '' : (e.role || '');
  const span = [e.start, e.end].filter(has).join(' ~ ');
  return [role, span].filter(has).join(' · ');
}
function quickCell(label, value){
  const cell = el('button',{class:'quickCell',type:'button','aria-label':'复制'+label+'：'+String(value)});
  cell.append(el('span',{class:'qk',text:label}), el('span',{class:'qv',text:String(value)}));
  cell.onclick = () => copyText(fmt(value), {btn:cell, source:label, trigger:cell});
  return cell;
}
function quickSource(q){
  if(!visible(q.k)) return null;
  if(q.g==='basic' || q.g==='intent'){
    const v = obj(q.g)[q.k];
    return has(v) ? {v, label:labelOf(q.k, q.g)} : null;
  }
  const e = firstRecord(q.g);
  if(!e || !has(e[q.k])) return null;
  return {v:e[q.k], label:GROUP_LABELS[q.g].replace('经历','').replace('能力','')+' · '+labelOf(q.k, q.g)};
}
function renderQuick(box, list){
  if(!box) return 0;
  box.replaceChildren();
  let n=0;
  for(const q of list){
    const item = quickSource(q);
    if(!item) continue;
    box.append(quickCell(item.label, item.v)); n++;
  }
  if(!n) box.append(el('div',{class:'empty small',text:'档案里还没有这些信息。'}));
  return n;
}
function renderPanel(){
  const box = $('#copyPanel'); box.replaceChildren();
  const empty = $('#copyEmpty');
  const kw = keyword.trim().toLowerCase();
  const hit = (k,v,g) => !kw || labelOf(k,g).toLowerCase().includes(kw) || String(v).toLowerCase().includes(kw);
  let shown = 0;
  const addSection = (key, title, nodes) => {
    if(!nodes.length) return;
    const det = el('details',{class:'group'}); det.dataset.key = key;
    det.open = kw ? true : (openState[key] !== undefined ? openState[key] : key==='basic');
    det.addEventListener('toggle', ()=>{ if(!keyword.trim()) openState[key]=det.open; syncExpandAll() });
    const sum = el('summary',{}, el('span',{text:title}), el('span',{class:'count',text:String(nodes.length)}));
    det.append(sum);
    for(const n of nodes) det.append(n);
    box.append(det); shown += nodes.length;
  };
  for(const g of ['basic','intent']){
    const nodes=[];
    for(const [k,v] of Object.entries(obj(g))){
      if(!has(v) || !visible(k) || !hit(k,v,g)) continue;
      nodes.push(row(k,v,g));
    }
    addSection(g, GROUP_LABELS[g], nodes);
  }
  for(const g of ENTRY_GROUPS){
    const arr = records(g).filter(e=>e && typeof e==='object' && Object.values(e).some(has));
    if(!arr.length) continue;
    const nodes=[];
    arr.forEach((e)=>{
      const allFields = Object.entries(e).filter(([k,v])=>has(v) && visible(k));   // 完整载荷（不受搜索影响）
      if(!allFields.length) return;
      const shownFields = allFields.filter(([k,v])=>hit(k,v,g));                    // 展示字段（受搜索影响）
      if(!shownFields.length) return;
      const card = el('div',{class:'entry'});
      const gl = GROUP_LABELS[g].replace('经历','').replace('能力','');
      const title = entryTitle(g,e);
      card.append(el('div',{class:'ehead'}, el('div',{class:'etitle',text:title})));
      const meta = entryMeta(g,e);
      if(meta) card.append(el('div',{class:'emeta',text:meta}));
      const bodyVals = allFields.filter(([k])=>BODY_KEYS.includes(k)).map(([,v])=>String(v));
      const preview = bodyVals.length ? bodyVals.join('\n')
                                      : allFields.slice(0,2).map(([k,v])=>labelOf(k,g)+'：'+fmt(v)).join(' · ');
      if(preview){
        const p = el('div',{class:'ebody',text:preview});
        const fold = el('button',{class:'link',type:'button',text:'展开全文'});
        fold.onclick = () => { const open = p.classList.toggle('full'); fold.textContent = open ? '收起全文' : '展开全文' };
        card.append(p, fold);
        requestAnimationFrame(()=>{ fold.hidden = p.scrollHeight <= p.clientHeight + 2 });
      }
      const acts = el('div',{class:'acts'});
      const whole = el('button',{class:'btn primary',type:'button'},
                       el('span',{class:'lbl',text:'复制整段'}), el('span',{class:'done',text:'✓ 已复制'}));
      whole.setAttribute('aria-label','复制整段（'+title+'，'+allFields.length+' 项）');
      whole.onclick = () => copyText(allFields.map(([k,v])=>labelOf(k,g)+'：'+fmt(v)).join('\n'),
                                     {btn:whole, source:gl+'：'+title, kind:'整段', trigger:whole});
      acts.append(whole);
      if(bodyVals.length){
        const bb = el('button',{class:'btn',type:'button'},
                      el('span',{class:'lbl',text:'复制正文'}), el('span',{class:'done',text:'✓ 已复制'}));
        bb.setAttribute('aria-label','复制正文（'+title+'）');
        bb.onclick = () => copyText(bodyVals.join('\n'), {btn:bb, source:gl+'：'+title, kind:'正文', trigger:bb});
        acts.append(bb);
      }
      const fbtn = el('button',{class:'btn ghost',type:'button',text:'展开字段'});
      const fields = el('div',{class:'fields',hidden:''});
      for(const [k,v] of allFields) fields.append(row(k,v,g));
      fbtn.onclick = () => { const open = fields.hidden; fields.hidden = !open; fbtn.textContent = open ? '收起字段' : '展开字段' };
      acts.append(fbtn);
      card.append(acts, fields);
      nodes.push(card);
    });
    addSection(g, GROUP_LABELS[g]+'（'+arr.length+' 段）', nodes);
  }
  if(!shown){
    empty.hidden = false; empty.replaceChildren();
    const p = el('div',{text: kw ? ('没有匹配「'+keyword+'」的字段。') : '档案里还没有内容，先去「编辑档案」填写或导入简历。'});
    const b = el('button',{class:'btn',type:'button',text:'去编辑档案'});
    b.onclick = () => chrome.runtime.openOptionsPage();
    empty.append(p,b);
  } else empty.hidden = true;
}
function syncExpandAll(){
  const btn = $('#expandAll'); if(!btn) return;
  if(keyword.trim()){ btn.disabled = true; btn.textContent = '搜索中自动展开'; return }
  btn.disabled = false;
  const els = [...document.querySelectorAll('#copyPanel details.group')];
  if(!els.length){ btn.textContent = '展开全部'; return }
  btn.textContent = els.some(d=>!d.open) ? '展开全部' : '折叠全部';
}
function renderAll(){
  renderQuick($('#quick'), QUICK_MAIN);
  const n = renderQuick($('#quickMoreBody'), QUICK_MORE);
  const c = $('#quickMoreCount'); if(c) c.textContent = String(n);
  renderPanel(); syncExpandAll();
}

// ---- 授权（一码一机）：未激活只显示激活入口；「检查更新」不受影响 ----
// 依据：设计/授权方案-一码一机.md —— 未激活：解析/复制不可用；买断：解析+复制；会员：再加自动填/AI/岗位表
const LOCKED = () => document.querySelector('#locked');
function setLocked(on){
  const wrap = $('#searchWrap'), qb = $('#quickBlock'), pb = $('#panelBlock'), lk = LOCKED();
  if(wrap) wrap.hidden = on;
  if(qb) qb.hidden = on;
  if(pb) pb.hidden = on;
  if(lk) lk.hidden = !on;
}
let lastLic = { state: 'none' };      // 最近一次授权状态：动作级门禁用（不靠按钮 disabled）
async function renderDeviceInfo(){
  const devId = $('#devId'), devInfo = $('#devInfo'), copy = $('#devInfoCopy');
  if(copy) copy.disabled = false;
  let device = '';
  try {
    device = await LvLicense.getDeviceId();
    if(devId) devId.textContent = device;
  } catch (e) {
    if(devId) devId.textContent = '读取失败，请在「编辑档案」里查看';
  }
  try {
    const info = await LvLicense.__core.deviceInfo();
    if(devInfo) devInfo.textContent = info.line;
    if(copy) copy._deviceInfo = info.line;
  } catch (e) {
    if(devInfo) devInfo.textContent = '本机设备密钥不可用（本地功能不受影响），请联系我们';
    if(copy) { copy.disabled = true; copy._deviceInfo = ''; }
  }
}
async function loadLicense(){
  let st = { state: 'none', reason: '未激活' };
  try { st = await LvLicense.getState() } catch (e) { st = { state: 'invalid', reason: '授权读取失败' } }
  const badge = $('#licBadge');
  const usable = st.state === 'ok' || st.state === 'expired';       // 过期 = 降级为买断功能，档案不动
  lastLic = st;
  if(badge){
    badge.textContent = st.state === 'ok'
      ? (st.plan === 'member' ? ('会员' + (st.exp === 'never' ? '' : '至 ' + String(st.exp).slice(0, 10))) : '基础版')
      : (st.state === 'expired' ? '会员已过期' : '未激活');
  }
  setLocked(!usable);
  await renderDeviceInfo();
  const st2 = $('#licStatus');
  if(st2){
    if(st.state === 'none') st2.textContent = '把上面这行设备信息（不是只发设备 ID）发给对方，收到授权码后粘到下面激活。';
    else if(st.state === 'ok' || st.state === 'expired') {
      const snap = await LvLicense.licenseSnapshot();
      st2.textContent = snap && snap.legacy === true
        ? '已激活（旧版授权码）：本地解析、复制、检查更新不受影响；云端 AI 需要换发新版授权——请把上面那行设备信息发给我们换发。'
        : '已激活：本机签名密钥已就绪（只在本机、不可导出）；换设备时用上面那行设备信息重新绑定（绑定的是浏览器安装标识，不是硬件）。';
    } else if(st.state !== 'expired') st2.textContent = st.reason || '授权不可用';
  }
  if(usable) return st;
  // 未激活 / 授权无效 / 设备不匹配：不渲染任何档案内容，只给激活入口
  // 转场也要清干净（会员→被解除/被换设备时，旧 DOM 里不能留着上一次渲染的档案内容）
  profile = null; showSensitive = false; keyword = '';
  ['#quick','#quickMoreBody','#copyPanel','#manual'].forEach(sel => { const n = $(sel); if(n) n.replaceChildren(); });
  const moreCount = $('#quickMoreCount'); if(moreCount) moreCount.textContent = '';
  const mBtn = $('#manual'); if(mBtn) mBtn.hidden = true;
  $('#profileSummary').textContent = LvLicense.reasonText(st.state);
  const contact = $('#lockContact'); if(contact) contact.textContent = ' ' + LvLicense.CONTACT;
  const ta = $('#licText');
  setStatus(st.state === 'none' ? '未激活：激活后即可解析与复制' : (st.reason || '授权不可用'), st.state !== 'none');
  return st;
}
function wireLicenseUI(){
  const copyBtn = $('#devCopy'), infoCopyBtn = $('#devInfoCopy'), actBtn = $('#licActivate'), openBtn = $('#licOpen'), ta = $('#licText');
  if(copyBtn) copyBtn.onclick = async () => {
    let dev = '';
    try { dev = await LvLicense.getDeviceId() } catch (e) { setStatus('设备 ID 读取失败', true); return }
    await copyText(dev, { btn: copyBtn, source: '本机设备 ID', trigger: copyBtn, allowNoLicense: true });
  };
  if(infoCopyBtn) infoCopyBtn.onclick = async () => {
    const line = infoCopyBtn._deviceInfo;
    if(!line) return;
    const ok = await copyText(line, { btn: infoCopyBtn, source: '本机设备信息', trigger: infoCopyBtn, allowNoLicense: true });
    if(!ok) infoCopyBtn.textContent = '请手动选中复制';
    else { infoCopyBtn.textContent = '已复制'; setTimeout(() => { infoCopyBtn.textContent = '复制设备信息'; }, FEEDBACK_MS); }
  };
  if(openBtn) openBtn.onclick = () => chrome.runtime.openOptionsPage();
  if(!actBtn) return;
  actBtn.onclick = async () => {
    const text = (ta && ta.value) || '';
    if(!text.trim()){ $('#licStatus').textContent = '请先粘贴授权码。'; return }
    actBtn.disabled = true; actBtn.textContent = '激活中…';
    let r = { ok: false, reason: '激活失败' };
    try { r = await LvLicense.activate(text) } catch (e) { r = { ok: false, reason: '激活失败：' + ((e && e.message) || e) } }
    actBtn.disabled = false; actBtn.textContent = '激活';
    $('#licStatus').textContent = r.ok ? (r.state === 'expired' ? r.reason : '已激活，可以开始复制了。') : (r.reason || '激活失败');
    if(r.ok) await load();
  };
}

let loadGen = 0;
async function load(){
  const gen = ++loadGen;                                       // 代次：晚返回的旧任务一律作废
  const st = await loadLicense();
  if(gen !== loadGen) return;
  if(!(st.state === 'ok' || st.state === 'expired')) return;   // 未激活：DOM 里不出现任何档案内容
  let raw;
  try{ raw = (await chrome.storage.local.get('profile')).profile }
  catch(err){
    $('#profileSummary').textContent = '档案读取失败';
    setStatus('档案读取失败：'+((err&&err.message)||err), true); return
  }
  if(gen !== loadGen) return;                                  // 期间又触发了新的 load：这次结果作废，避免把清空后的 DOM 填回去
  profile = (raw && typeof raw==='object') ? raw : null;
  const confirmed = !!(profile && profile.confirmed);
  const nm = obj('basic').name || '未命名';
  $('#profileSummary').textContent = profile ? (nm + ' · ' + (confirmed ? '档案已确认' : '档案未确认（请先确认）')) : '尚未建立档案';
  setStatus(st.state === 'expired'
    ? ('会员已于 ' + String(st.exp).slice(0, 10) + ' 过期：买断功能仍可用')
    : (profile ? '尚未复制' : '先去「编辑档案」建立档案'), st.state === 'expired');
  try{ renderAll() }catch(e){ setStatus('档案数据有问题，无法显示：'+((e&&e.message)||e), true) }
}

// ---- 事件 ----
const search = $('#search'), expand = $('#expandAll'), profileBtn = $('#profile'), sensBtn = $('#showSensitive');
if(search){
  search.oninput = e => { keyword = e.target.value; renderPanel(); syncExpandAll() };
  search.focus();
}
if(expand) expand.onclick = () => {
  const els = [...document.querySelectorAll('#copyPanel details.group')];
  const anyClosed = els.some(d=>!d.open);
  els.forEach(d=>{ d.open = anyClosed; if(d.dataset.key) openState[d.dataset.key] = anyClosed });
  syncExpandAll();
};
if(profileBtn) profileBtn.onclick = () => chrome.runtime.openOptionsPage();
if(sensBtn) sensBtn.onclick = () => {
  showSensitive = !showSensitive;
  sensBtn.textContent = showSensitive ? '隐藏敏感字段' : '显示敏感字段';
  sensBtn.setAttribute('aria-pressed', String(showSensitive));
  renderAll();
};
document.addEventListener('keydown', e => {
  if((e.ctrlKey||e.metaKey) && String(e.key).toLowerCase()==='f'){ e.preventDefault(); search.focus(); search.select(); return }
  if(e.key === 'Escape' && document.activeElement === search && search.value){ search.value=''; keyword=''; renderPanel(); syncExpandAll() }
});
if(chrome.storage && chrome.storage.onChanged){
  chrome.storage.onChanged.addListener((ch, area)=>{ if(area==='local' && (ch.profile || ch.license || ch.deviceId)) load() });
}
const ver = (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '—';
const verEl = $('#ver'); if(verEl) verEl.textContent = 'v' + ver;
const updateBtn = $('#checkUpdate'), updateStatus = $('#updateStatus');
const UPDATE_FAIL = '检查失败：网络或服务不可用，可稍后重试';
// 按钮永远只做「检查」；有新版时把下载入口放进状态区（实测教训：按钮一旦变成"打开下载页"，
// 用户就再也无法重新检查——服务恢复、换网络、确认是否已升上去都做不到）
updateBtn.onclick = async () => {
  updateBtn.disabled = true; updateBtn.textContent = '检查中…';
  updateStatus.textContent = '';
  let text = UPDATE_FAIL, result = null;
  try {
    result = await window.LvUpdate.check();
    // 真机断言用的只读钩子（不含任何敏感信息）：让测试台能拿到结构化终态，而不是靠猜界面文案
    window.__lastUpdateResult = result || null;
    window.__lastUpdateState = (result && result.state) || '';
    window.__lastUpdateDetail = (result && result.detail) || '';
    window.__lastUpdateZipUrl = (result && result.zip && result.zip.url) || '';
    if(result.state === 'latest') text = '已是最新 v' + ver;
    else if(result.state === 'newer') text = '有新版 v' + result.remote.replace(/^v/, '');
    else if(result.state === 'error') text = updateErrorText(result.detail);
  } catch (_) {}
  updateBtn.disabled = false; updateBtn.textContent = '检查更新';
  updateStatus.textContent = text;
  if(result && result.state === 'newer'){
    const a = document.createElement('a');
    a.href = '#'; a.textContent = '下载并校验更新包';
    a.onclick = async e => { e.preventDefault(); a.setAttribute('aria-disabled', 'true'); updateStatus.textContent = '正在校验更新包…'; const opened = await window.LvUpdate.openVerifiedPackage(result); updateStatus.textContent = opened.ok ? '已通过哈希校验，正在打开' : updateErrorText(opened.code); };
    updateStatus.append(' · ', a);
  }
};
function updateErrorText(code){return code==='rollback-refused'?'远端版本比本机旧，已拒绝（防降级）':code==='zip-hash-mismatch'?'更新包哈希不匹配，已拒绝（可能被替换）':code==='missing-sha256'?'清单缺少哈希，已拒绝':code==='invalid-url'?'只允许 https':'更新包校验失败：'+(code||'request-failed')}

wireLicenseUI();
load();
