// 简历随行 · 识别层（v0.5 重写）
// 职责：标签多源读取、去噪归一化、打分匹配、歧义保护、枚举互认、值适配。
// 保持导出 CampusEngine.{normalize, groupOf, classify, chooseOption, adaptValue} 向后兼容。
(function(root){
  // ---------- 归一化 ----------
  // 全角转半角
  const half=s=>s.replace(/[！-～]/g,c=>String.fromCharCode(c.charCodeAt(0)-0xFEE0)).replace(/　/g,' ');
  // 基础归一化：小写、半角、去空白与常见标点、去星号
  const normalize=s=>half(String(s||'')).toLowerCase().replace(/[\s*＊:：,，.。()（）\[\]【】\-—_/\\|、;；'"""'']/g,'').replace(/必填|required/g,'');
  // 去噪：在 normalize 基础上再去掉提示性前后缀，用于"请输入您的姓名"这类标签
  const NOISE=/^(请输入|请填写|请选择|输入|填写|选择|您的|你的|请)|（选填）|\(选填\)|（必填）|\(必填\)|选填/g;
  const denoise=s=>normalize(s).replace(NOISE,'');
  // 占位项（下拉中不得选中的"请选择"类选项）
  const isPlaceholder=s=>/^(请选择|请选择.*|选择|select.*|pleaseselect.*|--.*|—+.*|请选择或输入.*)$/i.test(normalize(s))||!normalize(s);

  // ---------- 字段规则（别名表） ----------
  const rules={
    basic:{name:['姓名','真实姓名','中文姓名','名字','name','fullname','username','applicantname'],email:['邮箱','电子邮箱','电子邮件','邮箱地址','email','emailaddress','mail'],phone:['手机','手机号','手机号码','联系电话','联系电话手机','电话','mobile','mobilephone','phonenumber','tel'],dialCode:['电话区号','区号'],gender:['性别','gender','sex'],birthDate:['出生日期','出生年月','生日','birthdate','birthday','dateofbirth'],experience:['工作经验','工作年限'],highestLevel:['最高学历'],location:['所在地','所在城市'],latestCompany:['最近公司'],selfDescription:['自我描述','自我评价','个人评价','自我介绍','个人简介','selfdescription','selfevaluation'],skills:['专业技能','技能特长','相关技能','技能专长','专长','技能','擅长技能','擅长什么','特长技能'],
      idNumber:['证件号','证件号码','证件编号','身份证号','身份证号码','idcard','idnumber'],politicalStatus:['政治面貌','politicalstatus'],ethnicity:['民族','ethnicity'],hometown:['籍贯','户籍','户籍所在地','户籍地','户籍地址','户口所在地','hometown'],currentResidence:['现居住地','现居地','现住址','居住地址','家庭住址','通讯地址','常住地址','currentresidence','address'],height:['身高','height'],age:['年龄'],
      idType:['证件类型','身份证件类型','证件种类'],nationality:['国籍'],maritalStatus:['婚否','婚姻状况','婚姻状态'],studyMode:['学习形式','培养方式','学习方式','就读形式'],graduateType:['应届/往届','应届往届','毕业类型','考生类别'],nativePlace:['生源地','高考生源地','生源'],weight:['体重']},
    education:{school:['学校','学校名称','毕业院校','院校名称','就读院校','毕业学校','院校','school','university','schoolname'],major:['专业','专业名称','所学专业','major','majorname','主修方向','主修专业','专业方向','所学方向','主修课程方向'],degree:['学位','degree'],level:['学历','教育程度','educationlevel','最高学历'],start:['开始时间','开始日期','入学时间','入学日期','startdate'],end:['结束时间','结束日期','毕业时间','毕业日期','enddate']},
    internship:{company:['实习单位','公司名称','单位名称','企业名称','实习公司','company','employer','companyname'],role:['实习岗位','实习职位','岗位名称','职位名称','职务','position','jobtitle'],start:['开始时间','开始日期','入职时间','入职日期','startdate'],end:['结束时间','结束日期','离职时间','离职日期','enddate'],description:['工作描述','工作内容','实习内容','实习描述','职责描述','岗位职责','工作职责','description','responsibilities'],ongoing:['是否至今']},
    work:{company:['公司名称','单位名称','工作公司','company'],role:['职位名称','职务','岗位'],start:['开始时间','入职时间'],end:['结束时间','离职时间'],description:['工作职责','工作描述'],ongoing:['是否至今']},
    project:{name:['项目名称','projectname'],role:['项目角色','担任角色','项目职务','role','职责'],responsibilities:['项目中职责'],start:['开始时间','开始日期','项目开始时间','startdate'],end:['结束时间','结束日期','项目结束时间','enddate'],description:['项目描述','项目介绍','项目内容','项目职责','description'],ongoing:['是否至今']},
    intent:{applicationCity:['意向工作城市','意向城市','工作城市','本次申请工作城市'],expectedRole:['意向岗位','意向职位','应聘岗位','目标岗位','求职岗位','期望岗位','期望从事职业','期望职业','期望职位','期望从事岗位','期望工作类型','期望工作','应聘职位','申请职位','从事工作'],expectedCity:['期望城市','期望工作城市','期望工作地点','期望地点','期望工作地区'],jobType:['求职类型','工作性质','求职性质','应聘类型'],expectedIndustry:['期望行业','意向行业','目标行业','期望从事行业','期望所属行业'],currentStatus:['当前状态','目前状态','求职状态','在职状态'],currentSalary:['当前薪资','目前薪资'],expectedSalary:['期望薪资','期望月薪','期望年薪','salary'],available:['到岗时间','预计报到时间','报到时间','最快到岗时间','可到岗时间'],obeyAdjust:['是否服从工作地点调配','服从工作地点调配','服从调剂','是否服从调剂','服从分配','接受调剂','能否服从调剂','服从岗位调剂','是否服从岗位调剂','服从专业调剂','是否服从专业调剂','是否接受调配','接受调配','是否接受调整','是否接受调剂','能否接受调配']},
    language:{name:['语言类型','语种','语言'],proficiency:['掌握程度','熟练程度','英语等级','外语水平','英语水平','语言等级','等级水平'],speaking:['听说'],writing:['读写']},
    award:{date:['获奖时间'],name:['奖项名称','奖励名称','获奖名称']},
    certificate:{name:['证书名称','证书','资格名称','证书项目','certificatename'],level:['证书等级','等级','成绩'],date:['获得时间','取得时间','获证时间','考试时间']}
  };

  // ---------- 枚举互认表（同组内任意两个值视为等价） ----------
  // 只有"确实等价"的写法才放进同一组；不同身份/不同层级的绝不放一起（否则会确定性填错）
  const ENUMS=[
    ['大专','专科','大学专科','高职'],
    ['本科','大学本科','全日制本科','本科及以上','本科生'],
    ['硕士','硕士研究生','研究生','硕士生','硕士学位'],
    ['博士','博士研究生','博士生','博士学位'],
    ['学士','学士学位'],
    ['男','男性','male'],
    ['女','女性','female'],
    ['中共党员','中国共产党党员','正式党员'],
    ['中共预备党员','预备党员'],
    ['共青团员','团员'],
    ['群众'],
    ['无党派人士'],
    ['汉族','汉'],
    ['中国','中华人民共和国','中国大陆'],
    ['全日制','普通全日制','全日制统招'],
    ['应届','应届生','应届毕业生'],
    ['往届','往届生'],
    ['至今','现在','今','目前','present','now']
  ];
  const enumIndex=new Map();
  ENUMS.forEach((group,i)=>group.forEach(v=>{const k=normalize(v);if(!enumIndex.has(k))enumIndex.set(k,i)}));
  const enumSame=(a,b)=>{const x=enumIndex.get(normalize(a)),y=enumIndex.get(normalize(b));return x!==undefined&&x===y};

  // ---------- 年月解析：2024.09 / 2024-9 / 2024年9月 / 2024/9 → 2024-09 ----------
  function parseYearMonth(v){const m=String(v||'').trim().match(/(\d{4})\s*[年.\-/]\s*(0?[1-9]|1[0-2])\s*月?$/);return m?m[1]+'-'+m[2].padStart(2,'0'):null}

  // ---------- 分组识别（标题/区块上下文） ----------
  function groupOf(text){const t=normalize(text);
    if(/紧急联系人|家庭成员|家庭情况|亲属|证明人|推荐人|担保人|emergency|reference|guarantor/.test(t))return 'blocked';
    if(/教育|学历经历|education/.test(t))return 'education';
    if(/实习|internship/.test(t))return 'internship';
    if(/工作经历|工作经验|employment|workexperience/.test(t))return 'work';
    if(/语言能力|语言/.test(t))return 'language';
    if(/获奖经历|奖励/.test(t))return 'award';
    if(/证书|资格/.test(t))return 'certificate';
    if(/申请信息|求职意向|意向/.test(t))return 'intent';
    if(/自我描述|自我评价/.test(t))return 'basic';
    if(/项目|project/.test(t))return 'project';
    if(/基本信息|个人信息|联系方式|basic|personal|contactinformation/.test(t))return 'basic';
    return null}
  // 标签级敏感判定：含这些词的字段永不自动填写
  const sensitive=s=>{const t=normalize(s);return /密码|验证码|短信码|校验码|动态码|口令|支付|银行卡/.test(t)||/password|passcode|verificationcode|captcha|otp|onetimecode|securitycode|authcode/.test(t)};
  // 标签级禁止组：紧急联系人/家庭/证明人/推荐人/担保人
  const blockedLabel=s=>{const t=normalize(s);return /紧急联系人|紧急联络人|家庭成员|家庭主要成员|证明人|推荐人|担保人|emergencycontact|referenceperson|guarantor/.test(t)||/父亲|母亲|家长|监护人|配偶|妻子|丈夫|子女|儿子|女儿|兄弟|姐妹|亲属|father|mother|parent|spouse|guardian/.test(t)};

  // ---------- 打分匹配 ----------
  const MIN_SCORE=60;
  // 单个标签对单个别名打分
  function scoreOne(label,alias){const l=denoise(label),a=normalize(alias);if(!l||!a)return 0;
    if(l===a)return 100;
    if(normalize(label)===a)return 90;
    // 限定词保护："现状"类与"期望"类字段不得互相命中。
    // 实测教训：真机页面上"现工作城市"包含别名"工作城市"→ 74 分命中 intent.applicationCity，
    // 若用户填了意向城市就会把"意向值"写进"现职城市"框 —— 属确定性误填，必须挡住。
    try{
      const NOW=/现|目前|当前|在职/, WANT=/期望|意向|目标|希望/;
      if((NOW.test(l)&&WANT.test(a))||(WANT.test(l)&&NOW.test(a)))return 0;
    }catch{}
    if(l.includes(a))return Math.min(80,70+a.length);       // 标签包含别名，按别名长度加权
    if(l.length>=2&&a.includes(l))return 60;                 // 别名包含标签（标签更短，谨慎给分）
    // 关键词共现：最长公共子串（仅对短标签启用，避免长文本拖慢匹配）
    if(l.length>24)return 0;
    let best=0;for(let i=0;i<l.length;i++)for(let j=i+2;j<=l.length;j++){const sub=l.slice(i,j);if(a.includes(sub)&&sub.length>best)best=sub.length;if(l.length-i<=best)break}
    return best>=2?Math.min(55,40+best*5):0}
  // 对一个字段的所有别名取最高分
  function scoreField(label,aliases){let best=0;for(const a of aliases)best=Math.max(best,scoreOne(label,a));return best}
  // classify：label 可为字符串或候选数组；group 限定分组（null 则全组搜索）
  // 返回 {group,key,score} | {ambiguous:true,candidates:[...]} | null
  function classify(label,group){
    if(group==='blocked')return null;
    const labels=(Array.isArray(label)?label:[label]).map(x=>String(x||'').trim()).filter(Boolean);
    if(!labels.length)return null;
    if(labels.some(blockedLabel))return null; // 禁止分组标签直接不填（content 层另行标记 blocked）
    if(labels.some(sensitive))return null;    // 密码/验证码类标签在识别层也不产出匹配（双保险）
    const groups=group?[group]:Object.keys(rules);
    const scored=[];
    for(const g of groups)for(const [key,aliases]of Object.entries(rules[g]||{})){
      let best=0;for(const l of labels)best=Math.max(best,scoreField(l,aliases));
      if(best>=MIN_SCORE)scored.push({group:g,key,score:best});
    }
    if(!scored.length)return null;
    scored.sort((x,y)=>y.score-x.score);
    const top=scored[0],tie=scored.filter(s=>s.score===top.score);
    if(tie.length>1)return{ambiguous:true,candidates:tie};
    return top;
  }

  // ---------- 选项匹配（原生 select 与自定义下拉共用） ----------
  // options: [{text,value,disabled}]，返回命中的 option（原对象），未命中返回 null
  function matchOption(options,value){
    const usable=options.filter(o=>!o.disabled&&!isPlaceholder(o.text));
    // 1. 归一化完全相等
    let hits=usable.filter(o=>normalize(o.text)===normalize(value));
    // 2. 枚举互认（如"本科"↔"大学本科"）
    if(!hits.length)hits=usable.filter(o=>enumSame(o.text,value));
    // 3. 去噪相等
    if(!hits.length)hits=usable.filter(o=>denoise(o.text)===denoise(value));
    // 4. 包含关系：仅中文允许，且必须唯一命中。英文一律要求全等——否则 male 会匹配到 female
    if(!hits.length){
      const v=denoise(value);
      if(v&&!/^[\x00-\x7F]+$/.test(v)){
        const c=usable.filter(o=>{const t=denoise(o.text);return t&&t.length>=2&&(t.includes(v)||v.includes(t))});
        const uniq=[...new Set(c.map(o=>denoise(o.text)))];
        if(uniq.length===1)hits=c.filter(o=>denoise(o.text)===uniq[0]);
      }
    }
    // 多个候选一律转人工，绝不按长度猜一个
    return hits.length===1?hits[0]:null;
  }
  // 旧接口：返回 option.value
  function chooseOption(options,value){const hit=matchOption(options,value);return hit?hit.value:null}

  // ---------- 值适配 ----------
  function adaptValue(value,type,maxLength){
    if(type==='month'||type==='yearmonth'){const ym=parseYearMonth(value)||(/^\d{4}-(0[1-9]|1[0-2])$/.test(value)?value:null);if(!ym)return{error:'需要明确的年月，请手动确认。'};return{value:ym}}
    if(type==='date'&&!/^\d{4}-\d{2}-\d{2}$/.test(value)){if(parseYearMonth(value))return{error:'网页需要具体日期，档案只有年月，未自动补写日期。'};return{error:'需要明确的日期（YYYY-MM-DD），请手动确认。'}}
    if(type==='number')return{error:'数字字段需手动确认，避免格式或精度变化。'};
    if(maxLength>=0&&String(value).length>maxLength)return{error:'资料超过此字段的字数限制，未截断原文。'};
    return{value:String(value)}
  }

  // ---------- DOM 标签读取（多源，返回候选数组，按优先级排序） ----------
  const LABEL_SELECTOR='.el-form-item__label,.ant-form-item-label,.form-item-label,.field-label,.label,dt,th,[class*=label],[class*=Label]';
  const textOf=n=>{try{const clone=n.cloneNode(true);clone.querySelectorAll('input,select,textarea,button,option').forEach(x=>x.remove());return clone.textContent.replace(/\s+/g,' ').trim()}catch{return ''}};
  function pushUnique(arr,s){s=String(s||'').replace(/\s+/g,' ').trim();if(s&&s.length<=160&&!arr.includes(s))arr.push(s)}
  const FIELD_WORDS=['姓名','电话','手机','邮箱','性别','学校','专业','学历','学位','入学','毕业','公司','岗位','职位','部门','城市','薪资','地址','民族','籍贯','证书','项目','荣誉','描述','内容','时间','日期'];
  // 文本是否像"多个字段名拼接"（如 "基本信息 姓名 联系电话 邮箱地址 性别"）
  // 宁可漏判（把拼接串当标签）也不能误判——"毕业时间"同时含"毕业""时间"两个词，旧规则会把它当拼接串丢掉，
  // 导致北森的"毕业时间"读不到任何标签 → 未识别。改为：3 个以上字段词命中，或 2 个命中且文本够长/带分隔符
  function looksLikeMultiField(t){
    const raw=String(t||'');const s=normalize(raw);let hits=0;
    for(const w of FIELD_WORDS){if(s.includes(normalize(w)))hits++}
    if(hits>=3)return true;
    return hits>=2&&(s.length>=8||/[\s、,，/｜|;；]/.test(raw));
  }
  // 剔除"同时是同一容器内其它控件标签"的候选（防止把相邻字段的标签当成本字段的标签）
  function filterShared(out,ctrl){
    try{
      let node=ctrl.parentElement,hop=0;
      while(node&&node!==document.body&&hop<4){
        const others=[...node.querySelectorAll('input,select,textarea')].filter(e=>e!==ctrl&&(e.type||'')!=='hidden');
        if(others.length){
          const shared=new Set();
          for(const o of others){
            if(o.id){const l=document.querySelector('label[for="'+CSS.escape(o.id)+'"]');if(l)shared.add(textOf(l))}
            const w=o.closest('label');if(w)shared.add(textOf(w));
          }
          if(shared.size){for(let i=out.length-1;i>=0;i--)if(shared.has(out[i]))out.splice(i,1)}
          break;
        }
        node=node.parentElement;hop++;
      }
    }catch{}
  }
  function labelOf(el,opts={}){
    const out=[];const ctrl=el;
    try{
      // 1. label[for] / 包裹式 label
      if(!opts.skipOwnLabel){
        if(ctrl.id){const l=document.querySelector('label[for="'+CSS.escape(ctrl.id)+'"]');if(l)pushUnique(out,textOf(l))}
        const wrap=ctrl.closest('label');if(wrap)pushUnique(out,textOf(wrap));
      }
      // 2. aria-labelledby / aria-label
      const ids=(ctrl.getAttribute('aria-labelledby')||'').split(/\s+/).filter(Boolean);
      for(const id of ids){const t=document.getElementById(id);if(t)pushUnique(out,textOf(t))}
      pushUnique(out,ctrl.getAttribute('aria-label'));
      // 3. placeholder
      //    注意：placeholder 不算"强标签"。北森等页面的 placeholder 是无信息量的"请输入/请选择"，
      //    若把它当强标签，会挡住下面真正有用的容器/兄弟标签提取（实测：北森整页字段全部识别失败）。
      const hasStrong=out.length>0;   // 只统计 label[for]/包裹 label/aria 这类强关联
      pushUnique(out,ctrl.getAttribute('placeholder'));
      // 4. 邻近文本：向上最多 4 层
      //    已有强标签（label[for]/包裹 label/aria）时不再向兄弟节点扩散——否则会把相邻字段的标签误当成本字段的
      let node=ctrl.parentElement,depth=0,cur=ctrl;
      while(node&&node!==document.body&&depth<4){
        // 4a. 只收与本控件真正关联的标签（for 指向本控件，或包裹本控件）
        try{for(const lab of node.querySelectorAll(LABEL_SELECTOR)){
          const linked=(lab.htmlFor&&ctrl.id&&lab.htmlFor===ctrl.id)||lab.contains(ctrl);
          if(linked)pushUnique(out,textOf(lab));
        }}catch{}
        // 4b. 前一个兄弟元素：仅在缺强标签时采用，且必须是"纯标签元素"（不含其它控件、文本短、非多字段拼接）
        if(!hasStrong){
          const sib=cur.previousElementSibling;
          if(sib&&!sib.contains(ctrl)&&!/^(input|select|textarea|button)$/i.test(sib.tagName)){
            const hasCtrl=!!sib.querySelector('input,select,textarea,[contenteditable]');
            const t=textOf(sib);
            if(!hasCtrl&&t&&t.length<=30&&!looksLikeMultiField(t))pushUnique(out,t);
          }
        }
        cur=node;node=node.parentElement;depth++;
      }
      // 4d. 组件库 form-item 容器（北森 Phoenix 等）：字段名与控件在同一容器里，label 是容器的另一个直接子元素。
      //     必须放在上面的 depth 循环之外：北森 select 的包裹层很深（inputWrapper→UL→DIV→unmodeled-layer→…），
      //     4 层循环根本到不了 form-item（实测：整页 21 个 select 全部识别失败）。
      //     只取容器直接子元素里第一个"不含其它控件"的短文本节点，避免误把整块表单文本当标签。
      try{
        // 先上溯到 form-item 的"块级"容器：BEM 里 form-item__control 也含 form-item 字样，
        // 直接 closest 会停在控件包裹层上，取不到字段名（北森实测）。
        let box=ctrl.closest('[class*=form-item],[class*=formItem],[class*=form_item]'),hop=0;
        while(box&&hop++<6&&/form-item__|__control|__body/i.test(String(box.className||''))){
          box=box.parentElement&&box.parentElement.closest('[class*=form-item],[class*=formItem],[class*=form_item]');
        }
        if(box){
          // 控件区之外、带 label 字样的节点才可能是字段名（排除选项 label、控件内部 label）
          const ctlBox=box.querySelector('[class*=form-item__control],[class*=form-item__body],[class*=__control]');
          let picked='';
          for(const x of box.querySelectorAll('[class*=label],[class*=Label],label')){
            if(x.contains(ctrl))continue;
            if(ctlBox&&ctlBox.contains(x))continue;
            if(x.querySelector('input,select,textarea,[contenteditable]'))continue;
            const t=textOf(x);
            if(t&&t.length<=40&&!looksLikeMultiField(t)){picked=t;break}
          }
          if(!picked){
            for(const c of [...box.children]){
              if(c.contains(ctrl))continue;
              if(/^(input|select|textarea|button)$/i.test(c.tagName))continue;
              if(c.querySelector('input,select,textarea,[contenteditable]'))continue;
              const t=textOf(c);
              if(t&&t.length<=40&&!looksLikeMultiField(t)){picked=t;break}
            }
          }
          if(picked)pushUnique(out,picked);
        }
      }catch{}
      // 4c. 兜底去污：剔除"同时是同一容器内其它控件标签"的候选
      if(out.length>1)filterShared(out,ctrl);
      // 5. 控件属性：name / id / data-label / data-field
      for(const a of ['data-label','data-field','name','id'])pushUnique(out,ctrl.getAttribute(a));
      // 6. title / data-placeholder
      pushUnique(out,ctrl.getAttribute('title'));
      pushUnique(out,ctrl.getAttribute('data-placeholder'));
    }catch{}
    return out;
  }
  // ---------- 区块上下文：返回 {group, node} ----------
  function contextOf(el){let node=el.parentElement;let guard=0;
    // 表格区块标题是前方独占整行的单元格，不能把 tbody 的首行当作所有字段的区块。
    // 只查看最近一层 table，跨 tbody 查找标题；普通字段行不参与区块判定。
    try{
      const row=el.closest('tr'),table=row&&row.closest('table');
      if(table){
        const rows=[...table.rows];
        for(let i=rows.indexOf(row)-1;i>=0;i--){
          const r=rows[i],cells=r.cells;
          if(cells.length!==1||cells[0].colSpan<2||r.querySelector('input,select,textarea,[contenteditable]'))continue;
          const t=textOf(cells[0]);
          if(!t)continue;
          // 最近的标题即边界，未知标题也不能沿用上一块的分组。
          return{group:groupOf(t),node:table};
        }
      }
    }catch{}
    while(node&&node!==document.body&&guard++<25){
      try{
        const heading=node.querySelector(':scope > legend, :scope > h1, :scope > h2, :scope > h3, :scope > h4, :scope > .section-head > h2, :scope > .card-title, :scope > .title');
        if(heading){const group=groupOf(textOf(heading));if(group)return{group,node}}
        // 通用兜底（不依赖任何类名）：真实站点大量使用 CSS-in-JS 哈希类名（北森新版整页都是 sc-xxxx），
        // 上面那套语义选择器一条都命中不了。改为看结构：容器"第一个有文本的直接子节点"若是区块词
        // （教育经历/工作经历/项目经历/语言能力…）就认；若不是，说明这一层不是经历区块容器，继续向上。
        // 只检查前 3 个子节点，且遇到第一个有文本的非区块词就放弃该层——避免在大容器里误判。
        let checked=0;
        for(const c of node.children){
          if(checked>=3)break;
          if(c.querySelector('input,select,textarea,[contenteditable]'))continue;
          const t=textOf(c);
          if(!t)continue;
          checked++;
          if(t.length<=12){const g=groupOf(t);if(g)return{group:g,node}}
          break;
        }
      }catch{}
      node=node.parentElement}
    return{group:null,node:null}}

  // ---------- AI 兜底（按 `设计/ai-方案-FINAL.md`：默认关闭；transport 可注入 → 离线可测，上线换自有代理） ----------
  // 设计要点：① 只有本地"拿不准"（未命中/歧义/score<阈值）才问 AI；② 只发字段标签，不发任何个人信息；
  //           ③ AI 只出中文短语，落位由本地规则完成；④ AI 说"不属于本人信息"→ 不填（不回退规则）；
  //           ⑤ 任何失败 → 回退本地结果，不让 AI 把结果变差。
  const AI_HI=80;                       // 本地置信度阈值：>= 直接用本地结果，不联网
  const AI_CACHE=new Map();             // key: 域名 + 规范化标签 → {group,key,src} | {abstain:true}
  let aiTransport=null, aiEnabled=false;
  const setAITransport=fn=>{aiTransport=fn};
  const setAIEnabled=on=>{aiEnabled=!!on};
  const clearAICache=()=>AI_CACHE.clear();
  const aiCacheSize=()=>AI_CACHE.size;

  // 该标签是否允许外发：敏感/禁止分组的字段永不外发；本地高置信的也不再问
  function needAI(label,group){
    const t=String(label||'').trim();
    if(!t)return false;
    if(blockedLabel(t)||sensitive(t))return false;
    const r=classify(t,group);
    if(!r)return true;
    if(r.ambiguous)return true;
    return r.score<AI_HI;
  }

  // items: [{id,label}]；返回 {id: {group,key,src:'ai'}|{abstain:true}}（只含问过 AI 的项）
  async function aiAssist(items,group,opts){
    opts=opts||{};
    const domain=opts.domain||'';
    const out={};
    const ask=[];
    for(const it of (items||[])){
      if(!it||!it.id)continue;
      const key=domain+'|'+normalize(it.label);
      if(AI_CACHE.has(key)){out[it.id]=AI_CACHE.get(key);continue}
      if(needAI(it.label,group))ask.push(it);
    }
    if(!ask.length||!aiEnabled||!aiTransport)return out;
    let res=null;
    try{
      res=await aiTransport({group:group||null,fields:ask.map(x=>({id:x.id,label:String(x.label).slice(0,120)}))});
    }catch(e){return out}                    // 网络/超时 → 回退本地（out 里没有这些项，调用方用规则结果）
    if(!res||!Array.isArray(res.mappings))return out;
    for(const m of res.mappings){
      if(!m)continue;
      const hit=ask.find(x=>x.id===m.id);if(!hit)continue;
      const key=domain+'|'+normalize(hit.label);
      let val=null;
      if(m.abstain===true||m.path===null){
        val={abstain:true};                  // AI 判定"不属于本人信息" → 不填（绝不能回退成规则结果）
      }else if(typeof m.phrase==='string'&&m.phrase.trim()){
        const p=m.phrase.trim().slice(0,40);
        if(/不属于本人|不是本人|无关|无法判断/.test(p)){val={abstain:true}}
        else{
          const rr=classify(p,group)||classify(p);   // AI 出短语 → 本地规则精确落位
          val=(rr&&!rr.ambiguous&&rr.score>=AI_HI)?{group:rr.group,key:rr.key,src:'ai',phrase:p}:{abstain:true};
        }
      }else{continue}
      AI_CACHE.set(key,val);out[hit.id]=val;
    }
    return out;
  }

  root.CampusEngine={normalize,denoise,isPlaceholder,enumSame,parseYearMonth,groupOf,classify,chooseOption,matchOption,adaptValue,labelOf,contextOf,sensitive,blockedLabel,scoreField,MIN_SCORE,rules,
    aiAssist,setAITransport,setAIEnabled,clearAICache,aiCacheSize,needAI,AI_HI};
})(globalThis);
