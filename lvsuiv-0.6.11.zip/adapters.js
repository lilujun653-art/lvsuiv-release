// 简历随行 · 控件适配层（v0.5 新增）
// 统一接口：Adapter = { id, detect(el) -> bool, async set(el, value, ctx) -> {ok, reason, before, after, restore?} }
// content.js 按数组顺序尝试，第一个 detect 命中的适配器执行；单控件失败不得中断整批。
(function(root){
  const E=root.CampusEngine;
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const visible=el=>{try{return !!(el.getClientRects&&el.getClientRects().length&&getComputedStyle(el).visibility!=='hidden'&&getComputedStyle(el).display!=='none')}catch{return false}};

  // ---------- 通用小工具 ----------
  // 原生赋值：原型 setter + input/change/blur 事件（应对 React/Vue 受控组件）
  function nativeSet(el,value){
    const proto=el.tagName==='SELECT'?HTMLSelectElement.prototype:el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto,'value').set.call(el,value);
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
    el.dispatchEvent(new Event('blur',{bubbles:true}));
  }
  // 真实点击序列：很多组件库监听 pointer/mouse 事件而非 click
  function realClick(el){
    try{
      for(const t of ['pointerdown','mousedown','pointerup','mouseup']){
        const Ev=t.startsWith('pointer')&&typeof PointerEvent!=='undefined'?PointerEvent:MouseEvent;
        el.dispatchEvent(new Ev(t,{bubbles:true,cancelable:true,view:window}));
      }
      el.click(); // 浏览器原生 click，isTrusted 视为真实
    }catch{try{el.click()}catch{}}
  }
  // 触发器当前显示文本（自定义下拉/日期控件）
  // 注意：必须"从自身往上找第一个有文字的节点"。不能用 closest('[class*=select]')——
  // 对于 <input class="el-select__input">，closest 会命中它自己（class 里就含 select），
  // 而 input 的 textContent 是空的，会导致读到空串、把成功判成失败。
  function displayText(el){
    try{
      if('value' in el&&el.value)return el.value;
      let node=el,depth=0,best='';
      while(node&&depth<5){
        // 只允许在"控件自身及其控件容器"内找文字；一旦走到字段容器（form-item/label 层）立刻停止，
        // 否则会把旁边的 label 文字（如"入学时间"）当成已填内容，导致误判"已有内容"而跳过填写。
        if(depth>0&&!/(select|picker|date|calendar|dropdown|combobox|editor|input|tag)/i.test(String(node.className||'')))break;
        const raw=node.textContent?node.textContent.replace(/\s+/g,' ').trim():'';
        if(raw&&raw.length<120){best=raw;break}
        node=node.parentElement;depth++;
      }
      return best;
    }catch{return ''}
  }
  // 自定义/搜索下拉的"已选标签"文本：选中值常在独立节点（chip），输入框本身可能为空
  function selectedTagText(el){
    try{
      let node=el.parentElement,depth=0;
      while(node&&depth<6){
        const list=node.querySelectorAll?node.querySelectorAll('.el-select__selected-item:not(.el-select__input-wrapper):not(.el-select__placeholder),.ant-select-selection-item,[class*=tag],[class*=Tag]'):[];
        for(const tag of list){
          if(tag===el||tag.contains(el))continue;
          const t=tag.textContent.replace(/\s+/g,' ').trim();
          // 占位文案（"请选择"等）不是已选内容
          if(t&&t.length<120&&!E.isPlaceholder(t)&&!/请选择|选择/.test(E.normalize(t)))return t;
        }
        node=node.parentElement;depth++;
      }
      return '';
    }catch{return ''}
  }

  // ---------- 浮层发现：点击后新增的、可见的、含可点击项的浮层 ----------
  // 候选选择器不绑定具体组件库，另保留常见类名提高命中
  const OPTION_SEL='[role=option],[role=menuitem],.el-select-dropdown__item,.ant-select-item-option,.sd-Select-option,li,[class*=option],[class*=Option],td,[class*=cell],[class*=Cell]';
  function optionLike(node){try{return node.children.length<=6&&node.textContent.replace(/\s+/g,' ').trim().length>0&&node.textContent.trim().length<=60}catch{return false}}
  function visibleOptions(scopeRoot){
    const out=[];
    try{for(const n of scopeRoot.querySelectorAll(OPTION_SEL)){if(visible(n)&&optionLike(n)&&!n.querySelector(OPTION_SEL))out.push(n)}}catch{}
    return out;
  }
  // 在 document 范围找"点击后新出现的可见选项浮层"：exclude 为点击前已可见的选项集合
  function snapshotOptions(){return new Set(visibleOptions(document))}
  function findPopup(exclude){
    const opts=visibleOptions(document).filter(o=>!exclude||!exclude.has(o));
    if(!opts.length)return null;
    // 取第一个选项向上找包含最多选项兄弟的容器作为浮层
    let best=null,bestCount=0;
    for(const o of opts.slice(0,30)){let p=o.parentElement,depth=0;
      while(p&&p!==document.body&&depth++<6){const c=opts.filter(x=>p.contains(x)).length;if(c>bestCount){best=p;bestCount=c}p=p.parentElement}}
    if(!best)return null;
    return{container:best,options:opts.filter(x=>best.contains(x))};
  }
  async function waitPopup(exclude,timeout=2000){
    const step=200;let waited=0;
    while(waited<=timeout){const p=findPopup(exclude);if(p)return p;await sleep(step);waited+=step}
    return null;
  }
  function closePopup(){try{document.body.dispatchEvent(new MouseEvent('mousedown',{bubbles:true}));document.body.click()}catch{}try{document.activeElement&&document.activeElement.blur&&document.activeElement.blur()}catch{}}
  // 在浮层内滚动查找（虚拟滚动长列表），最多 8 轮
  async function findOptionInPopup(popup,value){
    const scroller=[popup.container,...popup.container.querySelectorAll('*')].find(n=>{try{return n.scrollHeight>n.clientHeight+8&&/auto|scroll/.test(getComputedStyle(n).overflowY)}catch{return false}});
    for(let round=0;round<8;round++){
      const opts=visibleOptions(popup.container).map(n=>({text:n.textContent.replace(/\s+/g,' ').trim(),node:n}));
      const hit=E.matchOption(opts,value);
      if(hit)return hit.node;
      if(!scroller)break;
      scroller.scrollTop+=Math.max(120,scroller.clientHeight);await sleep(160);
    }
    return null;
  }

  // ---------- 1. 原生输入框 / 文本域 ----------
  const TEXT_TYPES=['text','email','tel','url','search','month','date','number','textarea',''];
  const nativeInput={
    id:'native-input',
    detect:el=>(el.tagName==='TEXTAREA'||el.tagName==='INPUT'&&TEXT_TYPES.includes((el.type||'').toLowerCase()))&&!el.readOnly,
    async set(el,value,ctx){
      const adapted=E.adaptValue(value,(el.type||'textarea').toLowerCase(),el.maxLength??-1);
      if(adapted.error)return{ok:false,reason:adapted.error};
      const before=el.value;
      try{
        nativeSet(el,adapted.value);await sleep(90);
        if(el.isConnected&&el.value===adapted.value&&(!el.validity||el.validity.valid))return{ok:true,before,after:el.value};
        if(el.isConnected&&el.value===adapted.value){try{nativeSet(el,before)}catch{}}
        return{ok:false,reason:'网页未接受该值，请手动检查此字段。'};
      }catch(e){try{if(el.isConnected&&el.value===adapted.value)nativeSet(el,before)}catch{}return{ok:false,reason:'填写失败，请手动检查。'}}
    }
  };

  // ---------- 2. 原生 select ----------
  const nativeSelect={
    id:'native-select',
    detect:el=>el.tagName==='SELECT',
    async set(el,value){
      const hit=E.matchOption([...el.options].map(o=>({text:o.textContent,value:o.value,disabled:o.disabled,node:o})),value);
      if(!hit)return{ok:false,reason:'网页选项与档案不完全匹配，请手动选择。'};
      const before=el.value;
      try{
        nativeSet(el,hit.value);await sleep(60);
        if(el.value===hit.value)return{ok:true,before,after:el.value};
        return{ok:false,reason:'网页未接受该选项，请手动选择。'};
      }catch{return{ok:false,reason:'选择失败，请手动检查。'}}
    }
  };

  // ---------- 3. 自定义下拉（div/只读输入 + 点击出浮层） ----------
  async function customSelectSet(el,value){
    const trigger=el;
    const before=displayText(trigger);
    try{
      const snap=snapshotOptions();
      realClick(trigger);
      const popup=await waitPopup(snap,2000);
      if(!popup)return{ok:false,reason:'点击后未出现选项浮层，请手动选择。'};
      const node=await findOptionInPopup(popup,value);
      if(!node){closePopup();return{ok:false,reason:'浮层选项与档案不匹配，请手动选择。'}}
      realClick(node);await sleep(200);
      const after=displayText(trigger);
      const ok=E.matchOption([{text:after}],value)||E.enumSame(after,value)||E.denoise(after).includes(E.denoise(value));
      if(!ok){closePopup();return{ok:false,reason:'选择后显示值与目标不一致，请手动检查。'}}
      // 还原函数：撤销时重新打开并选回旧值；原为空则尽力清空
      const restore=async()=>{
        try{
          if(!before||/请选择|选择/.test(E.normalize(before))){
            const clearBtn=trigger.parentElement&&trigger.parentElement.querySelector('[class*=clear]');
            if(clearBtn){realClick(clearBtn);await sleep(120);return true}
            if('value' in trigger){try{Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(trigger,'');trigger.dispatchEvent(new Event('input',{bubbles:true}));trigger.dispatchEvent(new Event('change',{bubbles:true}))}catch{}return!displayText(trigger)||E.isPlaceholder(displayText(trigger))}
            return false;
          }
          const snap2=snapshotOptions();
          realClick(trigger);const p2=await waitPopup(snap2,1500);if(!p2)return false;
          const back=await findOptionInPopup(p2,before);
          if(back){realClick(back);await sleep(150);return true}
          closePopup();return false;
        }catch{return false}
      };
      return{ok:true,before,after,restore};
    }catch(e){closePopup();return{ok:false,reason:'自定义下拉填写失败，请手动选择。'}}
  }
  const customSelect={
    id:'custom-select',
    detect(el){
      try{
        if(el.tagName==='SELECT')return false;
        const role=el.getAttribute('role');
        if(role==='combobox'&&el.readOnly)return true;
        if(role==='combobox'&&!el.getAttribute('aria-autocomplete'))return true;
        if(/listbox|menu|true/.test(el.getAttribute('aria-haspopup')||''))return true;
        const cls=String(el.className&&el.className.baseVal!==undefined?el.className.baseVal:el.className||'')+' '+(el.id||'');
        if(/select|dropdown|picker/i.test(cls)&&!/date|time|calendar|search/i.test(cls))return true;
        // 只读 input + 相邻箭头/容器含 select 类
        if(el.tagName==='INPUT'&&el.readOnly){const host=el.closest('[class*=select],[class*=Select],[class*=dropdown]');if(host)return true}
        return false;
      }catch{return false}
    },
    set:customSelectSet
  };

  // ---------- 4. 日期/年月选择器 ----------
  function dateTarget(value,needDay){
    const ym=E.parseYearMonth(value)||(/^\d{4}-\d{2}-\d{2}$/.test(value)?value.slice(0,7):null);
    if(!ym)return null;
    const d=/^\d{4}-\d{2}-(\d{2})$/.test(value)?+RegExp.$1:null;
    return{y:+ym.slice(0,4),m:+ym.slice(5,7),d};
  }
  // 从结果字符串中正则解析年月再比对：禁止 includes 判断（"2024" 本身含 "02"，会误判成功）
  function ymFromText(s){const m=String(s||'').match(/(\d{4})\D{0,3}(0?[1-9]|1[0-2])/);return m?{y:+m[1],m:+m[2]}:null}
  function ymMatch(s,target){const p=ymFromText(s);return !!p&&p.y===target.y&&p.m===target.m}
  // 完整日期匹配：必须"年月日"三段之间都有真实分隔符，不能允许 0 个分隔符（否则 2024-09 会被读成 2024/0/9）
  function ymdMatch(s,target){const m=String(s||'').match(/(\d{4})\s*[-\/年.]\s*(\d{1,2})\s*[-\/月.]\s*(\d{1,2})/);return !!m&&+m[1]===target.y&&+m[2]===target.m&&+m[3]===target.d}
  // 浮层是否为"完整日历"（含日层级）：有星期表头，或出现 13~31 的数字单元格
  function popupIsFullCalendar(popup){
    try{
      const leaves=[...popup.container.querySelectorAll('td,th,li,span,div,a')].filter(n=>visible(n)&&n.children.length===0);
      if(leaves.some(n=>/^(一|二|三|四|五|六|日|mo|tu|we|th|fr|sa|su)$/i.test(n.textContent.trim())))return true;
      const nums=leaves.map(n=>n.textContent.trim()).filter(t=>/^\d{1,2}$/.test(t)).map(Number);
      if(nums.some(n=>n>12))return true;
      return false;
    }catch{return true} // 无法确认时按完整日历处理（保守：不点）
  }
  // 是否可按"年月模式"自动操作：placeholder/type 明确是年月，或浮层表头只有年/月层级、没有日层级
  function isYearMonthMode(el,popup){
    try{
      if((el.type||'').toLowerCase()==='month')return true;
      if(/年月/.test(el.getAttribute('placeholder')||''))return true;
    }catch{}
    if(!popup)return false;
    try{
      if(!/(\d{4})\s*年/.test(popup.container.textContent))return false; // 表头无年份层级 → 无法确认
      return !popupIsFullCalendar(popup);
    }catch{return false}
  }
  async function datePickerSet(el,value){
    const target=dateTarget(value);
    if(!target)return{ok:false,reason:'需要明确的年月，请手动确认。'};
    const before=el.value||displayText(el);
    // 兜底路径：直接写入输入框（很多日期控件接受手输），与浮层路径用同一套年月校验
    const tryDirect=async()=>{
      if(el.tagName!=='INPUT'||el.readOnly)return false;
      const fmts=[`${target.y}-${String(target.m).padStart(2,'0')}`,`${target.y}/${String(target.m).padStart(2,'0')}`];
      if(target.d)fmts.unshift(`${target.y}-${String(target.m).padStart(2,'0')}-${String(target.d).padStart(2,'0')}`);
      for(const fmt of fmts){
        try{nativeSet(el,fmt);await sleep(120);
          const v=el.value||'';
          // 档案只有年月时：若写入后结果里被补出了"日"（2024-09 → 2024-09-01），说明控件擅自补日 → 不算成功、立即还原
          const autoFilledDay=/\d{4}\s*[-\/年.]\s*\d{1,2}\s*[-\/月.]\s*\d{1,2}/.test(v);   // 分隔符必须真实存在，否则 "2024-09" 会被误判成"补了日" 
          if(v&&(target.d?ymdMatch(v,target):(ymMatch(v,target)&&!autoFilledDay)))return true;
          nativeSet(el,before);
        }catch{}
      }
      return false;
    };
    try{
      // 主路径：打开浮层 → 确认是年月模式 → 导航到目标年月 → 点选 → 确定
      const snap=snapshotOptions();
      realClick(el);
      const popup=await waitPopup(snap,1500);
      if(!popup){
        if(await tryDirect())return{ok:true,before,after:el.value};
        return{ok:false,reason:'日期浮层未出现且不接受手输，请手动选择。'};
      }
      if(target.d){
        // 档案含具体日期：日历逐日点选不可靠，交给用户
        closePopup();
        return{ok:false,reason:'需要选择具体日期，请手动确认。'};
      }
      // 资料只有年月：必须确认控件是"年月模式"才允许浮层自动选择，否则绝不点击（避免点到某一天）
      if(!isYearMonthMode(el,popup)){
        // 该控件要精确到"日"，而档案只有年月。不点浮层、也不手写（手写会被控件擅自补成某一天），直接转人工。
        closePopup();
        return{ok:false,reason:'该控件要填到具体某一天，而档案里只有年月，为避免填错日期，请手动选择。'};
      }
      // 年月模式：找"年/月"表头并导航（年份差距大时优先点年按钮）
      const nav=async()=>{
        for(let i=0;i<72;i++){
          const head=popup.container.textContent;
          const hy=head.match(/(\d{4})\s*年/),hm=head.match(/(\d{1,2})\s*月/);
          if(hy&&+hy[1]===target.y&&(!hm||+hm[1]===target.m))return true;
          const btns=[...popup.container.querySelectorAll('button,[class*=prev],[class*=next],[class*=arrow],[role=button]')].filter(visible);
          const monthDiff=hy&&hm?(target.y*12+target.m)-(+hy[1]*12+ +hm[1]):hy?(target.y-+hy[1])*12:0;
          if(!monthDiff)return false;
          const dbl=btns.filter(b=>/«|»/.test(b.textContent));
          const sgl=btns.filter(b=>!/«|»/.test(b.textContent)&&/prev|next|‹|›|上一|下一/i.test(String(b.className)+' '+b.textContent));
          let btn=null;
          if(Math.abs(monthDiff)>=12&&dbl.length)btn=dbl.find(b=>monthDiff<0?/«/.test(b.textContent):/»/.test(b.textContent));
          if(!btn)btn=sgl.find(b=>monthDiff<0?/prev|‹|上一/i.test(String(b.className)+' '+b.textContent):/next|›|下一/i.test(String(b.className)+' '+b.textContent));
          if(!btn)return false;
          realClick(btn);await sleep(110);
        }
        // 循环结束再核对一次表头
        const head=popup.container.textContent;const hy=head.match(/(\d{4})\s*年/),hm=head.match(/(\d{1,2})\s*月/);
        return !!(hy&&+hy[1]===target.y&&(!hm||+hm[1]===target.m));
      };
      const headerOk=await nav();
      if(headerOk){
        // 已确认是年月模式：浮层里的月份单元格（"9" 或 "9月"），不存在"日"单元格
        const cells=[...popup.container.querySelectorAll('td,li,span,div,a')].filter(n=>visible(n)&&n.children.length===0&&/^\d{1,2}月?$/.test(n.textContent.trim())&&!/disabled|disable/i.test(n.className));
        const cell=cells.find(n=>parseInt(n.textContent.trim(),10)===target.m);
        if(cell){realClick(cell);await sleep(150)}
      }
      const confirmBtn=[...popup.container.querySelectorAll('button,a')].find(b=>visible(b)&&/^(确定|确认|ok)$/i.test(b.textContent.trim()));
      if(confirmBtn){realClick(confirmBtn);await sleep(120)}
      const after=el.value||displayText(el);
      if(after&&ymMatch(after,target)){
        return{ok:true,before,after};
      }
      closePopup();
      if(await tryDirect())return{ok:true,before,after:el.value};
      return{ok:false,reason:'日期浮层操作后值未生效，请手动选择。'};
    }catch(e){closePopup();if(await tryDirect().catch(()=>false))return{ok:true,before,after:el.value};return{ok:false,reason:'日期控件填写失败，请手动选择。'}}
  }
  const datePicker={
    id:'date-picker',
    detect(el){
      try{
        if(el.tagName!=='INPUT')return false;
        const t=(el.type||'').toLowerCase();
        if(t==='month'||t==='date')return false; // 原生日期框由 native-input 处理
        const sig=String(el.className||'')+' '+(el.id||'')+' '+(el.name||'')+' '+(el.getAttribute('placeholder')||'');
        if(/date|calendar/i.test(sig))return true;
        if(/日期|年月|时间/.test(el.getAttribute('placeholder')||''))return true;
        const host=el.closest('[class*=date],[class*=calendar]');if(host)return true;
        return false;
      }catch{return false}
    },
    set:datePickerSet
  };

  // ---------- 5. 单选组 / 复选 ----------
  const radioGroup={
    id:'radio-group',
    detect:el=>el.tagName==='INPUT'&&(el.type||'').toLowerCase()==='radio',
    async set(el,value,ctx){
      const group=(ctx&&ctx.group)||[el];
      try{
        // 选项文本读取：label[for] → 包裹 label → 紧邻本控件的文本节点 → 父容器（仅当父容器只含这一个单选）
        // 旧实现直接用 parentElement.textContent：北森把"男""女"放在同一容器里，两个选项文本都变成"男女"，
        // matchOption 命中两个候选 → 返回 null → 误报"单选项与档案不匹配"
        const ownText=r=>{
          let t='';
          try{
            if(r.id){const l=document.querySelector('label[for="'+CSS.escape(r.id)+'"]');if(l)t=l.textContent}
            if(!t){const w=r.closest('label');if(w)t=w.textContent}
            if(!t){let n=r.nextSibling;while(n&&!String(n.textContent||'').trim())n=n.nextSibling;if(n)t=n.textContent}
            if(!t){
              const p=r.parentElement;
              if(p&&p.querySelectorAll('input[type=radio]').length===1)t=p.textContent;
            }
          }catch{}
          return String(t||'').replace(/\s+/g,' ').trim();
        };
        const opts=group.map(r=>({text:ownText(r),node:r}));
        // 选项文本缺失或互相重复时，宁可报"需手动"，也不要在含义不明的选项里猜一个
        const seen=new Set();
        for(const o of opts){
          if(!o.text)return{ok:false,reason:'未能读到单选项文字，请手动选择。'};
          if(seen.has(o.text))return{ok:false,reason:'多个单选项文字相同，无法区分，请手动选择。'};
          seen.add(o.text);
        }
        const hit=E.matchOption(opts,value);
        if(!hit)return{ok:false,reason:'单选项与档案不匹配，请手动选择。'};
        // 用 DOM 元素身份判断当前选中项：多个未设 value 的 radio 其 value 都是 "on"，按字符串比对会认错
        const getCurrent=()=>{try{return group.find(r=>r.checked)||null}catch{return null}};
        const before=getCurrent();
        if(hit.node.checked)return{ok:false,reason:'already'};
        const lab=hit.node.id&&document.querySelector('label[for="'+CSS.escape(hit.node.id)+'"]');
        realClick(lab||hit.node.closest('label')||hit.node);await sleep(90);
        if(hit.node.checked)return{ok:true,before,after:hit.node,afterLabel:hit.text,getCurrent,restore:async()=>{try{if(!before){for(const r of group)if(r.checked){r.checked=false;r.dispatchEvent(new Event('change',{bubbles:true}))}return!group.some(r=>r.checked)}if(!before.isConnected)return false;realClick(before);await sleep(60);return before.checked}catch{return false}}};
        return{ok:false,reason:'单选未生效，请手动选择。'};
      }catch{return{ok:false,reason:'单选填写失败，请手动选择。'}}
    }
  };
  const checkboxSingle={
    id:'checkbox-single',
    detect:el=>el.tagName==='INPUT'&&(el.type||'').toLowerCase()==='checkbox',
    async set(el,value,ctx){
      const label=(ctx&&ctx.label)||'';
      // 协议/承诺类勾选一律由本人完成
      if(/同意|确认|承诺|条款|协议|隐私|授权|声明/.test(label))return{ok:false,reason:'协议或承诺类勾选需本人完成。'};
      return{ok:false,reason:'复选项请本人勾选。'};
    }
  };

  // ---------- 6. 异步搜索下拉（输入关键词 → 等候选 → 点击） ----------
  const searchSelect={
    id:'search-select',
    detect(el){
      try{
        if(el.tagName!=='INPUT'||el.readOnly)return false;
        if(el.getAttribute('aria-autocomplete')==='list'||el.getAttribute('aria-autocomplete')==='both')return true;
        if(el.hasAttribute('list'))return true;
        if(el.getAttribute('role')==='combobox')return true;
        const host=el.closest('[class*=search-select],[class*=autocomplete]');if(host)return true;
        return false;
      }catch{return false}
    },
    async set(el,value){
      const before=el.value;
      try{
        el.focus();nativeSet(el,'');await sleep(60);
        const snap=snapshotOptions();
        nativeSet(el,value);await sleep(100);
        const popup=await waitPopup(snap,2000);
        if(!popup){nativeSet(el,before);return{ok:false,reason:'未出现搜索候选，请手动输入选择。'}}
        const node=await findOptionInPopup(popup,value);
        if(!node){closePopup();nativeSet(el,before);return{ok:false,reason:'搜索候选与档案不匹配，请手动选择。'}}
        realClick(node);await sleep(200);
        // 搜索型下拉：选中值常落在独立的"已选标签"节点，搜索框本身可能仍为空 → 三处都看
        const after=el.value||selectedTagText(el)||displayText(el);
        if(E.matchOption([{text:after}],value)||E.denoise(after).includes(E.denoise(value)))return{ok:true,before,after};
        return{ok:false,reason:'候选选择后值未生效，请手动检查。'};
      }catch(e){closePopup();try{nativeSet(el,before)}catch{}return{ok:false,reason:'搜索下拉填写失败，请手动选择。'}}
    }
  };

  // ---------- 7. 附件上传（P2）：从扩展存储取预存简历 → DataTransfer 注入 ----------
  const fileAttach={
    id:'file-attach',
    detect:el=>el.tagName==='INPUT'&&(el.type||'').toLowerCase()==='file',
    async set(el,value,ctx){
      try{
        const getter=ctx&&ctx.getAttachment;
        if(!getter)return{ok:false,reason:'当前环境不支持附件填写。'};
        const att=await getter();
        if(!att)return{ok:false,reason:'请在插件个人档案中预存简历文件（PDF/DOCX）。'};
        const bin=Uint8Array.from(atob(att.data),c=>c.charCodeAt(0));
        const file=new File([bin],att.name,{type:att.type||'application/octet-stream'});
        const dt=new DataTransfer();dt.items.add(file);el.files=dt.files;
        el.dispatchEvent(new Event('input',{bubbles:true}));
        el.dispatchEvent(new Event('change',{bubbles:true}));
        await sleep(120);
        if(el.files&&el.files.length>0){
          const f=el.files[0];
          // 文件已注入，但网页框架是否真正接受上传无法可靠确认 → unverified，由用户核对
          // fileKey 为文件身份（name+size+lastModified），撤销时据此比对：用户换过文件就跳过
          return{ok:true,unverified:true,before:'',after:att.name,fileKey:f.name+'|'+f.size+'|'+f.lastModified};
        }
        return{ok:false,reason:'网页未接受附件，请手动上传。'};
      }catch(e){return{ok:false,reason:'附件填写失败（'+((e&&e.message)||'未知原因')+'），请手动上传。'}}
    }
  };

  // 适配器尝试顺序：特殊控件优先，普通输入兜底
  const adapters=[fileAttach,nativeSelect,radioGroup,checkboxSingle,datePicker,searchSelect,customSelect,nativeInput];
  root.CampusAdapters={adapters,nativeSet,realClick,displayText,selectedTagText,visible,sleep,closePopup};
})(globalThis);
