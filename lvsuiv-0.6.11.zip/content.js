// 简历随行 · 页面执行层（v0.5 重写）
// 全量可见控件遍历 → engine 识别 → adapters 填写；单字段失败不中断整批。
// 报告结构化：{filled[], skipped[], manual[], blocked[], preserved}；undo 记录含自定义控件还原。
(function(){
if(globalThis.CampusApply)return;
const E=globalThis.CampusEngine,A=globalThis.CampusAdapters;
let history=[];let busy=false;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const pause=()=>sleep(90);
const visible=(A&&A.visible)||(el=>{try{return !!(el.getClientRects().length&&getComputedStyle(el).visibility!=='hidden')}catch{return false}});

// ---------- 控件收集：全量可见控件，含 Shadow DOM 递归（最多 3 层） ----------
const CONTROL_SEL='input,textarea,select,[role=combobox],[contenteditable="true"]';
function deepCollect(rootNode,out,depth){
  try{
    for(const el of rootNode.querySelectorAll(CONTROL_SEL))out.push(el);
    if(depth<3)for(const host of rootNode.querySelectorAll('*')){try{if(host.shadowRoot)deepCollect(host.shadowRoot,out,depth+1)}catch{}}
  }catch{}
}
function collectControls(){
  const out=[];deepCollect(document,out,0);
  const seen=new Set();const controls=[];
  for(const el of out){
    if(seen.has(el))continue;seen.add(el);
    try{
      if(!visible(el)||el.disabled)continue;
      const type=(el.type||'').toLowerCase();
      if(['hidden','submit','button','reset','image'].includes(type))continue;
      controls.push(el);
    }catch{}
  }
  // 单选组按 name 去重，只处理每组的第一个
  const radioSeen=new Set();
  return controls.filter(el=>{
    if(el.tagName==='INPUT'&&(el.type||'').toLowerCase()==='radio'){
      const key=el.name||el.id||String(Math.random());
      if(radioSeen.has(key))return false;radioSeen.add(key);
    }
    return true;
  });
}
function radioMembers(el){
  try{
    if(!el.name)return[el];
    const root=el.getRootNode&&el.getRootNode()||document;
    return[...root.querySelectorAll('input[type=radio][name="'+CSS.escape(el.name)+'"]')];
  }catch{return[el]}
}

// ---------- 空值判断（不覆盖已有内容） ----------
function empty(el){
  try{
    if(el.tagName==='SELECT'){const o=el.selectedOptions[0];return el.value===''||!!o&&E.isPlaceholder(o.textContent)}
    const type=(el.type||'').toLowerCase();
    if(type==='radio')return!radioMembers(el).some(r=>r.checked);
    if(type==='checkbox')return!el.checked;
    if(type==='file')return!(el.files&&el.files.length);
    // 自定义下拉/搜索框：已选内容常在独立的"已选标签"节点，输入框本身可能为空 → 需要额外检查
    const isCustom=el.readOnly||(el.getAttribute&&el.getAttribute('role')==='combobox')||(el.hasAttribute&&el.hasAttribute('aria-autocomplete'))||!!el.closest('[class*=select],[class*=Select],[class*=dropdown],[class*=picker],[class*=autocomplete]');
    if('value' in el&&typeof el.value==='string'){
      if(el.value.trim())return false;
      if(!isCustom)return true;   // 普通输入框/文本域：值为空就是空，绝不看展示文本（否则会读到旁边的标签文字而误判"已有内容"）
      const tag=A.selectedTagText&&A.selectedTagText(el);
      if(tag&&!E.isPlaceholder(tag)&&!/请选择|选择/.test(E.normalize(tag)))return false;
      const t=A.displayText(el);return!t||E.isPlaceholder(t)||/请选择|选择/.test(E.normalize(t));
    }
    const t=A.displayText(el);return!t||E.isPlaceholder(t)||/请选择|选择/.test(E.normalize(t));
  }catch{return true}
}

// ---------- 经历区块：锚点字段定位每段经历的容器 ----------
const ANCHOR={education:'school',internship:'company',work:'company',project:'name',language:'name',award:'name',certificate:'name'};
function entryContainer(anchorEl,anchors){
  let node=anchorEl.parentElement,last=anchorEl,guard=0;
  while(node&&node!==document.body&&guard++<15){
    if(anchors.some(a=>a!==anchorEl&&node.contains(a)))break;
    last=node;node=node.parentElement;
  }
  return last;
}
// 在分组区块内找"添加/新增"按钮（取文本最短、且不含控件的元素，避免点到容器）
// 排除"提交/保存/申请/发布/确认"类按钮（防点中"添加并提交"）；scope 为空时直接不找（不全页兜底）
function findAddButton(scope){
  if(!scope)return null;
  let els=[];
  try{els=[...scope.querySelectorAll('button,a,[role=button],div,span')].filter(el=>{
    if(!visible(el)||el.querySelector('input,select,textarea'))return false;
    const t=(el.textContent||'').replace(/\s+/g,'').slice(0,16);
    if(/提交|保存|申请|发布|确认/.test(t))return false;
    return /^(＋|\+)?(添加|新增|继续添加|再添加)/.test(t);
  })}catch{return null}
  els.sort((a,b)=>a.textContent.length-b.textContent.length);
  return els[0]||null;
}

// ---------- 构建候选 ----------
function buildCandidates(){
  const controls=collectControls();
  const capped=controls.length>600?controls.slice(0,600):controls;
  const blocked=[],unmatched=[];
  const candidates=[];
  for(const el of capped){
    try{
      const type=(el.type||'').toLowerCase();
      const isChoice=type==='radio'||type==='checkbox';
      const labels=E.labelOf(el,{skipOwnLabel:isChoice});
      const label=labels[0]||'';
      const context=E.contextOf(el);
      const ac=((el.getAttribute&&el.getAttribute('autocomplete'))||'').toLowerCase();
      if(type==='password'||labels.some(E.sensitive)||ac==='one-time-code'||ac==='current-password'||ac==='new-password'){blocked.push({label:label||'(敏感控件)',reason:'密码/验证码类字段不自动填写。'});continue}
      if(context.group==='blocked'||labels.some(E.blockedLabel)){blocked.push({label:label||'(禁止分组)',reason:'紧急联系人/家庭/证明人类字段不自动填写。'});continue}
      if(type==='file'){candidates.push({el,labels,label,context,match:null,file:true});continue}
      // 先在分组上下文内匹配（消解"名称"类冲突）；无结果再全组搜索（标题宽泛时不漏填）
      let match=E.classify(labels,context.group)||(context.group?E.classify(labels,null):null);
      // 手机号本体是输入框：<select> 命中 phone 只可能是"区号/国家代码"这类下拉（北森：手机号 [中国大陆 ▼]）
      // 不纠正的话，手机号 select 与手机号 input 会同时命中 basic.phone，两处都判歧义 → 一个都不填
      if(match&&!match.ambiguous&&match.group==='basic'&&match.key==='phone'&&el.tagName==='SELECT')match={...match,key:'dialCode'};
      candidates.push({el,labels,label,context,match});
    }catch{}
  }
  return{candidates,blocked,total:controls.length,capped:controls.length>600};
}

// ---------- 主流程 ----------
async function run(action,profile){
  if(busy)return{message:'已有操作正在执行，请稍后重试。',filled:[],skipped:[],manual:[],blocked:[],items:[]};
  busy=true;
  try{
    if(action==='undo')return await undo();
    if(action!=='fill'||!profile||!profile.confirmed)return{message:'请先保存并确认个人档案。',filled:[],skipped:[],manual:[],blocked:[],items:[]};
    return await fill(profile);
  }finally{busy=false}
}

// ---------- 撤销 ----------
// history 按"批次"保存（每轮填写一个批次），撤销只处理最近一轮，不整体替换
async function undo(){
  let restored=0,skipped=0;
  const batch=history.pop();
  if(!batch||!batch.length)return{message:'当前页面没有可撤销的填写记录。',filled:[],skipped:[],manual:[],blocked:[],items:[]};
  const keep=[];
  for(const rec of[...batch].reverse()){
    try{
      if(!rec.el.isConnected||rec.url!==location.href){skipped++;continue}
      const now=rec.getCurrent?rec.getCurrent():(rec.custom?A.displayText(rec.el):rec.el.value);
      if(now!==rec.after){skipped++;continue} // 用户之后改过（含换过附件）→ 保留
      let ok=false;
      if(rec.restore){ok=await rec.restore().catch(()=>false)}
      else{A.nativeSet(rec.el,rec.before);await pause();ok=rec.el.value===rec.before}
      if(ok)restored++;else{keep.unshift(rec);skipped++}
    }catch{skipped++;keep.unshift(rec)}
  }
  if(keep.length)history.push(keep); // 未能恢复的记录留在历史里，可再次尝试
  return{message:`已撤销 ${restored} 项${skipped?'；另有 '+skipped+' 项已被修改、失效或无法恢复，保留现状':''}。撤销只影响当前页面、只撤销最近一轮填写，不能撤回服务器保存。`,filled:[],skipped:[],manual:[],blocked:[],items:[]};
}

// ---------- 填写 ----------
const EXTRA_GROUPS=['intent']; // 需要本次授权的组
const BASIC_FREE=['name','email','phone']; // 兼容旧引用
// 按类别授权：默认放开 basic 非敏感项 + intent + 全部经历；只拦敏感个人项与附件上传
const SENSITIVE_KEYS=['idNumber','idType','nationality','maritalStatus','weight','height'];
async function fill(profile){
  const filled=[],skipped=[],manual=[],records=[];
  let preserved=0;
  let{candidates,blocked,total,capped}=buildCandidates();

  // 获取预存附件（经 background 读取扩展 IndexedDB；demo 环境直接用 profile.attachment）
  const getAttachment=async()=>{
    try{
      if(profile.attachment&&profile.attachment.data)return profile.attachment;
      if(globalThis.chrome&&chrome.runtime&&chrome.runtime.sendMessage){
        const r=await chrome.runtime.sendMessage({type:'campus-get-attachment'});
        if(r&&r.ok)return r.attachment;
      }
    }catch{}
    return null;
  };

  // --- 经历分组：区块定位 / 自动补齐 / 段序分配 ---
  const entryIndexOf=new Map(); // el -> 档案段序号
  const entriesByGroup={};      // group -> 该组取用的经历数组（必要时按时间倒序）
  for(const group of['education','internship','work','project','language','award','certificate']){
    const entries=(profile[group]||[]).filter(e=>Object.values(e).some(Boolean));
    if(!entries.length)continue;
    const anchorKey=ANCHOR[group];
    let gCands=candidates.filter(c=>c.match&&c.match.group===group);
    if(!gCands.length)continue;
    const withNode=gCands.find(c=>c.context&&c.context.node);
    const sectionNode=withNode?withNode.context.node:null;
    // 区块 = 锚点控件的最小不重叠容器，按文档顺序
    const computeBlocks=()=>{
      const anchors=gCands.filter(c=>c.match.key===anchorKey).map(c=>c.el);
      const blocks=[];const seen=new Set();
      for(const a of anchors){const b=entryContainer(a,anchors);if(b&&!seen.has(b)){seen.add(b);blocks.push(b)}}
      return blocks;
    };
    let blocks=computeBlocks();
    // 档案段数多于页面区块 → 尝试点"添加"补齐；找不到明确的分组容器（sectionNode）就不点，由下方统一报告
    // v0.6：移除"自动点击＋添加按钮补齐经历区块"的循环。
    // 实测根因：classic 页三组共 15 次点击空等（每次最多 4 秒）≈60 秒，整轮卡到 80 秒超时、字段一个没填上；
    // 且点按钮会改动页面结构，属高风险动作（Codex v0.6 方案第 63 行也要求去掉这个 entries.length+2 自动循环）。
    // 区块不足时统一走下方报告，由用户手动补齐。
    if(!blocks.length){
      // 页面没有分段的经历区块（字段散落在"基本信息"里，如"毕业时间"）→ 按最近一段经历填，并提示核对
      // 旧行为：直接跳过（北森的"毕业时间"就一直填不上）
      const sorted=entries.slice().sort((a,b)=>String(b.end||b.start||'').localeCompare(String(a.end||a.start||'')));
      entriesByGroup[group]=sorted;
      for(const c of gCands){
        entryIndexOf.set(c.el,0);
        manual.push({label:c.label||group,reason:'此字段未按经历区块分开，已按最近一段经历填写，请核对。'});
      }
      continue;
    }
    if(blocks.length<entries.length){
      // v0.6：同一区块容器里叠了多段经历（真实站点常见，如北森新版：一个"教育经历"容器里放 N 段字段）。
      // 判定依据只有一条、且可核对：**锚点字段（学校名称/公司名称/项目名称…）在页面上的出现次数**。
      //   出现次数 == 档案段数 → 按 DOM 顺序把每个控件归到第 i 段（i 从第一个锚点开始计数）
      //   否则一律拒绝填写，并如实报告锚点次数与区块数，交给用户 —— 不猜、不点任何按钮。
      const anchorsAll=gCands.filter(c=>c.match.key===anchorKey).map(c=>c.el);
      if(anchorsAll.length===entries.length&&anchorsAll.length>0){
        const ordered=gCands.slice().sort((a,b)=>{try{return (a.el.compareDocumentPosition(b.el)&Node.DOCUMENT_POSITION_FOLLOWING)?-1:1}catch{return 0}});
        let seg=-1;const assigned=[];
        for(const c of ordered){
          if(c.match.key===anchorKey)seg++;
          if(seg>=0){entryIndexOf.set(c.el,seg);assigned.push(c.label||group)}
        }
        entriesByGroup[group]=entries;
        manual.push({label:group,reason:`本页把 ${entries.length} 段经历放在同一区块里，已按「${anchorKey}」字段在页面上的出现顺序，第 1~${entries.length} 段依次对应档案第 1~${entries.length} 段，请核对顺序是否正确。`});
        continue;
      }
      // 页面位置比档案段数少（真实站点常见：默认只渲染 1 段，其余要点"添加"）：
      // 把页面能给的位置按顺序填上（位置 i ← 档案第 i 段，档案本身按最近→最早排序），
      // 其余段如实报告 —— 绝不把后面的段塞进前面的位置，也不点任何按钮。
      skipped.push({label:group,reason:`档案有 ${entries.length} 段经历，本页只渲染 ${blocks.length} 个位置，已按顺序填前 ${blocks.length} 段（档案中较新的），其余 ${entries.length-blocks.length} 段请在页面新增后重填或手动填写。`});
      // 不 continue：继续走下面的 blockOfEl 映射（i<entries.length 的按顺序对应）
    }
    if(blocks.length>entries.length)skipped.push({label:group,reason:`页面有 ${blocks.length} 个经历区块，档案 ${entries.length} 段，已按顺序填前 ${entries.length} 段，其余留空。`});
    const blockOfEl=el=>blocks.findIndex(b=>b===el||b.contains(el));
    for(const c of gCands){
      const i=blockOfEl(c.el);
      if(i<0){if(entries.length===1)entryIndexOf.set(c.el,0);else skipped.push({label:c.label||group,reason:'该字段不属于任何经历区块，无法确定对应关系。'});continue}
      if(i<entries.length)entryIndexOf.set(c.el,i);
      // 超出档案段数的区块留空，不填
    }
  }

  // --- 同名字段多处出现：选一处填（原逻辑是整组判歧义、一个都不填） ---
  // 选择顺序：标签得分高的、且当前为空的那一处；都非空则不动
  const dupChoice=new Map();
  {
    const byKey=new Map();
    for(const c of candidates){
      if(!c.match||c.match.ambiguous)continue;
      if(!['basic','intent'].includes(c.match.group))continue;
      const k=c.match.group+'.'+c.match.key;
      if(!byKey.has(k))byKey.set(k,[]);
      byKey.get(k).push(c);
    }
    for(const [k,list] of byKey){
      if(list.length<2)continue;
      const isEmpty=c=>{try{return empty(c.el)}catch{return false}};
      const isTextish=c=>{try{const tag=(c.el.tagName||'').toLowerCase();if(tag==='textarea')return true;if(tag!=='input')return false;return ['text','search','tel','email','url',''].includes((c.el.type||'text').toLowerCase())}catch{return false}};
      const empties=list.filter(isEmpty);
      empties.sort((a,b)=>(b.match.score||0)-(a.match.score||0));
      // 全都是文本类输入框且有空位时：所有空位都填（如"籍贯"与"户口所在地"同为籍贯信息，页面同时要两处）
      // 控件类型混杂（文本 vs 下拉）时只填得分最高的一处，避免把值塞进语义不同的控件
      const fillAll=empties.length>0&&list.every(isTextish);
      dupChoice.set(k,{pick:empties[0]||null,total:list.length,fillAll});
    }
  }

  // --- 逐控件填写 ---
  const reportFail=(label,r,value)=>manual.push({label,reason:(r&&r.reason)||'填写失败，请手动检查。',value:value!==undefined?String(value):undefined});
  for(const c of candidates){
    const{el,label,labels,context,match}=c;
    const shown=label||'(无标签字段)';
    try{
      // 附件控件：仅标签明确为简历/附件时自动上传，其余报告
      if(c.file){
        const fileLabel=labels.join(' ');
        const isResume=/简历|resume|\bcv\b/i.test(fileLabel);
        const isOther=/(成绩单|成绩|证书|证明|作品|照片|证件|奖状|论文|设计稿|transcript|certificate|portfolio|photo)/i.test(fileLabel);
        if(!isResume||isOther){manual.push({label:shown,reason:'此上传口不是明确的"简历"用途，为避免传错文件，请手动上传。'});continue}
        if(!empty(el)){preserved++;continue}
        const adapter=A.adapters.find(a=>a.id==='file-attach');
        const r=await adapter.set(el,null,{getAttachment});
        if(r.ok){
          // 撤销记录带文件身份（name+size+lastModified）：用户换过文件则身份不符，撤销自动跳过
          records.push({el,before:'',after:r.fileKey||r.after,custom:true,getCurrent:()=>{try{const f=el.files&&el.files[0];return f?f.name+'|'+f.size+'|'+f.lastModified:''}catch{return ''}},restore:async()=>{try{el.value='';el.dispatchEvent(new Event('change',{bubbles:true}));return!(el.files&&el.files.length)}catch{return false}},url:location.href});
          if(r.unverified)manual.push({label:shown,reason:'已注入简历文件，但无法确认网页是否接受，请核对附件是否上传成功。'});
          else filled.push({label:shown,value:r.after});
        }
        else reportFail(shown,r);
        continue;
      }
      if(!match){if(label)manual.push({label:shown,reason:'未识别字段，需本人处理或尚未支持。'});continue}
      if(match.ambiguous){manual.push({label:shown,reason:'此标签匹配到多个档案字段，需人工确认。'});continue}
      const{group,key}=match;
      // 同一字段页面出现多处：只为选中的那一处填写，其余明确报告
      const dup=dupChoice.get(group+'.'+key);
      if(dup){
        if(!dup.pick){manual.push({label:shown,reason:`同一字段在页面出现 ${dup.total} 处且都已有内容，未改动。`});continue}
        if(dup.pick.el!==el){
          if(!dup.fillAll){manual.push({label:shown,reason:`同一字段在页面出现 ${dup.total} 处，已填其中空白的一处，请核对此处。`});continue}
          // fillAll（都是文本类且有空位）：继续往下走，逐处填写
        }
      }
      // 授权门槛
      const needExtra=(group==='basic'&&SENSITIVE_KEYS.includes(key))||group==='file';
      if(needExtra&&!profile.useExtra){skipped.push({label:shown,reason:'此项需本次单独授权，请在插件中勾选附加资料，或手动填写。'});continue}
      // 取值
      let value;
      if(group==='basic'||group==='intent')value=(profile[group]||{})[key];
      else{
        if(!entryIndexOf.has(el)){skipped.push({label:shown,reason:'档案中缺少此段经历，或页面区块无法与档案对应，请手动填写。'});continue}
        const entries=entriesByGroup[group]||(profile[group]||[]).filter(e=>Object.values(e).some(Boolean));
        value=(entries[entryIndexOf.get(el)]||{})[key];
      }
      if(value===undefined||value===null||String(value).trim()===''){skipped.push({label:shown,reason:'档案中缺少此项，请补充或手动填写。'});continue}
      value=String(value).trim();
      // 不覆盖已有内容
      if(!empty(el)){preserved++;continue}
      // 适配器
      const adapter=A.adapters.find(a=>{try{return a.detect(el)}catch{return false}});
      if(!adapter){manual.push({label:shown,reason:'此控件需手动处理。'});continue}
      if(!el.isConnected){skipped.push({label:shown,reason:'页面已变化，请重新点击填写。'});continue}
      const ctx={label:labels.join(' '),group:radioMembers(el),getAttachment,profile};
      // 单项超时保护：任何 adapter 的 set 都必须在上限内返回，否则跳过并如实报告（治"一项挂住=整轮不回执"）
      // 单项预算按控件类型给：原生控件 1.5 秒够；自定义浮层（下拉/日期/搜索）渲染慢，
      // 实测北森 Phoenix 下拉点开后浮层要 1.5 秒以上才出选项 → 放宽到 3 秒，否则会把能填的下拉误判成"超时跳过"。
      const slowKind=/custom-select|date-picker|search-select/.test(String(adapter.id));
      const itemBudget=slowKind?3000:1500;
      const r=await Promise.race([Promise.resolve(adapter.set(el,value,ctx)).then(v=>({v}),e=>({v:{ok:false,reason:'填写异常：'+((e&&e.message)||String(e))}})),sleep(itemBudget).then(()=>({to:true}))]).then(x=>x.to?{ok:false,reason:`此控件响应超时（${itemBudget/1000} 秒），已跳过，请手动检查。`}:(x.v||{ok:false,reason:'未知失败'}));
      if(r&&r.ok){
        records.push({el,before:r.before,after:r.after,custom:!!r.restore,restore:r.restore,getCurrent:r.getCurrent,url:location.href});
        // 无法可靠确认选中/接受状态的归入"需你确认"，不计入"已填写"
        if(r.unverified)manual.push({label:shown,reason:'已尝试填写，但无法确认网页是否接受，请核对此项。',value:value.slice(0,60)});
        else filled.push({label:shown,value:r.afterLabel||(r.after!==undefined?String(r.after).slice(0,60):value.slice(0,60))});
      }else if(r&&r.reason==='already'){preserved++}
      else reportFail(shown,r,value);
    }catch(e){
      manual.push({label:shown,reason:'填写异常已跳过，请手动检查此字段。'});
    }
  }

  if(records.length)history.push(records); // 分批保存：撤销只影响最近一轮
  if(capped)manual.push({label:'较长页面',reason:`本页控件超过 600 个（共 ${total}），仅处理前 600 个。`});
  // 同类提示合并计数（如北森"期望工作地点"7 个复选框各报一次），否则报告会被同一句话刷屏、掩盖真正的问题
  const mergeSame=arr=>{
    const m=new Map();
    for(const it of arr){const k=(it.label||'')+'\u0000'+(it.reason||'');const hit=m.get(k);if(hit)hit.n++;else m.set(k,Object.assign({},it,{n:1}))}
    return [...m.values()].map(x=>x.n>1?Object.assign({},x,{reason:x.reason+'（共 '+x.n+' 处）'}):x);
  };
  const mSkipped=mergeSame(skipped),mManual=mergeSame(manual),mBlocked=mergeSame(blocked);
  const items=[...mSkipped,...mManual,...mBlocked];
  const message=`已填写 ${filled.length} 项，保留已有内容 ${preserved} 项，跳过 ${mSkipped.length} 项，需手动 ${mManual.length} 项，未处理 ${mBlocked.length} 项。尚未保存或提交，请检查。`;
  return{message,filled,skipped:mSkipped,manual:mManual,blocked:mBlocked,preserved,items};
}

globalThis.CampusApply={run,debug:()=>{const b=buildCandidates();return{controls:b.total,blocked:b.blocked.length,cand:b.candidates.length,matched:b.candidates.filter(x=>x.match).length}}}
})();
