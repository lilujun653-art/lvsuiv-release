// 简历随行 · 后台服务（v0.5）
// 职责：触发填写（含 allFrames 多 frame 注入与结果聚合）、撤销、附件读取、快捷键。
const running=new Set();
const FILES=['engine.js','adapters.js','content.js','panel.js'];

// ---------- 扩展 IndexedDB 中的简历附件（profile.js 写入，此处只读） ----------
function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open('campus-files',1);req.onupgradeneeded=()=>{try{req.result.createObjectStore('files')}catch{}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
async function getAttachment(){
  try{
    const db=await openDB();
    const rec=await new Promise((resolve,reject)=>{const tx=db.transaction('files','readonly');const q=tx.objectStore('files').get('resume');q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error)});
    db.close();
    if(!rec||!rec.data)return{ok:false};
    // ArrayBuffer → base64（分块避免栈溢出）
    const bytes=new Uint8Array(rec.data);let bin='';
    for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000));
    return{ok:true,attachment:{name:rec.name||'resume',type:rec.type||'',data:btoa(bin)}};
  }catch(e){return{ok:false}}
}

// ---------- 多 frame 结果聚合 ----------
function emptyReport(){return{message:'',filled:[],skipped:[],manual:[],blocked:[],preserved:0,items:[]}}
function aggregate(frames,iframeCount){
  const out=emptyReport();
  let injected=0;
  for(const f of frames){
    const r=f&&f.result;
    if(!r)continue;
    injected++;
    const tag=f.frameId?'[内嵌页] ':'';
    for(const k of['filled','skipped','manual','blocked'])for(const it of r[k]||[])out[k].push({...it,label:tag+(it.label||'')});
    out.preserved+=(r.preserved||0);
    // 保留各 frame 的 message：该 frame 一项未填但有说明（如档案未确认、环境异常）时并入报告，
    // 避免真实错误被掩盖成"已填写 0 项"；常规统计型 message 与聚合口径重复，跳过
    if(r.message&&!(r.filled&&r.filled.length)&&!/^已填写 \d+ 项，保留已有内容/.test(r.message))out.manual.push({label:tag+'页面提示',reason:String(r.message)});
  }
  if(iframeCount>injected-1)out.manual.push({label:'内嵌页面',reason:'页面包含跨域内嵌区域，无法自动填写，请手动检查。'});
  out.message=`已填写 ${out.filled.length} 项，保留已有内容 ${out.preserved} 项，跳过 ${out.skipped.length} 项，需手动 ${out.manual.length} 项，未处理 ${out.blocked.length} 项。尚未保存或提交，请检查。`;
  out.items=[...out.skipped,...out.manual,...out.blocked];
  return out;
}

// ---------- 主流程 ----------
async function fillTab(tab,extra=false){
  if(!tab||!tab.id||running.has(tab.id))return;
  const {profile}=await chrome.storage.local.get('profile');
  if(!profile||!profile.confirmed){await chrome.runtime.openOptionsPage();return}
  // tab.url 读得到且明显不是 http(s) → 提示；读不到不拦截，尝试注入，失败再提示
  if(tab.url&&!/^https?:\/\//.test(tab.url)){
    await chrome.action.setBadgeText({tabId:tab.id,text:'!'});
    await chrome.action.setTitle({tabId:tab.id,title:'请先打开普通招聘网页，再点击填写'});
    return;
  }
  running.add(tab.id);
  try{
    await chrome.action.setBadgeText({tabId:tab.id,text:'…'});
    // 注入全部 frame；跨域子 frame 可能失败，尽力而为
    let injectedAll=true;
    try{await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},files:FILES})}
    catch(e){injectedAll=false;await chrome.scripting.executeScript({target:{tabId:tab.id},files:FILES})}
    await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>CampusPanel.show({message:'正在填写，请稍候…',items:[]},true)});
    // 各 frame 分别执行并聚合
    let frames;
    try{frames=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:p=>CampusApply.run('fill',p),args:[{...profile,useExtra:extra}]})}
    catch(e){frames=[{frameId:0,result:await chrome.scripting.executeScript({target:{tabId:tab.id},func:p=>CampusApply.run('fill',p),args:[{...profile,useExtra:extra}]}).then(r=>r[0]&&r[0].result).catch(()=>null)}]}
    // 顶层 frame 中 iframe 数量（用于判断是否有未能注入的内嵌页）
    let iframeCount=0;
    try{const r=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>document.querySelectorAll('iframe').length});iframeCount=(r[0]&&r[0].result)||0}catch{}
    const report=aggregate(frames,iframeCount);
    await chrome.scripting.executeScript({target:{tabId:tab.id},func:(r,p)=>CampusPanel.show(r,false,p),args:[report,{basic:profile.basic,intent:profile.intent,education:profile.education,internship:profile.internship,work:profile.work,project:profile.project,language:profile.language,award:profile.award,certificate:profile.certificate}]});
    await chrome.action.setBadgeText({tabId:tab.id,text:''});
    await chrome.action.setTitle({tabId:tab.id,title:'简历随行 · 打开复制面板'});
  }catch(e){
    await chrome.action.setBadgeText({tabId:tab.id,text:'!'}).catch(()=>{});
    await chrome.action.setTitle({tabId:tab.id,title:'填写未完成，请刷新或打开普通网页后重试'}).catch(()=>{});
    await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>globalThis.CampusPanel&&CampusPanel.show({message:'填写未完成，请检查当前页面；可以重新点击图标。',items:[]},false)}).catch(()=>{});
  }finally{running.delete(tab.id)}
}

// 撤销：在所有 frame 执行并汇总
async function undoTab(tabId){
  try{
    await chrome.scripting.executeScript({target:{tabId,allFrames:true},files:FILES}).catch(()=>{});
    const frames=await chrome.scripting.executeScript({target:{tabId,allFrames:true},func:()=>CampusApply.run('undo')});
    let restored=0,other=0;
    for(const f of frames||[]){
      const m=f&&f.result&&f.result.message||'';
      const a=m.match(/已撤销 (\d+) 项/),b=m.match(/另有 (\d+) 项/);
      if(a)restored+=+a[1];if(b)other+=+b[1];
    }
    return{message:`已撤销 ${restored} 项${other?'；另有 '+other+' 项已被修改、失效或无法恢复，保留现状':''}。撤销仅影响当前页面，不能撤回服务器保存。`,filled:[],skipped:[],manual:[],blocked:[],items:[]};
  }catch(e){return{message:'撤销未完成，请刷新后重试。',filled:[],skipped:[],manual:[],blocked:[],items:[]}}
}

// 首版只开放复制（方案 FINAL P0#5）：工具栏点击已在 manifest 里改为打开复制面板，
// 自动填入口在此显式关闭，避免将来误开。要恢复需同时改 manifest 与这里。
const ALLOW_AUTOFILL=false;
chrome.action.onClicked.addListener(tab=>{if(!ALLOW_AUTOFILL)return;fillTab(tab).catch(()=>{})});
chrome.commands.onCommand.addListener(async cmd=>{
  if(cmd!=='fill-page'||!ALLOW_AUTOFILL)return;
  try{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(tab)await fillTab(tab)}catch{}
});
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(sender.id!==chrome.runtime.id)return;
  if(message.type==='campus-open-profile'){chrome.runtime.openOptionsPage();reply({ok:true});return}
  if(message.type==='campus-fill-extra'){if(!sender.tab||!sender.tab.id)return;fillTab(sender.tab,true).then(()=>reply({ok:true}),()=>reply({ok:false}));return true}
  if(message.type==='campus-undo'){if(!sender.tab||!sender.tab.id)return;undoTab(sender.tab.id).then(result=>reply({ok:true,result}),()=>reply({ok:false}));return true}
  if(message.type==='campus-get-attachment'){getAttachment().then(reply,()=>reply({ok:false}));return true}
});
