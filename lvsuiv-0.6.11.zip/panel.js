// 简历随行 · 页面内结果面板（v0.5 重写）
// 分类展示：✅已填 / ⏭️跳过 / ⚠️需手动（含"复制此项"）/ ⛔未处理；
// 一键复制区：列出档案全部字段，点击复制（任何网站都能靠复制粘贴兜底）。
(function(){
if(globalThis.CampusPanel)return;
let host,root,status,list,undo,extra,copyBox,lastProfile=null;

// 档案字段中文化（复制区展示用）
const FIELD_LABELS={name:'姓名',email:'邮箱',phone:'手机号码',dialCode:'电话区号',gender:'性别',birthDate:'出生日期',experience:'工作经验',highestLevel:'最高学历',location:'所在地',latestCompany:'最近公司',selfDescription:'自我评价',idNumber:'证件号',politicalStatus:'政治面貌',ethnicity:'民族',hometown:'籍贯',currentResidence:'现居住地',height:'身高',school:'学校名称',major:'专业名称',degree:'学位',level:'学历',start:'开始时间',end:'结束时间',company:'单位名称',role:'职位/角色',description:'描述',responsibilities:'职责',ongoing:'是否至今',proficiency:'掌握程度',speaking:'听说',writing:'读写',date:'时间',applicationCity:'意向工作城市',currentSalary:'当前薪资',expectedSalary:'期望薪资',expectedCity:'期望城市'};
const GROUP_LABELS={basic:'基本信息',intent:'求职意向',education:'教育经历',internship:'实习经历',work:'工作经历',project:'项目经历',language:'语言能力',award:'获奖经历',certificate:'证书'};
function flattenProfile(p){
  const rows=[];
  if(!p)return rows;
  for(const g of['basic','intent']){for(const [k,v]of Object.entries(p[g]||{})){if(v)rows.push({label:(GROUP_LABELS[g])+' · '+(FIELD_LABELS[k]||k),value:String(v)})}}
  for(const g of['education','internship','work','project','language','award','certificate']){
    (p[g]||[]).forEach((entry,i)=>{for(const [k,v]of Object.entries(entry)){if(v)rows.push({label:GROUP_LABELS[g]+' '+(i+1)+' · '+(FIELD_LABELS[k]||k),value:String(v)})}});
  }
  return rows;
}

function create(){
  host=document.createElement('div');host.style.cssText='position:fixed;right:18px;bottom:18px;width:380px;max-width:calc(100vw - 36px);z-index:2147483647;';
  root=host.attachShadow({mode:'closed'});
  const style=document.createElement('style');style.textContent=':host{all:initial}*{box-sizing:border-box}.box{font:14px/1.65 system-ui,"Microsoft YaHei",sans-serif;color:#193e31;background:#fff;border:1px solid #d5e1d7;border-radius:14px;box-shadow:0 10px 40px #0002;padding:18px}header{display:flex;justify-content:space-between;align-items:center;font-weight:700}button{font:inherit;cursor:pointer;border:0;border-radius:7px;padding:6px 9px;background:#eaf1e6;color:#193e31}button:disabled{opacity:.5;cursor:wait}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}p{margin:10px 0}.list{max-height:240px;overflow:auto;font-size:12px}.cat{margin-top:8px;font-weight:700;font-size:12px}.item{padding:5px 0;border-bottom:1px solid #eee;display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.item span{flex:1}.item button{flex:none;padding:2px 7px;font-size:11px}.note{font-size:12px;color:#68766b}.copy{max-height:200px;overflow:auto;font-size:12px;margin-top:8px;border-top:1px dashed #d5e1d7;padding-top:8px}';
  root.append(style);
  const box=document.createElement('section');box.className='box';box.setAttribute('aria-label','简历随行填写结果');
  const header=document.createElement('header');header.textContent='简历随行';
  const close=document.createElement('button');close.textContent='收起';close.onclick=()=>host.remove();header.append(close);
  status=document.createElement('p');status.setAttribute('role','status');
  list=document.createElement('div');list.className='list';
  const actions=document.createElement('div');actions.className='actions';
  undo=document.createElement('button');undo.textContent='撤销填写';
  undo.onclick=async()=>{undo.disabled=true;try{show(await doUndo(),false)}finally{undo.disabled=false}};
  const edit=document.createElement('button');edit.textContent='修改资料';edit.onclick=()=>chrome.runtime.sendMessage({type:'campus-open-profile'});
  extra=document.createElement('button');extra.textContent='本次也填写附加资料';
  extra.onclick=()=>{if(!confirm('将档案中的附加个人资料及求职意向用于当前网页，包括已保存的出生日期、性别、证件号、薪资和城市。是否已核对并同意本次使用？'))return;extra.disabled=true;chrome.runtime.sendMessage({type:'campus-fill-extra'}).finally(()=>extra.disabled=false)};
  const copyBtn=document.createElement('button');copyBtn.textContent='一键复制';
  copyBox=document.createElement('div');copyBox.className='copy';copyBox.hidden=true;
  copyBtn.onclick=()=>{copyBox.hidden=!copyBox.hidden;if(!copyBox.hidden)renderCopy()};
  actions.append(undo,edit,extra,copyBtn);
  const note=document.createElement('p');note.className='note';note.textContent='请检查后自行保存或提交。复杂控件仍可能需要手动填写。';
  box.append(header,status,list,actions,copyBox,note);root.append(box);document.documentElement.append(host);
}
// 撤销：优先经 background 在所有 frame 执行；demo 环境退回本页执行
async function doUndo(){
  try{
    if(globalThis.chrome&&chrome.runtime&&chrome.runtime.sendMessage){
      const r=await chrome.runtime.sendMessage({type:'campus-undo'});
      if(r&&r.result)return r.result;
    }
  }catch{}
  return CampusApply.run('undo');
}
function row(item,withCopy){
  const div=document.createElement('div');div.className='item';
  const text=document.createElement('span');text.textContent=item.label+(item.value?'：'+item.value:'')+(item.reason?'：'+item.reason:'');
  div.append(text);
  if(withCopy&&item.value){div.append(copyButton(item.value))}
  return div;
}
function copyButton(value){
  const b=document.createElement('button');b.textContent='复制此项';
  b.onclick=async()=>{try{await navigator.clipboard.writeText(value);b.textContent='已复制'}catch{b.textContent='复制失败，请手动选择'}setTimeout(()=>b.textContent='复制此项',1800)};
  return b;
}
function renderCopy(){
  copyBox.replaceChildren();
  const rows=flattenProfile(lastProfile);
  if(!rows.length){const p=document.createElement('p');p.className='note';p.textContent='未读取到档案内容。';copyBox.append(p);return}
  const all=document.createElement('button');all.textContent='复制全部字段';
  all.onclick=async()=>{try{await navigator.clipboard.writeText(rows.map(r=>r.label+'：'+r.value).join('\n'));all.textContent='已复制全部'}catch{all.textContent='复制失败'}setTimeout(()=>all.textContent='复制全部字段',1800)};
  copyBox.append(all);
  for(const r of rows)copyBox.append(row(r,true));
}
function cat(title,items,withCopy){
  if(!items||!items.length)return;
  const h=document.createElement('div');h.className='cat';h.textContent=title;list.append(h);
  for(const it of items)list.append(row(it,withCopy));
}
function show(result,busy,profile){
  if(window!==window.top)return; // 面板只在顶层 frame 显示
  if(profile)lastProfile=profile;
  if(!host)create();else if(!host.isConnected)document.documentElement.append(host);
  status.textContent=result.message;
  list.replaceChildren();
  cat('✅ 已填写',result.filled,false);
  cat('⏭️ 已跳过',result.skipped,false);
  cat('⚠️ 需手动处理',result.manual,true);
  cat('⛔ 未处理（敏感/禁止/歧义）',result.blocked,false);
  // 兼容旧版 items 平铺结果
  if(!result.filled&&!result.skipped&&!result.manual&&!result.blocked)for(const item of result.items||[])list.append(row(item,false));
  copyBox.hidden=true;
  undo.disabled=!!busy;extra.disabled=!!busy;
}
globalThis.CampusPanel={show};
})();
