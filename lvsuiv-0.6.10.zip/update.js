(function () {
  'use strict';
  const LvUpdate = {};
  LvUpdate.DEFAULT_UPDATE_URL = 'https://meikeji-d8gjamou7090c09a2-1454638672.tcloudbaseapp.com/lvsuiv/latest.json';
  function parse(v) {
    if (typeof v !== 'string') return null;
    const m = /^v?(\d+(?:\.[0-9A-Za-z]+)*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(v.trim());
    return m ? [m[1].split('.'), m[2] ? m[2].split('.') : null] : null;
  }
  function segment(a, b) {
    const an = /^\d+$/.test(a), bn = /^\d+$/.test(b);
    if (an && bn) { a = BigInt(a); b = BigInt(b); }
    else if (an !== bn) return an ? 1 : -1;
    return a === b ? 0 : a > b ? 1 : -1;
  }
  LvUpdate.cmpV = function (a, b) {
    const x = parse(a), y = parse(b);
    if (!x || !y) return null;
    for (let i = 0; i < Math.max(x[0].length, y[0].length); i++) {
      const c = segment(x[0][i] || '0', y[0][i] || '0');
      if (c) return c;
    }
    if (!x[1] || !y[1]) return x[1] ? -1 : y[1] ? 1 : 0;
    for (let i = 0; i < Math.max(x[1].length, y[1].length); i++) {
      if (x[1][i] === undefined || y[1][i] === undefined) return x[1][i] === undefined ? -1 : 1;
      const a = x[1][i], b = y[1][i];
      const c = /^\d+$/.test(a) !== /^\d+$/.test(b) ? (/^\d+$/.test(a) ? -1 : 1) : segment(a, b);
      if (c) return c;
    }
    return 0;
  };
  LvUpdate.getUrl = async function () {
    const stored = await chrome.storage.local.get('updateUrl');
    return stored.updateUrl || LvUpdate.DEFAULT_UPDATE_URL;
  };
  LvUpdate.check = async function ({ url, fetchImpl, timeoutMs = 6000, currentVersion } = {}) {
    let timer;
    // 无法取得可信版本时不能断言已是最新，否则会把断网或服务故障伪装成成功。
    const error = detail => ({ state: 'error', remote: '', notes: [], zipUrl: '', detail });
    try {
      const current = currentVersion === undefined ? chrome.runtime.getManifest().version : currentVersion;
      if (!parse(current)) return error('invalid-current-version');
      const target = url === undefined ? await LvUpdate.getUrl() : url;
      if (typeof target !== 'string' || !/^https?:$/.test(new URL(target).protocol)) return error('invalid-url');
      const controller = new AbortController();
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => { reject(new Error('timeout')); controller.abort(); }, timeoutMs);
      });
      const request = async () => {
        // 固定 GET，无请求体、无档案字段、无 Cookie；仅用户点击时调用。
        const response = await (fetchImpl || globalThis.fetch)(target, {
          method: 'GET', signal: controller.signal, credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer'
        });
        if (response.status !== 200) throw new Error('http-' + response.status);
        return await response.json();
      };
      const data = await Promise.race([request(), timeout]);
      const cmp = LvUpdate.cmpV(data?.version, current);
      if (cmp === null) return error('invalid-remote-version');
      let zipUrl = '';
      if (typeof data.zip?.url === 'string') {
        try { const u = new URL(data.zip.url); if (/^https?:$/.test(u.protocol)) zipUrl = u.href; } catch (_) {}
      }
      return { state: cmp > 0 ? 'newer' : 'latest', remote: data.version,
        notes: Array.isArray(data.notes) ? data.notes.filter(n => typeof n === 'string') : [],
        zipUrl, detail: cmp < 0 ? 'remote-older' : '' };
    } catch (e) { return error(e?.message || 'request-failed'); }
    finally { clearTimeout(timer); }
  };
  if (typeof window !== 'undefined') window.LvUpdate = LvUpdate;
  if (typeof module !== 'undefined') module.exports = LvUpdate;
})();
